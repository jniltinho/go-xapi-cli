/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * Cluster member metadata
 * First published in XenServer 7.6.
 *
 * @author Cloud Software Group, Inc.
 */
public class ClusterHost extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    ClusterHost(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a ClusterHost, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof ClusterHost)
        {
            ClusterHost other = (ClusterHost) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a ClusterHost
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "cluster", this.cluster);
            print.printf("%1$20s: %2$s\n", "host", this.host);
            print.printf("%1$20s: %2$s\n", "enabled", this.enabled);
            print.printf("%1$20s: %2$s\n", "PIF", this.PIF);
            print.printf("%1$20s: %2$s\n", "joined", this.joined);
            print.printf("%1$20s: %2$s\n", "live", this.live);
            print.printf("%1$20s: %2$s\n", "lastUpdateLive", this.lastUpdateLive);
            print.printf("%1$20s: %2$s\n", "allowedOperations", this.allowedOperations);
            print.printf("%1$20s: %2$s\n", "currentOperations", this.currentOperations);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            return writer.toString();
        }

        /**
         * Convert a ClusterHost.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("cluster", this.cluster == null ? new Cluster("OpaqueRef:NULL") : this.cluster);
            map.put("host", this.host == null ? new Host("OpaqueRef:NULL") : this.host);
            map.put("enabled", this.enabled == null ? false : this.enabled);
            map.put("PIF", this.PIF == null ? new PIF("OpaqueRef:NULL") : this.PIF);
            map.put("joined", this.joined == null ? false : this.joined);
            map.put("live", this.live == null ? false : this.live);
            map.put("last_update_live", this.lastUpdateLive == null ? new Date(0) : this.lastUpdateLive);
            map.put("allowed_operations", this.allowedOperations == null ? new LinkedHashSet<Types.ClusterHostOperation>() : this.allowedOperations);
            map.put("current_operations", this.currentOperations == null ? new HashMap<String, Types.ClusterHostOperation>() : this.currentOperations);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * Reference to the Cluster object
         */
        @JsonProperty("cluster")
        public Cluster cluster;

        /**
         * Reference to the Host object
         */
        @JsonProperty("host")
        public Host host;

        /**
         * Whether the cluster host believes that clustering should be enabled on this host. This field can be altered by calling the enable/disable message on a cluster host. Only enabled members run the underlying cluster stack. Disabled members are still considered a member of the cluster (see joined), and can be re-enabled by the user.
         */
        @JsonProperty("enabled")
        public Boolean enabled;

        /**
         * Reference to the PIF object
         */
        @JsonProperty("PIF")
        public PIF PIF;

        /**
         * Whether the cluster host has joined the cluster. Contrary to enabled, a host that is not joined is not considered a member of the cluster, and hence enable and disable operations cannot be performed on this host.
         */
        @JsonProperty("joined")
        public Boolean joined;

        /**
         * Whether the underlying cluster stack thinks we are live. This field is set automatically based on updates from the cluster stack and cannot be altered by the user.
         * Experimental. First published in 24.3.0.
         */
        @JsonProperty("live")
        public Boolean live;

        /**
         * Time when the live field was last updated based on information from the cluster stack
         * Experimental. First published in 24.3.0.
         */
        @JsonProperty("last_update_live")
        public Date lastUpdateLive;

        /**
         * list of the operations allowed in this state. This list is advisory only and the server state may have changed by the time this field is read by a client.
         */
        @JsonProperty("allowed_operations")
        public Set<Types.ClusterHostOperation> allowedOperations;

        /**
         * links each of the running tasks using this object (by reference) to a current_operation enum which describes the nature of the task.
         */
        @JsonProperty("current_operations")
        public Map<String, Types.ClusterHostOperation> currentOperations;

        /**
         * Additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

    }

    /**
     * Get a record containing the current state of the given Cluster_host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public ClusterHost.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<ClusterHost.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the Cluster_host instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static ClusterHost getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<ClusterHost>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given Cluster_host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the cluster field of the given Cluster_host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Cluster getCluster(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_cluster";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Cluster>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host field of the given Cluster_host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getHost(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_host";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the enabled field of the given Cluster_host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PIF field of the given Cluster_host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PIF getPIF(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_PIF";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the joined field of the given Cluster_host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getJoined(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_joined";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the live field of the given Cluster_host.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.3.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getLive(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the last_update_live field of the given Cluster_host.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.3.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getLastUpdateLive(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_last_update_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allowed_operations field of the given Cluster_host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.ClusterHostOperation> getAllowedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.ClusterHostOperation>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the current_operations field of the given Cluster_host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Types.ClusterHostOperation> getCurrentOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_current_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Types.ClusterHostOperation>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given Cluster_host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Add a new host to an existing cluster.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param cluster Cluster to join 
     * @param host new cluster member 
     * @param pif Network interface to use for communication 
     * @return the newly created cluster_host object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.PifNotAttachedToHost Cluster_host creation failed as the PIF provided is not attached to the host.
     * @throws Types.NoClusterHostsReachable No other cluster host was reachable when joining
     */
    public static ClusterHost create(Connection c, Cluster cluster, Host host, PIF pif) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.PifNotAttachedToHost,
    Types.NoClusterHostsReachable {
        String methodCall = "Cluster_host.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, cluster, host, pif };
        var typeReference = new TypeReference<ClusterHost>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Add a new host to an existing cluster.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param cluster Cluster to join 
     * @param host new cluster member 
     * @param pif Network interface to use for communication 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.PifNotAttachedToHost Cluster_host creation failed as the PIF provided is not attached to the host.
     * @throws Types.NoClusterHostsReachable No other cluster host was reachable when joining
     */
    public static Task createAsync(Connection c, Cluster cluster, Host host, PIF pif) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.PifNotAttachedToHost,
    Types.NoClusterHostsReachable {
        String methodCall = "Async.Cluster_host.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, cluster, host, pif };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Remove the host from an existing cluster. This operation is allowed even if a cluster host is not enabled.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusterStackInUse The cluster stack is still in use by at least one plugged PBD.
     * @throws Types.ClusteringDisabled An operation was attempted while clustering was disabled on the cluster_host.
     * @throws Types.ClusterHostIsLast The last cluster host cannot be destroyed. Destroy the cluster instead
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusterStackInUse,
    Types.ClusteringDisabled,
    Types.ClusterHostIsLast {
        String methodCall = "Cluster_host.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the host from an existing cluster. This operation is allowed even if a cluster host is not enabled.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusterStackInUse The cluster stack is still in use by at least one plugged PBD.
     * @throws Types.ClusteringDisabled An operation was attempted while clustering was disabled on the cluster_host.
     * @throws Types.ClusterHostIsLast The last cluster host cannot be destroyed. Destroy the cluster instead
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusterStackInUse,
    Types.ClusteringDisabled,
    Types.ClusterHostIsLast {
        String methodCall = "Async.Cluster_host.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Enable cluster membership for a disabled cluster host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.PifAllowsUnplug The operation you requested cannot be performed because the specified PIF allows unplug.
     * @throws Types.RequiredPifIsUnplugged The operation you requested cannot be performed because the specified PIF is currently unplugged.
     */
    public void enable(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.PifAllowsUnplug,
    Types.RequiredPifIsUnplugged {
        String methodCall = "Cluster_host.enable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Enable cluster membership for a disabled cluster host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.PifAllowsUnplug The operation you requested cannot be performed because the specified PIF allows unplug.
     * @throws Types.RequiredPifIsUnplugged The operation you requested cannot be performed because the specified PIF is currently unplugged.
     */
    public Task enableAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.PifAllowsUnplug,
    Types.RequiredPifIsUnplugged {
        String methodCall = "Async.Cluster_host.enable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Remove a host from an existing cluster forcefully.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusterStackInUse The cluster stack is still in use by at least one plugged PBD.
     */
    public void forceDestroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusterStackInUse {
        String methodCall = "Cluster_host.force_destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove a host from an existing cluster forcefully.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusterStackInUse The cluster stack is still in use by at least one plugged PBD.
     */
    public Task forceDestroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusterStackInUse {
        String methodCall = "Async.Cluster_host.force_destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Disable cluster membership for an enabled cluster host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusterStackInUse The cluster stack is still in use by at least one plugged PBD.
     */
    public void disable(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusterStackInUse {
        String methodCall = "Cluster_host.disable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Disable cluster membership for an enabled cluster host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusterStackInUse The cluster stack is still in use by at least one plugged PBD.
     */
    public Task disableAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusterStackInUse {
        String methodCall = "Async.Cluster_host.disable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the Cluster_hosts known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<ClusterHost> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<ClusterHost>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of Cluster_host references to Cluster_host records for all Cluster_hosts known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<ClusterHost, ClusterHost.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster_host.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<ClusterHost, ClusterHost.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}