/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A new piece of functionality
 * First published in XenServer 7.2.
 *
 * @author Cloud Software Group, Inc.
 */
public class Feature extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    Feature(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a Feature, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Feature)
        {
            Feature other = (Feature) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a Feature
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "enabled", this.enabled);
            print.printf("%1$20s: %2$s\n", "experimental", this.experimental);
            print.printf("%1$20s: %2$s\n", "version", this.version);
            print.printf("%1$20s: %2$s\n", "host", this.host);
            return writer.toString();
        }

        /**
         * Convert a Feature.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("enabled", this.enabled == null ? false : this.enabled);
            map.put("experimental", this.experimental == null ? false : this.experimental);
            map.put("version", this.version == null ? "" : this.version);
            map.put("host", this.host == null ? new Host("OpaqueRef:NULL") : this.host);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * Indicates whether the feature is enabled
         */
        @JsonProperty("enabled")
        public Boolean enabled;

        /**
         * Indicates whether the feature is experimental (as opposed to stable and fully supported)
         */
        @JsonProperty("experimental")
        public Boolean experimental;

        /**
         * The version of this feature
         */
        @JsonProperty("version")
        public String version;

        /**
         * The host where this feature is available
         */
        @JsonProperty("host")
        public Host host;

    }

    /**
     * Get a record containing the current state of the given Feature.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Feature.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Feature.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Feature.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the Feature instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Feature getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Feature.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<Feature>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the Feature instances with the given label.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Feature> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Feature.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<Feature>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given Feature.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Feature.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given Feature.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Feature.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given Feature.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Feature.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the enabled field of the given Feature.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Feature.get_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the experimental field of the given Feature.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getExperimental(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Feature.get_experimental";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the version field of the given Feature.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getVersion(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Feature.get_version";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host field of the given Feature.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getHost(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Feature.get_host";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the Features known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Feature> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Feature.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<Feature>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of Feature references to Feature records for all Features known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<Feature, Feature.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Feature.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<Feature, Feature.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}