/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * Describes an observer which will control observability activity in the Toolstack
 * First published in .
 *
 * @author Cloud Software Group, Inc.
 */
public class Observer extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    Observer(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a Observer, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Observer)
        {
            Observer other = (Observer) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a Observer
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "hosts", this.hosts);
            print.printf("%1$20s: %2$s\n", "attributes", this.attributes);
            print.printf("%1$20s: %2$s\n", "endpoints", this.endpoints);
            print.printf("%1$20s: %2$s\n", "components", this.components);
            print.printf("%1$20s: %2$s\n", "enabled", this.enabled);
            return writer.toString();
        }

        /**
         * Convert a Observer.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("hosts", this.hosts == null ? new LinkedHashSet<Host>() : this.hosts);
            map.put("attributes", this.attributes == null ? new HashMap<String, String>() : this.attributes);
            map.put("endpoints", this.endpoints == null ? new LinkedHashSet<String>() : this.endpoints);
            map.put("components", this.components == null ? new LinkedHashSet<String>() : this.components);
            map.put("enabled", this.enabled == null ? false : this.enabled);
            return map;
        }

        /**
         * Unique identifier/object reference
         * Experimental. First published in 23.14.0.
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         * First published in XenServer 4.0.
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         * First published in XenServer 4.0.
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * The list of hosts the observer is active on. An empty list means all hosts
         * Experimental. First published in 23.14.0.
         */
        @JsonProperty("hosts")
        public Set<Host> hosts;

        /**
         * Attributes that observer will add to the data they produce
         * Experimental. First published in 23.14.0.
         */
        @JsonProperty("attributes")
        public Map<String, String> attributes;

        /**
         * The list of endpoints where data is exported to. Each endpoint is a URL or the string 'bugtool' refering to the internal logs
         * Experimental. First published in 23.14.0.
         */
        @JsonProperty("endpoints")
        public Set<String> endpoints;

        /**
         * The list of xenserver components the observer will broadcast. An empty list means all components
         * Experimental. First published in 23.14.0.
         */
        @JsonProperty("components")
        public Set<String> components;

        /**
         * This denotes if the observer is enabled. true if it is enabled and false if it is disabled
         * Experimental. First published in 23.14.0.
         */
        @JsonProperty("enabled")
        public Boolean enabled;

    }

    /**
     * Get a record containing the current state of the given Observer.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Observer.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Observer.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the Observer instance with the specified UUID.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Observer getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<Observer>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new Observer instance, and return its handle.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return reference to the newly created object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Observer create(Connection c, Observer.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<Observer>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new Observer instance, and return its handle.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, Observer.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Observer.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy the specified Observer instance.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy the specified Observer instance.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Observer.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the Observer instances with the given label.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Observer> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<Observer>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given Observer.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given Observer.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given Observer.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the hosts field of the given Observer.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Host> getHosts(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_hosts";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Host>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the attributes field of the given Observer.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getAttributes(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_attributes";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the endpoints field of the given Observer.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getEndpoints(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_endpoints";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the components field of the given Observer.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getComponents(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_components";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the enabled field of the given Observer.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name/label field of the given Observer.
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param label New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, label };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name/description field of the given Observer.
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param description New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameDescription(Connection c, String description) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, description };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets the hosts that the observer is to be registered on
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param value Hosts the observer is registered on 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHosts(Connection c, Set<Host> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.set_hosts";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets the hosts that the observer is to be registered on
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param value Hosts the observer is registered on 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setHostsAsync(Connection c, Set<Host> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Observer.set_hosts";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Enable / disable this observer which will stop the observer from producing observability information
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param value If the observer is to be enabled (true) or disabled (false) 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setEnabled(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.set_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Enable / disable this observer which will stop the observer from producing observability information
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param value If the observer is to be enabled (true) or disabled (false) 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setEnabledAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Observer.set_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the attributes of an observer. These are used to emit metadata by the observer
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param value The attributes that the observer emits as part of the data 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setAttributes(Connection c, Map<String, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.set_attributes";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the attributes of an observer. These are used to emit metadata by the observer
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param value The attributes that the observer emits as part of the data 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setAttributesAsync(Connection c, Map<String, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Observer.set_attributes";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the file/HTTP endpoints the observer sends data to
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param value The endpoints that the observer will export data to. A URL or the string 'bugtool'. This can refer to an enpoint to the local file system 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setEndpoints(Connection c, Set<String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.set_endpoints";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the file/HTTP endpoints the observer sends data to
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param value The endpoints that the observer will export data to. A URL or the string 'bugtool'. This can refer to an enpoint to the local file system 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setEndpointsAsync(Connection c, Set<String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Observer.set_endpoints";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the components on which the observer will broadcast to. i.e. xapi, xenopsd, networkd, etc.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param value The components the observer will broadcast to 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setComponents(Connection c, Set<String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.set_components";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the components on which the observer will broadcast to. i.e. xapi, xenopsd, networkd, etc.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @param value The components the observer will broadcast to 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setComponentsAsync(Connection c, Set<String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Observer.set_components";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the Observers known to the system.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Observer> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<Observer>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of Observer references to Observer records for all Observers known to the system.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.14.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<Observer, Observer.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Observer.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<Observer, Observer.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}