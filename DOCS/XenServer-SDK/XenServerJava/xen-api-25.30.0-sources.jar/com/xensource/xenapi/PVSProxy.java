/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * a proxy connects a VM/VIF with a PVS site
 * First published in XenServer 7.1.
 *
 * @author Cloud Software Group, Inc.
 */
public class PVSProxy extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    PVSProxy(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a PVSProxy, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof PVSProxy)
        {
            PVSProxy other = (PVSProxy) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a PVSProxy
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "site", this.site);
            print.printf("%1$20s: %2$s\n", "VIF", this.VIF);
            print.printf("%1$20s: %2$s\n", "currentlyAttached", this.currentlyAttached);
            print.printf("%1$20s: %2$s\n", "status", this.status);
            return writer.toString();
        }

        /**
         * Convert a PVSProxy.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("site", this.site == null ? new PVSSite("OpaqueRef:NULL") : this.site);
            map.put("VIF", this.VIF == null ? new VIF("OpaqueRef:NULL") : this.VIF);
            map.put("currently_attached", this.currentlyAttached == null ? false : this.currentlyAttached);
            map.put("status", this.status == null ? Types.PvsProxyStatus.UNRECOGNIZED : this.status);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * PVS site this proxy is part of
         */
        @JsonProperty("site")
        public PVSSite site;

        /**
         * VIF of the VM using the proxy
         */
        @JsonProperty("VIF")
        public VIF VIF;

        /**
         * true = VM is currently proxied
         */
        @JsonProperty("currently_attached")
        public Boolean currentlyAttached;

        /**
         * The run-time status of the proxy
         */
        @JsonProperty("status")
        public Types.PvsProxyStatus status;

    }

    /**
     * Get a record containing the current state of the given PVS_proxy.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PVSProxy.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_proxy.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PVSProxy.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the PVS_proxy instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PVSProxy getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_proxy.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<PVSProxy>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given PVS_proxy.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_proxy.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the site field of the given PVS_proxy.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PVSSite getSite(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_proxy.get_site";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PVSSite>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VIF field of the given PVS_proxy.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VIF getVIF(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_proxy.get_VIF";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the currently_attached field of the given PVS_proxy.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getCurrentlyAttached(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_proxy.get_currently_attached";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the status field of the given PVS_proxy.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.PvsProxyStatus getStatus(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_proxy.get_status";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.PvsProxyStatus>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Configure a VM/VIF to use a PVS proxy
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param site PVS site that we proxy for 
     * @param VIF VIF for the VM that needs to be proxied 
     * @return The reference of the created PVS proxy
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PVSProxy create(Connection c, PVSSite site, VIF VIF) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_proxy.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, site, VIF };
        var typeReference = new TypeReference<PVSProxy>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Configure a VM/VIF to use a PVS proxy
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param site PVS site that we proxy for 
     * @param VIF VIF for the VM that needs to be proxied 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, PVSSite site, VIF VIF) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PVS_proxy.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, site, VIF };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * remove (or switch off) a PVS proxy for this VM
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_proxy.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * remove (or switch off) a PVS proxy for this VM
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PVS_proxy.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the PVS_proxys known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<PVSProxy> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_proxy.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<PVSProxy>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of PVS_proxy references to PVS_proxy records for all PVS_proxys known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<PVSProxy, PVSProxy.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_proxy.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<PVSProxy, PVSProxy.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}