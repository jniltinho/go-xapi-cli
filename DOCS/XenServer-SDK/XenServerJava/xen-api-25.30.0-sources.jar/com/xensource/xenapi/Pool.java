/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * Pool-wide information
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class Pool extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    Pool(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a Pool, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Pool)
        {
            Pool other = (Pool) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a Pool
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "master", this.master);
            print.printf("%1$20s: %2$s\n", "defaultSR", this.defaultSR);
            print.printf("%1$20s: %2$s\n", "suspendImageSR", this.suspendImageSR);
            print.printf("%1$20s: %2$s\n", "crashDumpSR", this.crashDumpSR);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "haEnabled", this.haEnabled);
            print.printf("%1$20s: %2$s\n", "haConfiguration", this.haConfiguration);
            print.printf("%1$20s: %2$s\n", "haStatefiles", this.haStatefiles);
            print.printf("%1$20s: %2$s\n", "haHostFailuresToTolerate", this.haHostFailuresToTolerate);
            print.printf("%1$20s: %2$s\n", "haPlanExistsFor", this.haPlanExistsFor);
            print.printf("%1$20s: %2$s\n", "haAllowOvercommit", this.haAllowOvercommit);
            print.printf("%1$20s: %2$s\n", "haOvercommitted", this.haOvercommitted);
            print.printf("%1$20s: %2$s\n", "blobs", this.blobs);
            print.printf("%1$20s: %2$s\n", "tags", this.tags);
            print.printf("%1$20s: %2$s\n", "guiConfig", this.guiConfig);
            print.printf("%1$20s: %2$s\n", "healthCheckConfig", this.healthCheckConfig);
            print.printf("%1$20s: %2$s\n", "wlbUrl", this.wlbUrl);
            print.printf("%1$20s: %2$s\n", "wlbUsername", this.wlbUsername);
            print.printf("%1$20s: %2$s\n", "wlbEnabled", this.wlbEnabled);
            print.printf("%1$20s: %2$s\n", "wlbVerifyCert", this.wlbVerifyCert);
            print.printf("%1$20s: %2$s\n", "redoLogEnabled", this.redoLogEnabled);
            print.printf("%1$20s: %2$s\n", "redoLogVdi", this.redoLogVdi);
            print.printf("%1$20s: %2$s\n", "vswitchController", this.vswitchController);
            print.printf("%1$20s: %2$s\n", "restrictions", this.restrictions);
            print.printf("%1$20s: %2$s\n", "metadataVDIs", this.metadataVDIs);
            print.printf("%1$20s: %2$s\n", "haClusterStack", this.haClusterStack);
            print.printf("%1$20s: %2$s\n", "allowedOperations", this.allowedOperations);
            print.printf("%1$20s: %2$s\n", "currentOperations", this.currentOperations);
            print.printf("%1$20s: %2$s\n", "guestAgentConfig", this.guestAgentConfig);
            print.printf("%1$20s: %2$s\n", "cpuInfo", this.cpuInfo);
            print.printf("%1$20s: %2$s\n", "policyNoVendorDevice", this.policyNoVendorDevice);
            print.printf("%1$20s: %2$s\n", "livePatchingDisabled", this.livePatchingDisabled);
            print.printf("%1$20s: %2$s\n", "igmpSnoopingEnabled", this.igmpSnoopingEnabled);
            print.printf("%1$20s: %2$s\n", "uefiCertificates", this.uefiCertificates);
            print.printf("%1$20s: %2$s\n", "customUefiCertificates", this.customUefiCertificates);
            print.printf("%1$20s: %2$s\n", "isPsrPending", this.isPsrPending);
            print.printf("%1$20s: %2$s\n", "tlsVerificationEnabled", this.tlsVerificationEnabled);
            print.printf("%1$20s: %2$s\n", "repositories", this.repositories);
            print.printf("%1$20s: %2$s\n", "clientCertificateAuthEnabled", this.clientCertificateAuthEnabled);
            print.printf("%1$20s: %2$s\n", "clientCertificateAuthName", this.clientCertificateAuthName);
            print.printf("%1$20s: %2$s\n", "repositoryProxyUrl", this.repositoryProxyUrl);
            print.printf("%1$20s: %2$s\n", "repositoryProxyUsername", this.repositoryProxyUsername);
            print.printf("%1$20s: %2$s\n", "repositoryProxyPassword", this.repositoryProxyPassword);
            print.printf("%1$20s: %2$s\n", "migrationCompression", this.migrationCompression);
            print.printf("%1$20s: %2$s\n", "coordinatorBias", this.coordinatorBias);
            print.printf("%1$20s: %2$s\n", "localAuthMaxThreads", this.localAuthMaxThreads);
            print.printf("%1$20s: %2$s\n", "extAuthMaxThreads", this.extAuthMaxThreads);
            print.printf("%1$20s: %2$s\n", "extAuthCacheEnabled", this.extAuthCacheEnabled);
            print.printf("%1$20s: %2$s\n", "extAuthCacheSize", this.extAuthCacheSize);
            print.printf("%1$20s: %2$s\n", "extAuthCacheExpiry", this.extAuthCacheExpiry);
            print.printf("%1$20s: %2$s\n", "telemetryUuid", this.telemetryUuid);
            print.printf("%1$20s: %2$s\n", "telemetryFrequency", this.telemetryFrequency);
            print.printf("%1$20s: %2$s\n", "telemetryNextCollection", this.telemetryNextCollection);
            print.printf("%1$20s: %2$s\n", "lastUpdateSync", this.lastUpdateSync);
            print.printf("%1$20s: %2$s\n", "updateSyncFrequency", this.updateSyncFrequency);
            print.printf("%1$20s: %2$s\n", "updateSyncDay", this.updateSyncDay);
            print.printf("%1$20s: %2$s\n", "updateSyncEnabled", this.updateSyncEnabled);
            print.printf("%1$20s: %2$s\n", "recommendations", this.recommendations);
            print.printf("%1$20s: %2$s\n", "licenseServer", this.licenseServer);
            print.printf("%1$20s: %2$s\n", "haRebootVmOnInternalShutdown", this.haRebootVmOnInternalShutdown);
            return writer.toString();
        }

        /**
         * Convert a Pool.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("master", this.master == null ? new Host("OpaqueRef:NULL") : this.master);
            map.put("default_SR", this.defaultSR == null ? new SR("OpaqueRef:NULL") : this.defaultSR);
            map.put("suspend_image_SR", this.suspendImageSR == null ? new SR("OpaqueRef:NULL") : this.suspendImageSR);
            map.put("crash_dump_SR", this.crashDumpSR == null ? new SR("OpaqueRef:NULL") : this.crashDumpSR);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("ha_enabled", this.haEnabled == null ? false : this.haEnabled);
            map.put("ha_configuration", this.haConfiguration == null ? new HashMap<String, String>() : this.haConfiguration);
            map.put("ha_statefiles", this.haStatefiles == null ? new LinkedHashSet<String>() : this.haStatefiles);
            map.put("ha_host_failures_to_tolerate", this.haHostFailuresToTolerate == null ? 0 : this.haHostFailuresToTolerate);
            map.put("ha_plan_exists_for", this.haPlanExistsFor == null ? 0 : this.haPlanExistsFor);
            map.put("ha_allow_overcommit", this.haAllowOvercommit == null ? false : this.haAllowOvercommit);
            map.put("ha_overcommitted", this.haOvercommitted == null ? false : this.haOvercommitted);
            map.put("blobs", this.blobs == null ? new HashMap<String, Blob>() : this.blobs);
            map.put("tags", this.tags == null ? new LinkedHashSet<String>() : this.tags);
            map.put("gui_config", this.guiConfig == null ? new HashMap<String, String>() : this.guiConfig);
            map.put("health_check_config", this.healthCheckConfig == null ? new HashMap<String, String>() : this.healthCheckConfig);
            map.put("wlb_url", this.wlbUrl == null ? "" : this.wlbUrl);
            map.put("wlb_username", this.wlbUsername == null ? "" : this.wlbUsername);
            map.put("wlb_enabled", this.wlbEnabled == null ? false : this.wlbEnabled);
            map.put("wlb_verify_cert", this.wlbVerifyCert == null ? false : this.wlbVerifyCert);
            map.put("redo_log_enabled", this.redoLogEnabled == null ? false : this.redoLogEnabled);
            map.put("redo_log_vdi", this.redoLogVdi == null ? new VDI("OpaqueRef:NULL") : this.redoLogVdi);
            map.put("vswitch_controller", this.vswitchController == null ? "" : this.vswitchController);
            map.put("restrictions", this.restrictions == null ? new HashMap<String, String>() : this.restrictions);
            map.put("metadata_VDIs", this.metadataVDIs == null ? new LinkedHashSet<VDI>() : this.metadataVDIs);
            map.put("ha_cluster_stack", this.haClusterStack == null ? "" : this.haClusterStack);
            map.put("allowed_operations", this.allowedOperations == null ? new LinkedHashSet<Types.PoolAllowedOperations>() : this.allowedOperations);
            map.put("current_operations", this.currentOperations == null ? new HashMap<String, Types.PoolAllowedOperations>() : this.currentOperations);
            map.put("guest_agent_config", this.guestAgentConfig == null ? new HashMap<String, String>() : this.guestAgentConfig);
            map.put("cpu_info", this.cpuInfo == null ? new HashMap<String, String>() : this.cpuInfo);
            map.put("policy_no_vendor_device", this.policyNoVendorDevice == null ? false : this.policyNoVendorDevice);
            map.put("live_patching_disabled", this.livePatchingDisabled == null ? false : this.livePatchingDisabled);
            map.put("igmp_snooping_enabled", this.igmpSnoopingEnabled == null ? false : this.igmpSnoopingEnabled);
            map.put("uefi_certificates", this.uefiCertificates == null ? "" : this.uefiCertificates);
            map.put("custom_uefi_certificates", this.customUefiCertificates == null ? "" : this.customUefiCertificates);
            map.put("is_psr_pending", this.isPsrPending == null ? false : this.isPsrPending);
            map.put("tls_verification_enabled", this.tlsVerificationEnabled == null ? false : this.tlsVerificationEnabled);
            map.put("repositories", this.repositories == null ? new LinkedHashSet<Repository>() : this.repositories);
            map.put("client_certificate_auth_enabled", this.clientCertificateAuthEnabled == null ? false : this.clientCertificateAuthEnabled);
            map.put("client_certificate_auth_name", this.clientCertificateAuthName == null ? "" : this.clientCertificateAuthName);
            map.put("repository_proxy_url", this.repositoryProxyUrl == null ? "" : this.repositoryProxyUrl);
            map.put("repository_proxy_username", this.repositoryProxyUsername == null ? "" : this.repositoryProxyUsername);
            map.put("repository_proxy_password", this.repositoryProxyPassword == null ? new Secret("OpaqueRef:NULL") : this.repositoryProxyPassword);
            map.put("migration_compression", this.migrationCompression == null ? false : this.migrationCompression);
            map.put("coordinator_bias", this.coordinatorBias == null ? false : this.coordinatorBias);
            map.put("local_auth_max_threads", this.localAuthMaxThreads == null ? 0 : this.localAuthMaxThreads);
            map.put("ext_auth_max_threads", this.extAuthMaxThreads == null ? 0 : this.extAuthMaxThreads);
            map.put("ext_auth_cache_enabled", this.extAuthCacheEnabled == null ? false : this.extAuthCacheEnabled);
            map.put("ext_auth_cache_size", this.extAuthCacheSize == null ? 0 : this.extAuthCacheSize);
            map.put("ext_auth_cache_expiry", this.extAuthCacheExpiry == null ? 0 : this.extAuthCacheExpiry);
            map.put("telemetry_uuid", this.telemetryUuid == null ? new Secret("OpaqueRef:NULL") : this.telemetryUuid);
            map.put("telemetry_frequency", this.telemetryFrequency == null ? Types.TelemetryFrequency.UNRECOGNIZED : this.telemetryFrequency);
            map.put("telemetry_next_collection", this.telemetryNextCollection == null ? new Date(0) : this.telemetryNextCollection);
            map.put("last_update_sync", this.lastUpdateSync == null ? new Date(0) : this.lastUpdateSync);
            map.put("update_sync_frequency", this.updateSyncFrequency == null ? Types.UpdateSyncFrequency.UNRECOGNIZED : this.updateSyncFrequency);
            map.put("update_sync_day", this.updateSyncDay == null ? 0 : this.updateSyncDay);
            map.put("update_sync_enabled", this.updateSyncEnabled == null ? false : this.updateSyncEnabled);
            map.put("recommendations", this.recommendations == null ? new HashMap<String, String>() : this.recommendations);
            map.put("license_server", this.licenseServer == null ? new HashMap<String, String>() : this.licenseServer);
            map.put("ha_reboot_vm_on_internal_shutdown", this.haRebootVmOnInternalShutdown == null ? false : this.haRebootVmOnInternalShutdown);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * Short name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * Description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * The host that is pool master
         */
        @JsonProperty("master")
        public Host master;

        /**
         * Default SR for VDIs
         */
        @JsonProperty("default_SR")
        public SR defaultSR;

        /**
         * The SR in which VDIs for suspend images are created
         */
        @JsonProperty("suspend_image_SR")
        public SR suspendImageSR;

        /**
         * The SR in which VDIs for crash dumps are created
         */
        @JsonProperty("crash_dump_SR")
        public SR crashDumpSR;

        /**
         * additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * true if HA is enabled on the pool, false otherwise
         * First published in XenServer 5.0.
         */
        @JsonProperty("ha_enabled")
        public Boolean haEnabled;

        /**
         * The current HA configuration
         * First published in XenServer 5.0.
         */
        @JsonProperty("ha_configuration")
        public Map<String, String> haConfiguration;

        /**
         * HA statefile VDIs in use
         * First published in XenServer 5.0.
         */
        @JsonProperty("ha_statefiles")
        public Set<String> haStatefiles;

        /**
         * Number of host failures to tolerate before the Pool is declared to be overcommitted
         * First published in XenServer 5.0.
         */
        @JsonProperty("ha_host_failures_to_tolerate")
        public Long haHostFailuresToTolerate;

        /**
         * Number of future host failures we have managed to find a plan for. Once this reaches zero any future host failures will cause the failure of protected VMs.
         * First published in XenServer 5.0.
         */
        @JsonProperty("ha_plan_exists_for")
        public Long haPlanExistsFor;

        /**
         * If set to false then operations which would cause the Pool to become overcommitted will be blocked.
         * First published in XenServer 5.0.
         */
        @JsonProperty("ha_allow_overcommit")
        public Boolean haAllowOvercommit;

        /**
         * True if the Pool is considered to be overcommitted i.e. if there exist insufficient physical resources to tolerate the configured number of host failures
         * First published in XenServer 5.0.
         */
        @JsonProperty("ha_overcommitted")
        public Boolean haOvercommitted;

        /**
         * Binary blobs associated with this pool
         * First published in XenServer 5.0.
         */
        @JsonProperty("blobs")
        public Map<String, Blob> blobs;

        /**
         * user-specified tags for categorization purposes
         * First published in XenServer 5.0.
         */
        @JsonProperty("tags")
        public Set<String> tags;

        /**
         * gui-specific configuration for pool
         * First published in XenServer 5.0.
         */
        @JsonProperty("gui_config")
        public Map<String, String> guiConfig;

        /**
         * Configuration for the automatic health check feature
         * First published in XenServer 7.0.
         */
        @JsonProperty("health_check_config")
        public Map<String, String> healthCheckConfig;

        /**
         * Url for the configured workload balancing host
         * First published in XenServer 5.5.
         */
        @JsonProperty("wlb_url")
        public String wlbUrl;

        /**
         * Username for accessing the workload balancing host
         * First published in XenServer 5.5.
         */
        @JsonProperty("wlb_username")
        public String wlbUsername;

        /**
         * true if workload balancing is enabled on the pool, false otherwise
         * First published in XenServer 5.5.
         */
        @JsonProperty("wlb_enabled")
        public Boolean wlbEnabled;

        /**
         * true if communication with the WLB server should enforce TLS certificate verification.
         * First published in XenServer 5.5.
         */
        @JsonProperty("wlb_verify_cert")
        @Deprecated(since = "XenServer 5.5")
        public Boolean wlbVerifyCert;

        /**
         * true a redo-log is to be used other than when HA is enabled, false otherwise
         * First published in XenServer 5.6.
         */
        @JsonProperty("redo_log_enabled")
        public Boolean redoLogEnabled;

        /**
         * indicates the VDI to use for the redo-log other than when HA is enabled
         * First published in XenServer 5.6.
         */
        @JsonProperty("redo_log_vdi")
        public VDI redoLogVdi;

        /**
         * address of the vswitch controller
         * First published in XenServer 5.6.
         */
        @JsonProperty("vswitch_controller")
        @Deprecated(since = "XenServer 5.6")
        public String vswitchController;

        /**
         * Pool-wide restrictions currently in effect
         * First published in XenServer 5.6.
         */
        @JsonProperty("restrictions")
        public Map<String, String> restrictions;

        /**
         * The set of currently known metadata VDIs for this pool
         * First published in XenServer 6.0.
         */
        @JsonProperty("metadata_VDIs")
        public Set<VDI> metadataVDIs;

        /**
         * The HA cluster stack that is currently in use. Only valid when HA is enabled.
         * First published in XenServer 7.0.
         */
        @JsonProperty("ha_cluster_stack")
        public String haClusterStack;

        /**
         * list of the operations allowed in this state. This list is advisory only and the server state may have changed by the time this field is read by a client.
         */
        @JsonProperty("allowed_operations")
        public Set<Types.PoolAllowedOperations> allowedOperations;

        /**
         * links each of the running tasks using this object (by reference) to a current_operation enum which describes the nature of the task.
         */
        @JsonProperty("current_operations")
        public Map<String, Types.PoolAllowedOperations> currentOperations;

        /**
         * Pool-wide guest agent configuration information
         * First published in XenServer 7.0.
         */
        @JsonProperty("guest_agent_config")
        public Map<String, String> guestAgentConfig;

        /**
         * Details about the physical CPUs on the pool
         * First published in XenServer 7.0.
         */
        @JsonProperty("cpu_info")
        public Map<String, String> cpuInfo;

        /**
         * This field was consulted when VM.create did not specify a value for 'has_vendor_device'; VM.create now uses a simple default and no longer consults this value.
         * First published in XenServer 7.0.
         */
        @JsonProperty("policy_no_vendor_device")
        @Deprecated(since = "XenServer 7.0")
        public Boolean policyNoVendorDevice;

        /**
         * The pool-wide flag to show if the live patching feauture is disabled or not.
         * First published in XenServer 7.1.
         */
        @JsonProperty("live_patching_disabled")
        public Boolean livePatchingDisabled;

        /**
         * true if IGMP snooping is enabled in the pool, false otherwise.
         * First published in XenServer 7.3.
         */
        @JsonProperty("igmp_snooping_enabled")
        public Boolean igmpSnoopingEnabled;

        /**
         * The UEFI certificates allowing Secure Boot
         * First published in Citrix Hypervisor 8.1.
         */
        @JsonProperty("uefi_certificates")
        public String uefiCertificates;

        /**
         * Custom UEFI certificates allowing Secure Boot
         * Experimental. First published in 24.0.0.
         */
        @JsonProperty("custom_uefi_certificates")
        public String customUefiCertificates;

        /**
         * True if either a PSR is running or we are waiting for a PSR to be re-run
         * First published in Citrix Hypervisor 8.2 Hotfix 2.
         */
        @JsonProperty("is_psr_pending")
        public Boolean isPsrPending;

        /**
         * True iff TLS certificate verification is enabled
         * First published in 1.290.0.
         */
        @JsonProperty("tls_verification_enabled")
        public Boolean tlsVerificationEnabled;

        /**
         * The set of currently enabled repositories
         * First published in 1.301.0.
         */
        @JsonProperty("repositories")
        public Set<Repository> repositories;

        /**
         * True if authentication by TLS client certificates is enabled
         * First published in 1.318.0.
         */
        @JsonProperty("client_certificate_auth_enabled")
        public Boolean clientCertificateAuthEnabled;

        /**
         * The name (CN/SAN) that an incoming client certificate must have to allow authentication
         * First published in 1.318.0.
         */
        @JsonProperty("client_certificate_auth_name")
        public String clientCertificateAuthName;

        /**
         * Url of the proxy used in syncing with the enabled repositories
         * First published in 21.3.0.
         */
        @JsonProperty("repository_proxy_url")
        public String repositoryProxyUrl;

        /**
         * Username for the authentication of the proxy used in syncing with the enabled repositories
         * First published in 21.3.0.
         */
        @JsonProperty("repository_proxy_username")
        public String repositoryProxyUsername;

        /**
         * Password for the authentication of the proxy used in syncing with the enabled repositories
         * First published in 21.3.0.
         */
        @JsonProperty("repository_proxy_password")
        public Secret repositoryProxyPassword;

        /**
         * Default behaviour during migration, True if stream compression should be used
         * Experimental. First published in 22.33.0.
         */
        @JsonProperty("migration_compression")
        public Boolean migrationCompression;

        /**
         * true if bias against pool master when scheduling vms is enabled, false otherwise
         */
        @JsonProperty("coordinator_bias")
        public Boolean coordinatorBias;

        /**
         * Maximum number of threads to use for PAM authentication
         * Experimental. First published in 23.27.0.
         */
        @JsonProperty("local_auth_max_threads")
        public Long localAuthMaxThreads;

        /**
         * Maximum number of threads to use for external (AD) authentication
         * Experimental. First published in 23.27.0.
         */
        @JsonProperty("ext_auth_max_threads")
        public Long extAuthMaxThreads;

        /**
         * Specifies whether external authentication caching is enabled for this pool or not
         * Experimental. First published in 24.31.0.
         */
        @JsonProperty("ext_auth_cache_enabled")
        public Boolean extAuthCacheEnabled;

        /**
         * Maximum capacity of external authentication cache
         * Experimental. First published in 24.31.0.
         */
        @JsonProperty("ext_auth_cache_size")
        public Long extAuthCacheSize;

        /**
         * Specifies how long external authentication entries should be cached for (seconds)
         * Experimental. First published in 24.31.0.
         */
        @JsonProperty("ext_auth_cache_expiry")
        public Long extAuthCacheExpiry;

        /**
         * The UUID of the pool for identification of telemetry data
         * Experimental. First published in 23.9.0.
         */
        @JsonProperty("telemetry_uuid")
        public Secret telemetryUuid;

        /**
         * How often the telemetry collection will be carried out
         * Experimental. First published in 23.9.0.
         */
        @JsonProperty("telemetry_frequency")
        public Types.TelemetryFrequency telemetryFrequency;

        /**
         * The earliest timestamp (in UTC) when the next round of telemetry collection can be carried out
         * Experimental. First published in 23.9.0.
         */
        @JsonProperty("telemetry_next_collection")
        public Date telemetryNextCollection;

        /**
         * time of the last update sychronization
         * Experimental. First published in 23.18.0.
         */
        @JsonProperty("last_update_sync")
        public Date lastUpdateSync;

        /**
         * The frequency at which updates are synchronized from a remote CDN: daily or weekly.
         * Experimental. First published in 23.18.0.
         */
        @JsonProperty("update_sync_frequency")
        public Types.UpdateSyncFrequency updateSyncFrequency;

        /**
         * The day of the week the update synchronizations will be scheduled, based on pool's local timezone. Ignored when update_sync_frequency is daily
         * Experimental. First published in 23.18.0.
         */
        @JsonProperty("update_sync_day")
        public Long updateSyncDay;

        /**
         * Whether periodic update synchronization is enabled or not
         * Experimental. First published in 23.18.0.
         */
        @JsonProperty("update_sync_enabled")
        public Boolean updateSyncEnabled;

        /**
         * The recommended pool properties for clients to respect for optimal performance. e.g. max-vm-group=5
         * Experimental. First published in 24.19.1.
         */
        @JsonProperty("recommendations")
        public Map<String, String> recommendations;

        /**
         * Licensing data shared within the whole pool
         * Experimental. First published in 25.6.0.
         */
        @JsonProperty("license_server")
        public Map<String, String> licenseServer;

        /**
         * Indicates whether an HA-protected VM that is shut down from inside (not through the API) should be automatically rebooted when HA is enabled
         * Experimental. First published in 25.16.0.
         */
        @JsonProperty("ha_reboot_vm_on_internal_shutdown")
        public Boolean haRebootVmOnInternalShutdown;

    }

    /**
     * Get a record containing the current state of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Pool.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Pool.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the pool instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Pool getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<Pool>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name_label field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name_description field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the master field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getMaster(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_master";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the default_SR field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public SR getDefaultSR(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_default_SR";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the suspend_image_SR field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public SR getSuspendImageSR(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_suspend_image_SR";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the crash_dump_SR field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public SR getCrashDumpSR(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_crash_dump_SR";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_enabled field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getHaEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ha_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_configuration field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getHaConfiguration(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ha_configuration";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_statefiles field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getHaStatefiles(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ha_statefiles";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_host_failures_to_tolerate field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getHaHostFailuresToTolerate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ha_host_failures_to_tolerate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_plan_exists_for field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getHaPlanExistsFor(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ha_plan_exists_for";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_allow_overcommit field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getHaAllowOvercommit(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ha_allow_overcommit";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_overcommitted field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getHaOvercommitted(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ha_overcommitted";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the blobs field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Blob> getBlobs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_blobs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Blob>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the tags field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getTags(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the gui_config field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getGuiConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_gui_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the health_check_config field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getHealthCheckConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_health_check_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the wlb_url field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getWlbUrl(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_wlb_url";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the wlb_username field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getWlbUsername(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_wlb_username";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the wlb_enabled field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getWlbEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_wlb_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the wlb_verify_cert field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     * @deprecated since 1.290.0
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "1.290.0")
    public Boolean getWlbVerifyCert(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_wlb_verify_cert";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the redo_log_enabled field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getRedoLogEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_redo_log_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the redo_log_vdi field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VDI getRedoLogVdi(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_redo_log_vdi";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the vswitch_controller field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     * @deprecated since XenServer 7.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.2")
    public String getVswitchController(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_vswitch_controller";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the restrictions field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getRestrictions(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_restrictions";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the metadata_VDIs field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VDI> getMetadataVDIs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_metadata_VDIs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VDI>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_cluster_stack field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getHaClusterStack(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ha_cluster_stack";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allowed_operations field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.PoolAllowedOperations> getAllowedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.PoolAllowedOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the current_operations field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Types.PoolAllowedOperations> getCurrentOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_current_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Types.PoolAllowedOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the guest_agent_config field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getGuestAgentConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_guest_agent_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the cpu_info field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getCpuInfo(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_cpu_info";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the policy_no_vendor_device field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     * @deprecated since 24.14.0
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "24.14.0")
    public Boolean getPolicyNoVendorDevice(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_policy_no_vendor_device";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the live_patching_disabled field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getLivePatchingDisabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_live_patching_disabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the igmp_snooping_enabled field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIgmpSnoopingEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_igmp_snooping_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uefi_certificates field of the given pool.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUefiCertificates(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_uefi_certificates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the custom_uefi_certificates field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.0.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getCustomUefiCertificates(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_custom_uefi_certificates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_psr_pending field of the given pool.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.2 Hotfix 2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsPsrPending(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_is_psr_pending";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the tls_verification_enabled field of the given pool.
     * Minimum allowed role: read-only
     * First published in 1.290.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getTlsVerificationEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_tls_verification_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the repositories field of the given pool.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Repository> getRepositories(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_repositories";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Repository>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the client_certificate_auth_enabled field of the given pool.
     * Minimum allowed role: read-only
     * First published in 1.318.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getClientCertificateAuthEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_client_certificate_auth_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the client_certificate_auth_name field of the given pool.
     * Minimum allowed role: read-only
     * First published in 1.318.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getClientCertificateAuthName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_client_certificate_auth_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the repository_proxy_url field of the given pool.
     * Minimum allowed role: read-only
     * First published in 21.3.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getRepositoryProxyUrl(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_repository_proxy_url";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the repository_proxy_username field of the given pool.
     * Minimum allowed role: read-only
     * First published in 21.3.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getRepositoryProxyUsername(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_repository_proxy_username";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the repository_proxy_password field of the given pool.
     * Minimum allowed role: read-only
     * First published in 21.3.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Secret getRepositoryProxyPassword(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_repository_proxy_password";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Secret>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the migration_compression field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 22.33.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getMigrationCompression(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_migration_compression";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the coordinator_bias field of the given pool.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getCoordinatorBias(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_coordinator_bias";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the local_auth_max_threads field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.27.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getLocalAuthMaxThreads(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_local_auth_max_threads";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ext_auth_max_threads field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.27.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getExtAuthMaxThreads(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ext_auth_max_threads";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ext_auth_cache_enabled field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.31.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getExtAuthCacheEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ext_auth_cache_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ext_auth_cache_size field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.31.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getExtAuthCacheSize(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ext_auth_cache_size";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ext_auth_cache_expiry field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.31.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getExtAuthCacheExpiry(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ext_auth_cache_expiry";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the telemetry_uuid field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.9.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Secret getTelemetryUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_telemetry_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Secret>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the telemetry_frequency field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.9.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.TelemetryFrequency getTelemetryFrequency(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_telemetry_frequency";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.TelemetryFrequency>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the telemetry_next_collection field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.9.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getTelemetryNextCollection(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_telemetry_next_collection";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the last_update_sync field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.18.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getLastUpdateSync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_last_update_sync";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the update_sync_frequency field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.18.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.UpdateSyncFrequency getUpdateSyncFrequency(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_update_sync_frequency";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.UpdateSyncFrequency>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the update_sync_day field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.18.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getUpdateSyncDay(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_update_sync_day";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the update_sync_enabled field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.18.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getUpdateSyncEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_update_sync_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the recommendations field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getRecommendations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_recommendations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the license_server field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getLicenseServer(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_license_server";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_reboot_vm_on_internal_shutdown field of the given pool.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.16.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getHaRebootVmOnInternalShutdown(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_ha_reboot_vm_on_internal_shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name_label field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param nameLabel New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameLabel(Connection c, String nameLabel) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, nameLabel };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name_description field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param nameDescription New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameDescription(Connection c, String nameDescription) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, nameDescription };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the default_SR field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param defaultSR New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setDefaultSR(Connection c, SR defaultSR) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_default_SR";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, defaultSR };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the suspend_image_SR field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param suspendImageSR New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSuspendImageSR(Connection c, SR suspendImageSR) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_suspend_image_SR";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, suspendImageSR };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the crash_dump_SR field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param crashDumpSR New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setCrashDumpSR(Connection c, SR crashDumpSR) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_crash_dump_SR";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, crashDumpSR };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the other_config field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given pool.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the ha_allow_overcommit field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param haAllowOvercommit New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHaAllowOvercommit(Connection c, Boolean haAllowOvercommit) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_ha_allow_overcommit";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, haAllowOvercommit };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the tags field of the given pool.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param tags New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setTags(Connection c, Set<String> tags) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, tags };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given value to the tags field of the given pool.  If the value is already in that Set, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value New value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addTags(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.add_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given value from the tags field of the given pool.  If the value is not in that Set, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value Value to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeTags(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.remove_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the gui_config field of the given pool.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param guiConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setGuiConfig(Connection c, Map<String, String> guiConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_gui_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, guiConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the gui_config field of the given pool.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToGuiConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.add_to_gui_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the gui_config field of the given pool.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromGuiConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.remove_from_gui_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the health_check_config field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param healthCheckConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHealthCheckConfig(Connection c, Map<String, String> healthCheckConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_health_check_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, healthCheckConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the health_check_config field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToHealthCheckConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.add_to_health_check_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the health_check_config field of the given pool.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromHealthCheckConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.remove_from_health_check_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the wlb_enabled field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param wlbEnabled New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setWlbEnabled(Connection c, Boolean wlbEnabled) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_wlb_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, wlbEnabled };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the wlb_verify_cert field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     * @deprecated since 1.290.0
     *
     * @param c The connection the call is made on
     * @param wlbVerifyCert New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "1.290.0")
    public void setWlbVerifyCert(Connection c, Boolean wlbVerifyCert) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_wlb_verify_cert";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, wlbVerifyCert };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the policy_no_vendor_device field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     * @deprecated since 24.14.0
     *
     * @param c The connection the call is made on
     * @param policyNoVendorDevice New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "24.14.0")
    public void setPolicyNoVendorDevice(Connection c, Boolean policyNoVendorDevice) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_policy_no_vendor_device";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, policyNoVendorDevice };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the live_patching_disabled field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param livePatchingDisabled New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setLivePatchingDisabled(Connection c, Boolean livePatchingDisabled) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_live_patching_disabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, livePatchingDisabled };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the is_psr_pending field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in Citrix Hypervisor 8.2 Hotfix 2.
     *
     * @param c The connection the call is made on
     * @param isPsrPending New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setIsPsrPending(Connection c, Boolean isPsrPending) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_is_psr_pending";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, isPsrPending };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the migration_compression field of the given pool.
     * Minimum allowed role: pool-operator
     * Experimental. First published in 22.33.0.
     *
     * @param c The connection the call is made on
     * @param migrationCompression New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setMigrationCompression(Connection c, Boolean migrationCompression) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_migration_compression";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, migrationCompression };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the coordinator_bias field of the given pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param coordinatorBias New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setCoordinatorBias(Connection c, Boolean coordinatorBias) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_coordinator_bias";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, coordinatorBias };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the license_server field of the given pool.
     * Minimum allowed role: pool-operator
     * Experimental. First published in 25.6.0.
     *
     * @param c The connection the call is made on
     * @param licenseServer New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setLicenseServer(Connection c, Map<String, String> licenseServer) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_license_server";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, licenseServer };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the license_server field of the given pool.
     * Minimum allowed role: pool-operator
     * Experimental. First published in 25.6.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToLicenseServer(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.add_to_license_server";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the license_server field of the given pool.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * Experimental. First published in 25.6.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromLicenseServer(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.remove_from_license_server";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the ha_reboot_vm_on_internal_shutdown field of the given pool.
     * Minimum allowed role: pool-operator
     * Experimental. First published in 25.16.0.
     *
     * @param c The connection the call is made on
     * @param haRebootVmOnInternalShutdown New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHaRebootVmOnInternalShutdown(Connection c, Boolean haRebootVmOnInternalShutdown) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_ha_reboot_vm_on_internal_shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, haRebootVmOnInternalShutdown };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Instruct host to join a new pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param masterAddress The hostname of the master of the pool to join 
     * @param masterUsername The username of the master (for initial authentication) 
     * @param masterPassword The password for the master (for initial authentication) 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.JoiningHostCannotContainSharedSrs The server joining the pool cannot contain any shared storage.
     */
    public static void join(Connection c, String masterAddress, String masterUsername, String masterPassword) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.JoiningHostCannotContainSharedSrs {
        String methodCall = "pool.join";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, masterAddress, masterUsername, masterPassword };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Instruct host to join a new pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param masterAddress The hostname of the master of the pool to join 
     * @param masterUsername The username of the master (for initial authentication) 
     * @param masterPassword The password for the master (for initial authentication) 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.JoiningHostCannotContainSharedSrs The server joining the pool cannot contain any shared storage.
     */
    public static Task joinAsync(Connection c, String masterAddress, String masterUsername, String masterPassword) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.JoiningHostCannotContainSharedSrs {
        String methodCall = "Async.pool.join";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, masterAddress, masterUsername, masterPassword };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Instruct host to join a new pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param masterAddress The hostname of the master of the pool to join 
     * @param masterUsername The username of the master (for initial authentication) 
     * @param masterPassword The password for the master (for initial authentication) 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void joinForce(Connection c, String masterAddress, String masterUsername, String masterPassword) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.join_force";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, masterAddress, masterUsername, masterPassword };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Instruct host to join a new pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param masterAddress The hostname of the master of the pool to join 
     * @param masterUsername The username of the master (for initial authentication) 
     * @param masterPassword The password for the master (for initial authentication) 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task joinForceAsync(Connection c, String masterAddress, String masterUsername, String masterPassword) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.join_force";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, masterAddress, masterUsername, masterPassword };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Instruct a pool master to eject a host from the pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The host to eject 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void eject(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.eject";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Instruct a pool master to eject a host from the pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The host to eject 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task ejectAsync(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.eject";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Instruct host that's currently a slave to transition to being master
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void emergencyTransitionToMaster(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.emergency_transition_to_master";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Instruct a slave already in a pool that the master has changed
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param masterAddress The hostname of the master 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void emergencyResetMaster(Connection c, String masterAddress) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.emergency_reset_master";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, masterAddress };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Instruct a pool master, M, to try and contact its slaves and, if slaves are in emergency mode, reset their master address to M.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return list of hosts whose master address were successfully reset
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Host> recoverSlaves(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.recover_slaves";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<Host>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Instruct a pool master, M, to try and contact its slaves and, if slaves are in emergency mode, reset their master address to M.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task recoverSlavesAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.recover_slaves";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create PIFs, mapping a network to the same physical interface/VLAN on each host. This call is deprecated: use Pool.create_VLAN_from_PIF instead.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param device physical interface on which to create the VLAN interface 
     * @param network network to which this interface should be connected 
     * @param VLAN VLAN tag for the new interface 
     * @return The references of the created PIF objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VlanTagInvalid You tried to create a VLAN, but the tag you gave was invalid -- it must be between 0 and 4094. The parameter echoes the VLAN tag you gave.
     */
    public static Set<PIF> createVLAN(Connection c, String device, Network network, Long VLAN) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VlanTagInvalid {
        String methodCall = "pool.create_VLAN";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, device, network, VLAN };
        var typeReference = new TypeReference<Set<PIF>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create PIFs, mapping a network to the same physical interface/VLAN on each host. This call is deprecated: use Pool.create_VLAN_from_PIF instead.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param device physical interface on which to create the VLAN interface 
     * @param network network to which this interface should be connected 
     * @param VLAN VLAN tag for the new interface 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VlanTagInvalid You tried to create a VLAN, but the tag you gave was invalid -- it must be between 0 and 4094. The parameter echoes the VLAN tag you gave.
     */
    public static Task createVLANAsync(Connection c, String device, Network network, Long VLAN) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VlanTagInvalid {
        String methodCall = "Async.pool.create_VLAN";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, device, network, VLAN };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Reconfigure the management network interface for all Hosts in the Pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @param network The network 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.HaIsEnabled The operation could not be performed because HA is enabled on the Pool
     * @throws Types.PifNotPresent This host has no PIF on the given network.
     * @throws Types.CannotPlugBondSlave This PIF is a bond member and cannot be plugged.
     * @throws Types.PifIncompatiblePrimaryAddressType The primary address types are not compatible
     * @throws Types.PifHasNoNetworkConfiguration PIF has no IP configuration (mode currently set to 'none')
     * @throws Types.PifHasNoV6NetworkConfiguration PIF has no IPv6 configuration (mode currently set to 'none')
     */
    public static void managementReconfigure(Connection c, Network network) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.HaIsEnabled,
    Types.PifNotPresent,
    Types.CannotPlugBondSlave,
    Types.PifIncompatiblePrimaryAddressType,
    Types.PifHasNoNetworkConfiguration,
    Types.PifHasNoV6NetworkConfiguration {
        String methodCall = "pool.management_reconfigure";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, network };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Reconfigure the management network interface for all Hosts in the Pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @param network The network 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.HaIsEnabled The operation could not be performed because HA is enabled on the Pool
     * @throws Types.PifNotPresent This host has no PIF on the given network.
     * @throws Types.CannotPlugBondSlave This PIF is a bond member and cannot be plugged.
     * @throws Types.PifIncompatiblePrimaryAddressType The primary address types are not compatible
     * @throws Types.PifHasNoNetworkConfiguration PIF has no IP configuration (mode currently set to 'none')
     * @throws Types.PifHasNoV6NetworkConfiguration PIF has no IPv6 configuration (mode currently set to 'none')
     */
    public static Task managementReconfigureAsync(Connection c, Network network) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.HaIsEnabled,
    Types.PifNotPresent,
    Types.CannotPlugBondSlave,
    Types.PifIncompatiblePrimaryAddressType,
    Types.PifHasNoNetworkConfiguration,
    Types.PifHasNoV6NetworkConfiguration {
        String methodCall = "Async.pool.management_reconfigure";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, network };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a pool-wide VLAN by taking the PIF.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param pif physical interface on any particular host, that identifies the PIF on which to create the (pool-wide) VLAN interface 
     * @param network network to which this interface should be connected 
     * @param VLAN VLAN tag for the new interface 
     * @return The references of the created PIF objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VlanTagInvalid You tried to create a VLAN, but the tag you gave was invalid -- it must be between 0 and 4094. The parameter echoes the VLAN tag you gave.
     */
    public static Set<PIF> createVLANFromPIF(Connection c, PIF pif, Network network, Long VLAN) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VlanTagInvalid {
        String methodCall = "pool.create_VLAN_from_PIF";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, pif, network, VLAN };
        var typeReference = new TypeReference<Set<PIF>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a pool-wide VLAN by taking the PIF.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param pif physical interface on any particular host, that identifies the PIF on which to create the (pool-wide) VLAN interface 
     * @param network network to which this interface should be connected 
     * @param VLAN VLAN tag for the new interface 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VlanTagInvalid You tried to create a VLAN, but the tag you gave was invalid -- it must be between 0 and 4094. The parameter echoes the VLAN tag you gave.
     */
    public static Task createVLANFromPIFAsync(Connection c, PIF pif, Network network, Long VLAN) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VlanTagInvalid {
        String methodCall = "Async.pool.create_VLAN_from_PIF";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, pif, network, VLAN };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Turn on High Availability mode
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param heartbeatSrs Set of SRs to use for storage heartbeating 
     * @param configuration Detailed HA configuration to apply 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void enableHa(Connection c, Set<SR> heartbeatSrs, Map<String, String> configuration) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.enable_ha";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, heartbeatSrs, configuration };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Turn on High Availability mode
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param heartbeatSrs Set of SRs to use for storage heartbeating 
     * @param configuration Detailed HA configuration to apply 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task enableHaAsync(Connection c, Set<SR> heartbeatSrs, Map<String, String> configuration) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.enable_ha";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, heartbeatSrs, configuration };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Turn off High Availability mode
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void disableHa(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.disable_ha";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Turn off High Availability mode
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task disableHaAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.disable_ha";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Forcibly synchronise the database now
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void syncDatabase(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.sync_database";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Forcibly synchronise the database now
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task syncDatabaseAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.sync_database";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Perform an orderly handover of the role of master to the referenced host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param host The host who should become the new master 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void designateNewMaster(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.designate_new_master";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Perform an orderly handover of the role of master to the referenced host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param host The host who should become the new master 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task designateNewMasterAsync(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.designate_new_master";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * When this call returns the VM restart logic will not run for the requested number of seconds. If the argument is zero then the restart thread is immediately unblocked
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0 Update 1.
     *
     * @param c The connection the call is made on
     * @param seconds The number of seconds to block the restart thread for 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void haPreventRestartsFor(Connection c, Long seconds) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.ha_prevent_restarts_for";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, seconds };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Returns true if a VM failover plan exists for up to 'n' host failures
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param n The number of host failures to plan for 
     * @return true if a failover plan exists for the supplied number of host failures
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Boolean haFailoverPlanExists(Connection c, Long n) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.ha_failover_plan_exists";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, n };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns the maximum number of host failures we could tolerate before we would be unable to restart configured VMs
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return maximum value for ha_host_failures_to_tolerate given current configuration
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Long haComputeMaxHostFailuresToTolerate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.ha_compute_max_host_failures_to_tolerate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns the maximum number of host failures we could tolerate before we would be unable to restart the provided VMs
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param configuration Map of protected VM reference to restart priority 
     * @return maximum value for ha_host_failures_to_tolerate given provided configuration
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Long haComputeHypotheticalMaxHostFailuresToTolerate(Connection c, Map<VM, String> configuration) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.ha_compute_hypothetical_max_host_failures_to_tolerate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, configuration };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a VM failover plan assuming a given subset of hosts fail
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param failedHosts The set of hosts to assume have failed 
     * @param failedVms The set of VMs to restart 
     * @return VM failover plan: a map of VM to host to restart the host on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<VM, Map<String, String>> haComputeVmFailoverPlan(Connection c, Set<Host> failedHosts, Set<VM> failedVms) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.ha_compute_vm_failover_plan";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, failedHosts, failedVms };
        var typeReference = new TypeReference<Map<VM, Map<String, String>>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the maximum number of host failures to consider in the HA VM restart planner
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value New number of host failures to consider 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHaHostFailuresToTolerate(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_ha_host_failures_to_tolerate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the maximum number of host failures to consider in the HA VM restart planner
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value New number of host failures to consider 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setHaHostFailuresToTolerateAsync(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.set_ha_host_failures_to_tolerate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @return The reference of the blob, needed for populating its data
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Blob createNewBlob(Connection c, String name, String mimeType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType };
        var typeReference = new TypeReference<Blob>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @param _public True if the blob should be publicly available First published in XenServer 6.1.
     * @return The reference of the blob, needed for populating its data
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Blob createNewBlob(Connection c, String name, String mimeType, Boolean _public) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType, _public };
        var typeReference = new TypeReference<Blob>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task createNewBlobAsync(Connection c, String name, String mimeType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @param _public True if the blob should be publicly available First published in XenServer 6.1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task createNewBlobAsync(Connection c, String name, String mimeType, Boolean _public) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType, _public };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call enables external authentication on all the hosts of the pool
     * Minimum allowed role: pool-admin
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param config A list of key-values containing the configuration data 
     * @param serviceName The name of the service 
     * @param authType The type of authentication (e.g. AD for Active Directory) 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void enableExternalAuth(Connection c, Map<String, String> config, String serviceName, String authType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.enable_external_auth";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, config, serviceName, authType };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * This call disables external authentication on all the hosts of the pool
     * Minimum allowed role: pool-admin
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param config Optional parameters as a list of key-values containing the configuration data 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void disableExternalAuth(Connection c, Map<String, String> config) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.disable_external_auth";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, config };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * This call asynchronously detects if the external authentication configuration in any slave is different from that in the master and raises appropriate alerts
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void detectNonhomogeneousExternalAuth(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.detect_nonhomogeneous_external_auth";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Initializes workload balancing monitoring on this pool with the specified wlb server
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param wlbUrl The ip address and port to use when accessing the wlb server 
     * @param wlbUsername The username used to authenticate with the wlb server 
     * @param wlbPassword The password used to authenticate with the wlb server 
     * @param xenserverUsername The username used by the wlb server to authenticate with the xenserver 
     * @param xenserverPassword The password used by the wlb server to authenticate with the xenserver 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void initializeWlb(Connection c, String wlbUrl, String wlbUsername, String wlbPassword, String xenserverUsername, String xenserverPassword) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.initialize_wlb";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, wlbUrl, wlbUsername, wlbPassword, xenserverUsername, xenserverPassword };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Initializes workload balancing monitoring on this pool with the specified wlb server
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param wlbUrl The ip address and port to use when accessing the wlb server 
     * @param wlbUsername The username used to authenticate with the wlb server 
     * @param wlbPassword The password used to authenticate with the wlb server 
     * @param xenserverUsername The username used by the wlb server to authenticate with the xenserver 
     * @param xenserverPassword The password used by the wlb server to authenticate with the xenserver 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task initializeWlbAsync(Connection c, String wlbUrl, String wlbUsername, String wlbPassword, String xenserverUsername, String xenserverPassword) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.initialize_wlb";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, wlbUrl, wlbUsername, wlbPassword, xenserverUsername, xenserverPassword };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Permanently deconfigures workload balancing monitoring on this pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void deconfigureWlb(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.deconfigure_wlb";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Permanently deconfigures workload balancing monitoring on this pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task deconfigureWlbAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.deconfigure_wlb";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sets the pool optimization criteria for the workload balancing server
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param config The configuration to use in optimizing this pool 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void sendWlbConfiguration(Connection c, Map<String, String> config) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.send_wlb_configuration";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, config };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets the pool optimization criteria for the workload balancing server
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param config The configuration to use in optimizing this pool 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task sendWlbConfigurationAsync(Connection c, Map<String, String> config) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.send_wlb_configuration";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, config };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Retrieves the pool optimization criteria from the workload balancing server
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return The configuration used in optimizing this pool
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<String, String> retrieveWlbConfiguration(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.retrieve_wlb_configuration";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Retrieves the pool optimization criteria from the workload balancing server
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task retrieveWlbConfigurationAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.retrieve_wlb_configuration";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Retrieves vm migrate recommendations for the pool from the workload balancing server
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return The list of vm migration recommendations
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<VM, Set<String>> retrieveWlbRecommendations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.retrieve_wlb_recommendations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<VM, Set<String>>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Retrieves vm migrate recommendations for the pool from the workload balancing server
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task retrieveWlbRecommendationsAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.retrieve_wlb_recommendations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Send the given body to the given host and port, using HTTPS, and print the response.  This is used for debugging the SSL layer.
     * Minimum allowed role: pool-admin
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param host No description 
     * @param port No description 
     * @param body No description 
     * @return The response
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static String sendTestPost(Connection c, String host, Long port, String body) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.send_test_post";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, port, body };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Send the given body to the given host and port, using HTTPS, and print the response.  This is used for debugging the SSL layer.
     * Minimum allowed role: pool-admin
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param host No description 
     * @param port No description 
     * @param body No description 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task sendTestPostAsync(Connection c, String host, Long port, String body) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.send_test_post";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, port, body };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Install a TLS CA certificate, pool-wide.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     * @deprecated since 1.290.0
     *
     * @param c The connection the call is made on
     * @param name A name to give the certificate 
     * @param cert The certificate in PEM format 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "1.290.0")
    public static void certificateInstall(Connection c, String name, String cert) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.certificate_install";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name, cert };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Install a TLS CA certificate, pool-wide.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     * @deprecated since 1.290.0
     *
     * @param c The connection the call is made on
     * @param name A name to give the certificate 
     * @param cert The certificate in PEM format 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "1.290.0")
    public static Task certificateInstallAsync(Connection c, String name, String cert) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.certificate_install";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name, cert };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Remove a pool-wide TLS CA certificate.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     * @deprecated since 1.290.0
     *
     * @param c The connection the call is made on
     * @param name The certificate name 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "1.290.0")
    public static void certificateUninstall(Connection c, String name) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.certificate_uninstall";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove a pool-wide TLS CA certificate.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     * @deprecated since 1.290.0
     *
     * @param c The connection the call is made on
     * @param name The certificate name 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "1.290.0")
    public static Task certificateUninstallAsync(Connection c, String name) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.certificate_uninstall";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * List the names of all installed TLS CA certificates.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     * @deprecated since 1.290.0
     *
     * @param c The connection the call is made on
     * @return All installed certificates
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "1.290.0")
    public static Set<String> certificateList(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.certificate_list";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * List the names of all installed TLS CA certificates.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     * @deprecated since 1.290.0
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "1.290.0")
    public static Task certificateListAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.certificate_list";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Install a TLS CA certificate, pool-wide.
     * Minimum allowed role: pool-operator
     * First published in 1.290.0.
     *
     * @param c The connection the call is made on
     * @param name A name to give the certificate 
     * @param cert The certificate in PEM format 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void installCaCertificate(Connection c, String name, String cert) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.install_ca_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name, cert };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Install a TLS CA certificate, pool-wide.
     * Minimum allowed role: pool-operator
     * First published in 1.290.0.
     *
     * @param c The connection the call is made on
     * @param name A name to give the certificate 
     * @param cert The certificate in PEM format 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task installCaCertificateAsync(Connection c, String name, String cert) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.install_ca_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name, cert };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Remove a pool-wide TLS CA certificate.
     * Minimum allowed role: pool-operator
     * First published in 1.290.0.
     *
     * @param c The connection the call is made on
     * @param name The certificate name 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void uninstallCaCertificate(Connection c, String name) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.uninstall_ca_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove a pool-wide TLS CA certificate.
     * Minimum allowed role: pool-operator
     * First published in 1.290.0.
     *
     * @param c The connection the call is made on
     * @param name The certificate name 
     * @param force Remove the DB entry even if the file is non-existent First published in 24.35.0.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void uninstallCaCertificate(Connection c, String name, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.uninstall_ca_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name, force };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove a pool-wide TLS CA certificate.
     * Minimum allowed role: pool-operator
     * First published in 1.290.0.
     *
     * @param c The connection the call is made on
     * @param name The certificate name 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task uninstallCaCertificateAsync(Connection c, String name) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.uninstall_ca_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Remove a pool-wide TLS CA certificate.
     * Minimum allowed role: pool-operator
     * First published in 1.290.0.
     *
     * @param c The connection the call is made on
     * @param name The certificate name 
     * @param force Remove the DB entry even if the file is non-existent First published in 24.35.0.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task uninstallCaCertificateAsync(Connection c, String name, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.uninstall_ca_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name, force };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Install a TLS CA-issued Certificate Revocation List, pool-wide.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param name A name to give the CRL 
     * @param cert The CRL 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void crlInstall(Connection c, String name, String cert) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.crl_install";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name, cert };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Install a TLS CA-issued Certificate Revocation List, pool-wide.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param name A name to give the CRL 
     * @param cert The CRL 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task crlInstallAsync(Connection c, String name, String cert) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.crl_install";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name, cert };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Remove a pool-wide TLS CA-issued Certificate Revocation List.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param name The CRL name 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void crlUninstall(Connection c, String name) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.crl_uninstall";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove a pool-wide TLS CA-issued Certificate Revocation List.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param name The CRL name 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task crlUninstallAsync(Connection c, String name) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.crl_uninstall";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, name };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * List the names of all installed TLS CA-issued Certificate Revocation Lists.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return The names of all installed CRLs
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<String> crlList(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.crl_list";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * List the names of all installed TLS CA-issued Certificate Revocation Lists.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task crlListAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.crl_list";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Copy the TLS CA certificates and CRLs of the master to all slaves.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void certificateSync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.certificate_sync";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Copy the TLS CA certificates and CRLs of the master to all slaves.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task certificateSyncAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.certificate_sync";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Enable TLS server certificate verification
     * Minimum allowed role: pool-admin
     * First published in 1.290.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void enableTlsVerification(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.enable_tls_verification";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Enable the redo log on the given SR and start using it, unless HA is enabled.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param sr SR to hold the redo log. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void enableRedoLog(Connection c, SR sr) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.enable_redo_log";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, sr };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Enable the redo log on the given SR and start using it, unless HA is enabled.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param sr SR to hold the redo log. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task enableRedoLogAsync(Connection c, SR sr) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.enable_redo_log";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, sr };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Disable the redo log if in use, unless HA is enabled.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void disableRedoLog(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.disable_redo_log";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Disable the redo log if in use, unless HA is enabled.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task disableRedoLogAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.disable_redo_log";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the IP address of the vswitch controller.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     * @deprecated since XenServer 7.2
     *
     * @param c The connection the call is made on
     * @param address IP address of the vswitch controller. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.2")
    public static void setVswitchController(Connection c, String address) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_vswitch_controller";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, address };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the IP address of the vswitch controller.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     * @deprecated since XenServer 7.2
     *
     * @param c The connection the call is made on
     * @param address IP address of the vswitch controller. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.2")
    public static Task setVswitchControllerAsync(Connection c, String address) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.set_vswitch_controller";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, address };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call tests if a location is valid
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param config Location config settings to test 
     * @return An XMLRPC result
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String testArchiveTarget(Connection c, Map<String, String> config) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.test_archive_target";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, config };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call attempts to enable pool-wide local storage caching
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void enableLocalStorageCaching(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.enable_local_storage_caching";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * This call attempts to enable pool-wide local storage caching
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task enableLocalStorageCachingAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.enable_local_storage_caching";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call disables pool-wide local storage caching
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void disableLocalStorageCaching(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.disable_local_storage_caching";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * This call disables pool-wide local storage caching
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task disableLocalStorageCachingAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.disable_local_storage_caching";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call returns the license state for the pool
     * Minimum allowed role: read-only
     * First published in XenServer 6.2.
     *
     * @param c The connection the call is made on
     * @return The pool's license state
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getLicenseState(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_license_state";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call returns the license state for the pool
     * Minimum allowed role: read-only
     * First published in XenServer 6.2.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getLicenseStateAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.get_license_state";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Apply an edition to all hosts in the pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2.
     *
     * @param c The connection the call is made on
     * @param edition The requested edition 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void applyEdition(Connection c, String edition) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.apply_edition";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, edition };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Apply an edition to all hosts in the pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2.
     *
     * @param c The connection the call is made on
     * @param edition The requested edition 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task applyEditionAsync(Connection c, String edition) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.apply_edition";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, edition };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sets ssl_legacy true on each host, pool-master last. See Host.ssl_legacy and Host.set_ssl_legacy.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     * @deprecated since XenServer 7.0
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.0")
    public void enableSslLegacy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.enable_ssl_legacy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets ssl_legacy true on each host, pool-master last. See Host.ssl_legacy and Host.set_ssl_legacy.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     * @deprecated since XenServer 7.0
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.0")
    public Task enableSslLegacyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.enable_ssl_legacy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sets ssl_legacy false on each host, pool-master last. See Host.ssl_legacy and Host.set_ssl_legacy.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     * @deprecated since Citrix Hypervisor 8.2
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "Citrix Hypervisor 8.2")
    public void disableSslLegacy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.disable_ssl_legacy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets ssl_legacy false on each host, pool-master last. See Host.ssl_legacy and Host.set_ssl_legacy.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     * @deprecated since Citrix Hypervisor 8.2
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "Citrix Hypervisor 8.2")
    public Task disableSslLegacyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.disable_ssl_legacy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Enable or disable IGMP Snooping on the pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @param value Enable or disable IGMP Snooping on the pool 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setIgmpSnoopingEnabled(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_igmp_snooping_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Enable or disable IGMP Snooping on the pool.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @param value Enable or disable IGMP Snooping on the pool 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setIgmpSnoopingEnabledAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.set_igmp_snooping_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return true if the extension is available on the pool
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param name The name of the API call 
     * @return True if the extension exists, false otherwise
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean hasExtension(Connection c, String name) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.has_extension";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return true if the extension is available on the pool
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param name The name of the API call 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task hasExtensionAsync(Connection c, String name) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.has_extension";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Add a key-value pair to the pool-wide guest agent configuration
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param key The key to add 
     * @param value The value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToGuestAgentConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.add_to_guest_agent_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add a key-value pair to the pool-wide guest agent configuration
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param key The key to add 
     * @param value The value to add 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task addToGuestAgentConfigAsync(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.add_to_guest_agent_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Remove a key-value pair from the pool-wide guest agent configuration
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param key The key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromGuestAgentConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.remove_from_guest_agent_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove a key-value pair from the pool-wide guest agent configuration
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param key The key to remove 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task removeFromGuestAgentConfigAsync(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.remove_from_guest_agent_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-admin
     * First published in Citrix Hypervisor 8.2 Hotfix 2.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.InternalError The server failed to handle your request, due to an internal error. The given message may give details useful for debugging the problem.
     * @throws Types.HostIsSlave You cannot make regular API calls directly on a supporter. Please pass API calls via the coordinator host.
     * @throws Types.CannotContactHost Cannot forward messages because the server cannot be contacted. The server may be switched off or there may be network connectivity problems.
     * @throws Types.HaIsEnabled The operation could not be performed because HA is enabled on the Pool
     * @throws Types.NotSupportedDuringUpgrade This operation is not supported during an upgrade.
     */
    public static void rotateSecret(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.InternalError,
    Types.HostIsSlave,
    Types.CannotContactHost,
    Types.HaIsEnabled,
    Types.NotSupportedDuringUpgrade {
        String methodCall = "pool.rotate_secret";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-admin
     * First published in Citrix Hypervisor 8.2 Hotfix 2.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.InternalError The server failed to handle your request, due to an internal error. The given message may give details useful for debugging the problem.
     * @throws Types.HostIsSlave You cannot make regular API calls directly on a supporter. Please pass API calls via the coordinator host.
     * @throws Types.CannotContactHost Cannot forward messages because the server cannot be contacted. The server may be switched off or there may be network connectivity problems.
     * @throws Types.HaIsEnabled The operation could not be performed because HA is enabled on the Pool
     * @throws Types.NotSupportedDuringUpgrade This operation is not supported during an upgrade.
     */
    public static Task rotateSecretAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.InternalError,
    Types.HostIsSlave,
    Types.CannotContactHost,
    Types.HaIsEnabled,
    Types.NotSupportedDuringUpgrade {
        String methodCall = "Async.pool.rotate_secret";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set enabled set of repositories
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param value The set of repositories to be enabled 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setRepositories(Connection c, Set<Repository> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_repositories";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set enabled set of repositories
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param value The set of repositories to be enabled 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setRepositoriesAsync(Connection c, Set<Repository> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.set_repositories";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Add a repository to the enabled set
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param value The repository to be added to the enabled set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addRepository(Connection c, Repository value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.add_repository";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add a repository to the enabled set
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param value The repository to be added to the enabled set 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task addRepositoryAsync(Connection c, Repository value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.add_repository";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Remove a repository from the enabled set
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param value The repository to be removed 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeRepository(Connection c, Repository value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.remove_repository";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove a repository from the enabled set
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param value The repository to be removed 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task removeRepositoryAsync(Connection c, Repository value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.remove_repository";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sync with the enabled repository
     * Minimum allowed role: pool-operator
     * First published in 1.329.0.
     *
     * @param c The connection the call is made on
     * @param force If true local mirroring repo will be removed before syncing 
     * @param token The token for repository client authentication 
     * @param tokenId The ID of the token 
     * @return The SHA256 hash of updateinfo.xml.gz
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String syncUpdates(Connection c, Boolean force, String token, String tokenId) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.sync_updates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, force, token, tokenId };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sync with the enabled repository
     * Minimum allowed role: pool-operator
     * First published in 1.329.0.
     *
     * @param c The connection the call is made on
     * @param force If true local mirroring repo will be removed before syncing 
     * @param token The token for repository client authentication 
     * @param tokenId The ID of the token 
     * @param username The username of the remote pool First published in 25.7.0.
     * @param password The password of the remote pool First published in 25.7.0.
     * @return The SHA256 hash of updateinfo.xml.gz
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String syncUpdates(Connection c, Boolean force, String token, String tokenId, String username, String password) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.sync_updates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, force, token, tokenId, username, password };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sync with the enabled repository
     * Minimum allowed role: pool-operator
     * First published in 1.329.0.
     *
     * @param c The connection the call is made on
     * @param force If true local mirroring repo will be removed before syncing 
     * @param token The token for repository client authentication 
     * @param tokenId The ID of the token 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task syncUpdatesAsync(Connection c, Boolean force, String token, String tokenId) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.sync_updates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, force, token, tokenId };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sync with the enabled repository
     * Minimum allowed role: pool-operator
     * First published in 1.329.0.
     *
     * @param c The connection the call is made on
     * @param force If true local mirroring repo will be removed before syncing 
     * @param token The token for repository client authentication 
     * @param tokenId The ID of the token 
     * @param username The username of the remote pool First published in 25.7.0.
     * @param password The password of the remote pool First published in 25.7.0.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task syncUpdatesAsync(Connection c, Boolean force, String token, String tokenId, String username, String password) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.sync_updates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, force, token, tokenId, username, password };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Check if the pool is ready to be updated. If not, report the reasons.
     * Minimum allowed role: pool-operator
     * First published in 1.304.0.
     *
     * @param c The connection the call is made on
     * @param requiresReboot Assume that the update will require host reboots 
     * @return A set of error codes with arguments, if the pool is
        not ready to update. An empty list means the pool can be updated.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Set<String>> checkUpdateReadiness(Connection c, Boolean requiresReboot) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.check_update_readiness";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, requiresReboot };
        var typeReference = new TypeReference<Set<Set<String>>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Check if the pool is ready to be updated. If not, report the reasons.
     * Minimum allowed role: pool-operator
     * First published in 1.304.0.
     *
     * @param c The connection the call is made on
     * @param requiresReboot Assume that the update will require host reboots 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task checkUpdateReadinessAsync(Connection c, Boolean requiresReboot) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.check_update_readiness";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, requiresReboot };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Enable client certificate authentication on the pool
     * Minimum allowed role: pool-operator
     * First published in 1.318.0.
     *
     * @param c The connection the call is made on
     * @param name The name (CN/SAN) that an incoming client certificate must have to allow authentication 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void enableClientCertificateAuth(Connection c, String name) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.enable_client_certificate_auth";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Enable client certificate authentication on the pool
     * Minimum allowed role: pool-operator
     * First published in 1.318.0.
     *
     * @param c The connection the call is made on
     * @param name The name (CN/SAN) that an incoming client certificate must have to allow authentication 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task enableClientCertificateAuthAsync(Connection c, String name) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.enable_client_certificate_auth";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Disable client certificate authentication on the pool
     * Minimum allowed role: pool-operator
     * First published in 1.318.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void disableClientCertificateAuth(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.disable_client_certificate_auth";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Disable client certificate authentication on the pool
     * Minimum allowed role: pool-operator
     * First published in 1.318.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task disableClientCertificateAuthAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.disable_client_certificate_auth";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Configure proxy for RPM package repositories.
     * Minimum allowed role: pool-operator
     * First published in 21.3.0.
     *
     * @param c The connection the call is made on
     * @param url The URL of the proxy server 
     * @param username The username used to authenticate with the proxy server 
     * @param password The password used to authenticate with the proxy server 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void configureRepositoryProxy(Connection c, String url, String username, String password) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.configure_repository_proxy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, url, username, password };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Configure proxy for RPM package repositories.
     * Minimum allowed role: pool-operator
     * First published in 21.3.0.
     *
     * @param c The connection the call is made on
     * @param url The URL of the proxy server 
     * @param username The username used to authenticate with the proxy server 
     * @param password The password used to authenticate with the proxy server 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task configureRepositoryProxyAsync(Connection c, String url, String username, String password) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.configure_repository_proxy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, url, username, password };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Disable the proxy for RPM package repositories.
     * Minimum allowed role: pool-operator
     * First published in 21.4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void disableRepositoryProxy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.disable_repository_proxy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Disable the proxy for RPM package repositories.
     * Minimum allowed role: pool-operator
     * First published in 21.4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task disableRepositoryProxyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.disable_repository_proxy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the UEFI certificates for a pool and all its hosts. Deprecated: use set_custom_uefi_certificates instead
     * Minimum allowed role: pool-admin
     * First published in 22.16.0.
     * @deprecated since 24.0.0
     *
     * @param c The connection the call is made on
     * @param value The certificates to apply to the pool and its hosts 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "24.0.0")
    public void setUefiCertificates(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_uefi_certificates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the UEFI certificates for a pool and all its hosts. Deprecated: use set_custom_uefi_certificates instead
     * Minimum allowed role: pool-admin
     * First published in 22.16.0.
     * @deprecated since 24.0.0
     *
     * @param c The connection the call is made on
     * @param value The certificates to apply to the pool and its hosts 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "24.0.0")
    public Task setUefiCertificatesAsync(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.set_uefi_certificates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set custom UEFI certificates for a pool and all its hosts. Need `allow-custom-uefi-certs` set to true in conf. If empty: default back to Pool.uefi_certificates
     * Minimum allowed role: pool-admin
     * Experimental. First published in 24.0.0.
     *
     * @param c The connection the call is made on
     * @param value The certificates to apply to the pool and its hosts 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setCustomUefiCertificates(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_custom_uefi_certificates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set custom UEFI certificates for a pool and all its hosts. Need `allow-custom-uefi-certs` set to true in conf. If empty: default back to Pool.uefi_certificates
     * Minimum allowed role: pool-admin
     * Experimental. First published in 24.0.0.
     *
     * @param c The connection the call is made on
     * @param value The certificates to apply to the pool and its hosts 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setCustomUefiCertificatesAsync(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.set_custom_uefi_certificates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * updates all the host firewalls in the pool to open or close port 80 depending on the value
     * Minimum allowed role: pool-operator
     * Experimental. First published in 22.27.0.
     *
     * @param c The connection the call is made on
     * @param value true - http port 80 will be blocked, false - http port 80 will be open for the hosts in the pool 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHttpsOnly(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_https_only";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * updates all the host firewalls in the pool to open or close port 80 depending on the value
     * Minimum allowed role: pool-operator
     * Experimental. First published in 22.27.0.
     *
     * @param c The connection the call is made on
     * @param value true - http port 80 will be blocked, false - http port 80 will be open for the hosts in the pool 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setHttpsOnlyAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.set_https_only";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the timestamp for the next telemetry data collection.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.9.0.
     *
     * @param c The connection the call is made on
     * @param value The earliest timestamp (in UTC) when the next round of telemetry collection can be carried out. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setTelemetryNextCollection(Connection c, Date value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_telemetry_next_collection";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the timestamp for the next telemetry data collection.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.9.0.
     *
     * @param c The connection the call is made on
     * @param value The earliest timestamp (in UTC) when the next round of telemetry collection can be carried out. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setTelemetryNextCollectionAsync(Connection c, Date value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.set_telemetry_next_collection";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Assign a new UUID to telemetry data.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.9.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void resetTelemetryUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.reset_telemetry_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Assign a new UUID to telemetry data.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 23.9.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task resetTelemetryUuidAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.reset_telemetry_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Configure periodic update synchronization to synchronize updates from a remote CDN
     * Minimum allowed role: pool-operator
     * Experimental. First published in 23.18.0.
     *
     * @param c The connection the call is made on
     * @param updateSyncFrequency The frequency at which updates are synchronized from a remote CDN: daily or weekly. 
     * @param updateSyncDay The day of the week the update synchronization will happen, based on pool's local timezone. Valid values are 0 to 6, 0 being Sunday. For 'daily' schedule, the value is ignored. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void configureUpdateSync(Connection c, Types.UpdateSyncFrequency updateSyncFrequency, Long updateSyncDay) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.configure_update_sync";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, updateSyncFrequency, updateSyncDay };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Configure periodic update synchronization to synchronize updates from a remote CDN
     * Minimum allowed role: pool-operator
     * Experimental. First published in 23.18.0.
     *
     * @param c The connection the call is made on
     * @param updateSyncFrequency The frequency at which updates are synchronized from a remote CDN: daily or weekly. 
     * @param updateSyncDay The day of the week the update synchronization will happen, based on pool's local timezone. Valid values are 0 to 6, 0 being Sunday. For 'daily' schedule, the value is ignored. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task configureUpdateSyncAsync(Connection c, Types.UpdateSyncFrequency updateSyncFrequency, Long updateSyncDay) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.configure_update_sync";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, updateSyncFrequency, updateSyncDay };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * enable or disable periodic update synchronization depending on the value
     * Minimum allowed role: pool-operator
     * Experimental. First published in 23.18.0.
     *
     * @param c The connection the call is made on
     * @param value true - enable periodic update synchronization, false - disable it 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setUpdateSyncEnabled(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_update_sync_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * enable or disable periodic update synchronization depending on the value
     * Minimum allowed role: pool-operator
     * Experimental. First published in 23.18.0.
     *
     * @param c The connection the call is made on
     * @param value true - enable periodic update synchronization, false - disable it 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setUpdateSyncEnabledAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.set_update_sync_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * Experimental. First published in 23.27.0.
     *
     * @param c The connection the call is made on
     * @param value The new maximum 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setLocalAuthMaxThreads(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_local_auth_max_threads";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * Experimental. First published in 23.27.0.
     *
     * @param c The connection the call is made on
     * @param value The new maximum 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setExtAuthMaxThreads(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_ext_auth_max_threads";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * Experimental. First published in 24.17.0.
     *
     * @param c The connection the call is made on
     * @return The readiness of the pool
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.PoolGuestSecurebootReadiness getGuestSecurebootReadiness(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_guest_secureboot_readiness";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.PoolGuestSecurebootReadiness>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Enable SSH access on all hosts in the pool. It's a helper which calls host.enable_ssh for all the hosts in the pool.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.13.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void enableSsh(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.enable_ssh";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Enable SSH access on all hosts in the pool. It's a helper which calls host.enable_ssh for all the hosts in the pool.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.13.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task enableSshAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.enable_ssh";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Disable SSH access on all hosts in the pool. It's a helper which calls host.disable_ssh for all the hosts in the pool.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.13.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void disableSsh(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.disable_ssh";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Disable SSH access on all hosts in the pool. It's a helper which calls host.disable_ssh for all the hosts in the pool.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.13.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task disableSshAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.disable_ssh";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the SSH enabled timeout for all hosts in the pool
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.21.0.
     *
     * @param c The connection the call is made on
     * @param value The SSH enabled timeout in seconds. (0 means no timeout, max 2 days) 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSshEnabledTimeout(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_ssh_enabled_timeout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the SSH enabled timeout for all hosts in the pool
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.21.0.
     *
     * @param c The connection the call is made on
     * @param value The SSH enabled timeout in seconds. (0 means no timeout, max 2 days) 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setSshEnabledTimeoutAsync(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.set_ssh_enabled_timeout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the console idle timeout for all hosts in the pool
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.21.0.
     *
     * @param c The connection the call is made on
     * @param value The idle SSH/VNC session timeout in seconds. A value of 0 means no timeout. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setConsoleIdleTimeout(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_console_idle_timeout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the console idle timeout for all hosts in the pool
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.21.0.
     *
     * @param c The connection the call is made on
     * @param value The idle SSH/VNC session timeout in seconds. A value of 0 means no timeout. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setConsoleIdleTimeoutAsync(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.set_console_idle_timeout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the SSH auto mode for all hosts in the pool
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.27.0.
     *
     * @param c The connection the call is made on
     * @param value The SSH auto mode for all hosts in the pool，when set to true, SSH to normally be disabled and SSH to be enabled only in case of emergency e.g., xapi is down 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSshAutoMode(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.set_ssh_auto_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the SSH auto mode for all hosts in the pool
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.27.0.
     *
     * @param c The connection the call is made on
     * @param value The SSH auto mode for all hosts in the pool，when set to true, SSH to normally be disabled and SSH to be enabled only in case of emergency e.g., xapi is down 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setSshAutoModeAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool.set_ssh_auto_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the pools known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Pool> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<Pool>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of pool references to pool records for all pools known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<Pool, Pool.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<Pool, Pool.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}