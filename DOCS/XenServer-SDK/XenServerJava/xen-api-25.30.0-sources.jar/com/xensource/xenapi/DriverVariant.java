/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * UNSUPPORTED. Variant of a host driver
 * First published in .
 *
 * @author Cloud Software Group, Inc.
 */
public class DriverVariant extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    DriverVariant(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a DriverVariant, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof DriverVariant)
        {
            DriverVariant other = (DriverVariant) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a DriverVariant
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "name", this.name);
            print.printf("%1$20s: %2$s\n", "driver", this.driver);
            print.printf("%1$20s: %2$s\n", "version", this.version);
            print.printf("%1$20s: %2$s\n", "hardwarePresent", this.hardwarePresent);
            print.printf("%1$20s: %2$s\n", "priority", this.priority);
            print.printf("%1$20s: %2$s\n", "status", this.status);
            return writer.toString();
        }

        /**
         * Convert a DriverVariant.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name", this.name == null ? "" : this.name);
            map.put("driver", this.driver == null ? new HostDriver("OpaqueRef:NULL") : this.driver);
            map.put("version", this.version == null ? "" : this.version);
            map.put("hardware_present", this.hardwarePresent == null ? false : this.hardwarePresent);
            map.put("priority", this.priority == null ? 0.0 : this.priority);
            map.put("status", this.status == null ? "" : this.status);
            return map;
        }

        /**
         * Unique identifier/object reference
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * Name identifying the driver variant within the driver
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("name")
        public String name;

        /**
         * Driver this variant is a part of
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("driver")
        public HostDriver driver;

        /**
         * Unique version of this driver variant
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("version")
        public String version;

        /**
         * True if the hardware for this variant is present on the host
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("hardware_present")
        public Boolean hardwarePresent;

        /**
         * Priority; this needs an explanation how this is ordered
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("priority")
        public Double priority;

        /**
         * Development and release status of this variant, like 'alpha'
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("status")
        public String status;

    }

    /**
     * Get a record containing the current state of the given Driver_variant.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public DriverVariant.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Driver_variant.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<DriverVariant.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the Driver_variant instance with the specified UUID.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static DriverVariant getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Driver_variant.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<DriverVariant>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given Driver_variant.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Driver_variant.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name field of the given Driver_variant.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Driver_variant.get_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the driver field of the given Driver_variant.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public HostDriver getDriver(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Driver_variant.get_driver";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<HostDriver>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the version field of the given Driver_variant.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getVersion(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Driver_variant.get_version";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the hardware_present field of the given Driver_variant.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getHardwarePresent(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Driver_variant.get_hardware_present";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the priority field of the given Driver_variant.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Double getPriority(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Driver_variant.get_priority";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Double>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the status field of the given Driver_variant.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getStatus(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Driver_variant.get_status";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * UNSUPPORTED Select this variant of a driver to become active after reboot or immediately if currently no version is active
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void select(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Driver_variant.select";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * UNSUPPORTED Select this variant of a driver to become active after reboot or immediately if currently no version is active
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task selectAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Driver_variant.select";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the Driver_variants known to the system.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<DriverVariant> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Driver_variant.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<DriverVariant>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of Driver_variant references to Driver_variant records for all Driver_variants known to the system.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<DriverVariant, DriverVariant.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Driver_variant.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<DriverVariant, DriverVariant.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}