/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * network-sriov which connects logical pif and physical pif
 * First published in XenServer 7.5.
 *
 * @author Cloud Software Group, Inc.
 */
public class NetworkSriov extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    NetworkSriov(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a NetworkSriov, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof NetworkSriov)
        {
            NetworkSriov other = (NetworkSriov) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a NetworkSriov
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "physicalPIF", this.physicalPIF);
            print.printf("%1$20s: %2$s\n", "logicalPIF", this.logicalPIF);
            print.printf("%1$20s: %2$s\n", "requiresReboot", this.requiresReboot);
            print.printf("%1$20s: %2$s\n", "configurationMode", this.configurationMode);
            return writer.toString();
        }

        /**
         * Convert a NetworkSriov.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("physical_PIF", this.physicalPIF == null ? new PIF("OpaqueRef:NULL") : this.physicalPIF);
            map.put("logical_PIF", this.logicalPIF == null ? new PIF("OpaqueRef:NULL") : this.logicalPIF);
            map.put("requires_reboot", this.requiresReboot == null ? false : this.requiresReboot);
            map.put("configuration_mode", this.configurationMode == null ? Types.SriovConfigurationMode.UNRECOGNIZED : this.configurationMode);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * The PIF that has SR-IOV enabled
         */
        @JsonProperty("physical_PIF")
        public PIF physicalPIF;

        /**
         * The logical PIF to connect to the SR-IOV network after enable SR-IOV on the physical PIF
         */
        @JsonProperty("logical_PIF")
        public PIF logicalPIF;

        /**
         * Indicates whether the host need to be rebooted before SR-IOV is enabled on the physical PIF
         */
        @JsonProperty("requires_reboot")
        public Boolean requiresReboot;

        /**
         * The mode for configure network sriov
         */
        @JsonProperty("configuration_mode")
        public Types.SriovConfigurationMode configurationMode;

    }

    /**
     * Get a record containing the current state of the given network_sriov.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public NetworkSriov.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network_sriov.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<NetworkSriov.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the network_sriov instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static NetworkSriov getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network_sriov.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<NetworkSriov>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given network_sriov.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network_sriov.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the physical_PIF field of the given network_sriov.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PIF getPhysicalPIF(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network_sriov.get_physical_PIF";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the logical_PIF field of the given network_sriov.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PIF getLogicalPIF(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network_sriov.get_logical_PIF";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the requires_reboot field of the given network_sriov.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getRequiresReboot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network_sriov.get_requires_reboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the configuration_mode field of the given network_sriov.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.SriovConfigurationMode getConfigurationMode(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network_sriov.get_configuration_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.SriovConfigurationMode>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Enable SR-IOV on the specific PIF. It will create a network-sriov based on the specific PIF and automatically create a logical PIF to connect the specific network.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @param pif PIF on which to enable SR-IOV 
     * @param network Network to connect SR-IOV virtual functions with VM VIFs 
     * @return The reference of the created network_sriov object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static NetworkSriov create(Connection c, PIF pif, Network network) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network_sriov.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, pif, network };
        var typeReference = new TypeReference<NetworkSriov>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Enable SR-IOV on the specific PIF. It will create a network-sriov based on the specific PIF and automatically create a logical PIF to connect the specific network.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @param pif PIF on which to enable SR-IOV 
     * @param network Network to connect SR-IOV virtual functions with VM VIFs 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, PIF pif, Network network) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.network_sriov.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, pif, network };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Disable SR-IOV on the specific PIF. It will destroy the network-sriov and the logical PIF accordingly.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network_sriov.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Disable SR-IOV on the specific PIF. It will destroy the network-sriov and the logical PIF accordingly.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.network_sriov.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the number of free SR-IOV VFs on the associated PIF
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return The number of free SR-IOV VFs on the associated PIF
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getRemainingCapacity(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network_sriov.get_remaining_capacity";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the number of free SR-IOV VFs on the associated PIF
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getRemainingCapacityAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.network_sriov.get_remaining_capacity";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the network_sriovs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<NetworkSriov> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network_sriov.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<NetworkSriov>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of network_sriov references to network_sriov records for all network_sriovs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<NetworkSriov, NetworkSriov.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network_sriov.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<NetworkSriov, NetworkSriov.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}