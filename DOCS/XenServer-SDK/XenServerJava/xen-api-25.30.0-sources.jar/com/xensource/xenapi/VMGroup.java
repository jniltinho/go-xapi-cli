/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A VM group
 * First published in .
 *
 * @author Cloud Software Group, Inc.
 */
public class VMGroup extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    VMGroup(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a VMGroup, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof VMGroup)
        {
            VMGroup other = (VMGroup) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a VMGroup
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "placement", this.placement);
            print.printf("%1$20s: %2$s\n", "VMs", this.VMs);
            return writer.toString();
        }

        /**
         * Convert a VMGroup.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("placement", this.placement == null ? Types.PlacementPolicy.UNRECOGNIZED : this.placement);
            map.put("VMs", this.VMs == null ? new LinkedHashSet<VM>() : this.VMs);
            return map;
        }

        /**
         * Unique identifier/object reference
         * First published in XenServer 4.0.
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         * First published in XenServer 4.0.
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         * First published in XenServer 4.0.
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * The placement policy of the VM group
         * Experimental. First published in 24.19.1.
         */
        @JsonProperty("placement")
        public Types.PlacementPolicy placement;

        /**
         * The list of VMs associated with the group
         * Experimental. First published in 24.19.1.
         */
        @JsonProperty("VMs")
        public Set<VM> VMs;

    }

    /**
     * Get a record containing the current state of the given VM_group.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VMGroup.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VMGroup.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the VM_group instance with the specified UUID.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VMGroup getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<VMGroup>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VM_group instance, and return its handle.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return reference to the newly created object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VMGroup create(Connection c, VMGroup.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<VMGroup>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VM_group instance, and return its handle.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, VMGroup.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM_group.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy the specified VM_group instance.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy the specified VM_group instance.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM_group.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the VM_group instances with the given label.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VMGroup> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<VMGroup>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given VM_group.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given VM_group.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given VM_group.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the placement field of the given VM_group.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.PlacementPolicy getPlacement(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.get_placement";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.PlacementPolicy>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VMs field of the given VM_group.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VM> getVMs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.get_VMs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VM>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name/label field of the given VM_group.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param label New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, label };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name/description field of the given VM_group.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param description New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameDescription(Connection c, String description) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, description };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Return a list of all the VM_groups known to the system.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VMGroup> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<VMGroup>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of VM_group references to VM_group records for all VM_groups known to the system.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<VMGroup, VMGroup.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_group.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<VMGroup, VMGroup.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}