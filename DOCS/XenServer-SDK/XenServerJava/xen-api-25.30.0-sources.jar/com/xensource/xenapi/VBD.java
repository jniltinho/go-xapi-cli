/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A virtual block device
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class VBD extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    VBD(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a VBD, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof VBD)
        {
            VBD other = (VBD) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a VBD
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "allowedOperations", this.allowedOperations);
            print.printf("%1$20s: %2$s\n", "currentOperations", this.currentOperations);
            print.printf("%1$20s: %2$s\n", "VM", this.VM);
            print.printf("%1$20s: %2$s\n", "VDI", this.VDI);
            print.printf("%1$20s: %2$s\n", "device", this.device);
            print.printf("%1$20s: %2$s\n", "userdevice", this.userdevice);
            print.printf("%1$20s: %2$s\n", "bootable", this.bootable);
            print.printf("%1$20s: %2$s\n", "mode", this.mode);
            print.printf("%1$20s: %2$s\n", "type", this.type);
            print.printf("%1$20s: %2$s\n", "unpluggable", this.unpluggable);
            print.printf("%1$20s: %2$s\n", "storageLock", this.storageLock);
            print.printf("%1$20s: %2$s\n", "empty", this.empty);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "currentlyAttached", this.currentlyAttached);
            print.printf("%1$20s: %2$s\n", "statusCode", this.statusCode);
            print.printf("%1$20s: %2$s\n", "statusDetail", this.statusDetail);
            print.printf("%1$20s: %2$s\n", "runtimeProperties", this.runtimeProperties);
            print.printf("%1$20s: %2$s\n", "qosAlgorithmType", this.qosAlgorithmType);
            print.printf("%1$20s: %2$s\n", "qosAlgorithmParams", this.qosAlgorithmParams);
            print.printf("%1$20s: %2$s\n", "qosSupportedAlgorithms", this.qosSupportedAlgorithms);
            print.printf("%1$20s: %2$s\n", "metrics", this.metrics);
            return writer.toString();
        }

        /**
         * Convert a VBD.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("allowed_operations", this.allowedOperations == null ? new LinkedHashSet<Types.VbdOperations>() : this.allowedOperations);
            map.put("current_operations", this.currentOperations == null ? new HashMap<String, Types.VbdOperations>() : this.currentOperations);
            map.put("VM", this.VM == null ? new VM("OpaqueRef:NULL") : this.VM);
            map.put("VDI", this.VDI == null ? new VDI("OpaqueRef:NULL") : this.VDI);
            map.put("device", this.device == null ? "" : this.device);
            map.put("userdevice", this.userdevice == null ? "" : this.userdevice);
            map.put("bootable", this.bootable == null ? false : this.bootable);
            map.put("mode", this.mode == null ? Types.VbdMode.UNRECOGNIZED : this.mode);
            map.put("type", this.type == null ? Types.VbdType.UNRECOGNIZED : this.type);
            map.put("unpluggable", this.unpluggable == null ? false : this.unpluggable);
            map.put("storage_lock", this.storageLock == null ? false : this.storageLock);
            map.put("empty", this.empty == null ? false : this.empty);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("currently_attached", this.currentlyAttached == null ? false : this.currentlyAttached);
            map.put("status_code", this.statusCode == null ? 0 : this.statusCode);
            map.put("status_detail", this.statusDetail == null ? "" : this.statusDetail);
            map.put("runtime_properties", this.runtimeProperties == null ? new HashMap<String, String>() : this.runtimeProperties);
            map.put("qos_algorithm_type", this.qosAlgorithmType == null ? "" : this.qosAlgorithmType);
            map.put("qos_algorithm_params", this.qosAlgorithmParams == null ? new HashMap<String, String>() : this.qosAlgorithmParams);
            map.put("qos_supported_algorithms", this.qosSupportedAlgorithms == null ? new LinkedHashSet<String>() : this.qosSupportedAlgorithms);
            map.put("metrics", this.metrics == null ? new VBDMetrics("OpaqueRef:NULL") : this.metrics);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * list of the operations allowed in this state. This list is advisory only and the server state may have changed by the time this field is read by a client.
         */
        @JsonProperty("allowed_operations")
        public Set<Types.VbdOperations> allowedOperations;

        /**
         * links each of the running tasks using this object (by reference) to a current_operation enum which describes the nature of the task.
         */
        @JsonProperty("current_operations")
        public Map<String, Types.VbdOperations> currentOperations;

        /**
         * the virtual machine
         */
        @JsonProperty("VM")
        public VM VM;

        /**
         * the virtual disk
         */
        @JsonProperty("VDI")
        public VDI VDI;

        /**
         * device seen by the guest e.g. hda1
         */
        @JsonProperty("device")
        public String device;

        /**
         * user-friendly device name e.g. 0,1,2,etc.
         */
        @JsonProperty("userdevice")
        public String userdevice;

        /**
         * true if this VBD is bootable
         */
        @JsonProperty("bootable")
        public Boolean bootable;

        /**
         * the mode the VBD should be mounted with
         */
        @JsonProperty("mode")
        public Types.VbdMode mode;

        /**
         * how the VBD will appear to the guest (e.g. disk or CD)
         */
        @JsonProperty("type")
        public Types.VbdType type;

        /**
         * true if this VBD will support hot-unplug
         * First published in XenServer 4.1.
         */
        @JsonProperty("unpluggable")
        public Boolean unpluggable;

        /**
         * true if a storage level lock was acquired
         */
        @JsonProperty("storage_lock")
        public Boolean storageLock;

        /**
         * if true this represents an empty drive
         */
        @JsonProperty("empty")
        public Boolean empty;

        /**
         * additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * is the device currently attached (erased on reboot)
         */
        @JsonProperty("currently_attached")
        public Boolean currentlyAttached;

        /**
         * error/success code associated with last attach-operation (erased on reboot)
         */
        @JsonProperty("status_code")
        public Long statusCode;

        /**
         * error/success information associated with last attach-operation status (erased on reboot)
         */
        @JsonProperty("status_detail")
        public String statusDetail;

        /**
         * Device runtime properties
         */
        @JsonProperty("runtime_properties")
        public Map<String, String> runtimeProperties;

        /**
         * QoS algorithm to use
         */
        @JsonProperty("qos_algorithm_type")
        public String qosAlgorithmType;

        /**
         * parameters for chosen QoS algorithm
         */
        @JsonProperty("qos_algorithm_params")
        public Map<String, String> qosAlgorithmParams;

        /**
         * supported QoS algorithms for this VBD
         */
        @JsonProperty("qos_supported_algorithms")
        public Set<String> qosSupportedAlgorithms;

        /**
         * metrics associated with this VBD
         */
        @JsonProperty("metrics")
        public VBDMetrics metrics;

    }

    /**
     * Get a record containing the current state of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VBD.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VBD.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the VBD instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VBD getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<VBD>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VBD instance, and return its handle.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return reference to the newly created object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VBD create(Connection c, VBD.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<VBD>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VBD instance, and return its handle.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, VBD.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VBD.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy the specified VBD instance.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy the specified VBD instance.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VBD.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allowed_operations field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.VbdOperations> getAllowedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.VbdOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the current_operations field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Types.VbdOperations> getCurrentOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_current_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Types.VbdOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VM field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VM getVM(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_VM";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VDI field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VDI getVDI(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_VDI";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the device field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getDevice(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_device";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the userdevice field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUserdevice(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_userdevice";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the bootable field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getBootable(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_bootable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the mode field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.VbdMode getMode(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.VbdMode>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the type field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.VbdType getType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.VbdType>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the unpluggable field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getUnpluggable(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_unpluggable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the storage_lock field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getStorageLock(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_storage_lock";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the empty field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getEmpty(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_empty";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the currently_attached field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getCurrentlyAttached(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_currently_attached";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the status_code field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getStatusCode(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_status_code";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the status_detail field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getStatusDetail(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_status_detail";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the runtime_properties field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getRuntimeProperties(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_runtime_properties";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the qos/algorithm_type field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getQosAlgorithmType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_qos_algorithm_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the qos/algorithm_params field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getQosAlgorithmParams(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_qos_algorithm_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the qos/supported_algorithms field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getQosSupportedAlgorithms(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_qos_supported_algorithms";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the metrics field of the given VBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 6.1
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.1")
    public VBDMetrics getMetrics(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_metrics";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VBDMetrics>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the userdevice field of the given VBD.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param userdevice New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setUserdevice(Connection c, String userdevice) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.set_userdevice";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, userdevice };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the bootable field of the given VBD.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param bootable New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setBootable(Connection c, Boolean bootable) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.set_bootable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, bootable };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the type field of the given VBD.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param type New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setType(Connection c, Types.VbdType type) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.set_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, type };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the unpluggable field of the given VBD.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param unpluggable New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setUnpluggable(Connection c, Boolean unpluggable) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.set_unpluggable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, unpluggable };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the other_config field of the given VBD.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given VBD.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given VBD.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the qos/algorithm_type field of the given VBD.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param algorithmType New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setQosAlgorithmType(Connection c, String algorithmType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.set_qos_algorithm_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, algorithmType };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the qos/algorithm_params field of the given VBD.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param algorithmParams New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setQosAlgorithmParams(Connection c, Map<String, String> algorithmParams) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.set_qos_algorithm_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, algorithmParams };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the qos/algorithm_params field of the given VBD.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToQosAlgorithmParams(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.add_to_qos_algorithm_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the qos/algorithm_params field of the given VBD.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromQosAlgorithmParams(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.remove_from_qos_algorithm_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the media from the device and leave it empty
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VbdNotRemovableMedia Media could not be ejected because it is not removable
     * @throws Types.VbdIsEmpty Operation could not be performed because the drive is empty
     */
    public void eject(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VbdNotRemovableMedia,
    Types.VbdIsEmpty {
        String methodCall = "VBD.eject";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the media from the device and leave it empty
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VbdNotRemovableMedia Media could not be ejected because it is not removable
     * @throws Types.VbdIsEmpty Operation could not be performed because the drive is empty
     */
    public Task ejectAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VbdNotRemovableMedia,
    Types.VbdIsEmpty {
        String methodCall = "Async.VBD.eject";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Insert new media into the device
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param vdi The new VDI to 'insert' 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VbdNotRemovableMedia Media could not be ejected because it is not removable
     * @throws Types.VbdNotEmpty Operation could not be performed because the drive is not empty
     */
    public void insert(Connection c, VDI vdi) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VbdNotRemovableMedia,
    Types.VbdNotEmpty {
        String methodCall = "VBD.insert";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, vdi };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Insert new media into the device
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param vdi The new VDI to 'insert' 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VbdNotRemovableMedia Media could not be ejected because it is not removable
     * @throws Types.VbdNotEmpty Operation could not be performed because the drive is not empty
     */
    public Task insertAsync(Connection c, VDI vdi) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VbdNotRemovableMedia,
    Types.VbdNotEmpty {
        String methodCall = "Async.VBD.insert";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, vdi };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Hotplug the specified VBD, dynamically attaching it to the running VM
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void plug(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.plug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Hotplug the specified VBD, dynamically attaching it to the running VM
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task plugAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VBD.plug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Hot-unplug the specified VBD, dynamically unattaching it from the running VM
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.DeviceDetachRejected The VM rejected the attempt to detach the device.
     * @throws Types.DeviceAlreadyDetached The device is not currently attached
     */
    public void unplug(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.DeviceDetachRejected,
    Types.DeviceAlreadyDetached {
        String methodCall = "VBD.unplug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Hot-unplug the specified VBD, dynamically unattaching it from the running VM
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.DeviceDetachRejected The VM rejected the attempt to detach the device.
     * @throws Types.DeviceAlreadyDetached The device is not currently attached
     */
    public Task unplugAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.DeviceDetachRejected,
    Types.DeviceAlreadyDetached {
        String methodCall = "Async.VBD.unplug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Forcibly unplug the specified VBD
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void unplugForce(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.unplug_force";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Forcibly unplug the specified VBD
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task unplugForceAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VBD.unplug_force";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Throws an error if this VBD could not be attached to this VM if the VM were running. Intended for debugging.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void assertAttachable(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.assert_attachable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Throws an error if this VBD could not be attached to this VM if the VM were running. Intended for debugging.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task assertAttachableAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VBD.assert_attachable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sets the mode of the VBD. The power_state of the VM must be halted.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setMode(Connection c, Types.VbdMode value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.set_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets the mode of the VBD. The power_state of the VM must be halted.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value New value to set 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setModeAsync(Connection c, Types.VbdMode value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VBD.set_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the VBDs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VBD> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<VBD>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of VBD references to VBD records for all VBDs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<VBD, VBD.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VBD.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<VBD, VBD.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}