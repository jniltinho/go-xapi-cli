/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * Management of remote authentication services
 * First published in XenServer 5.5.
 *
 * @author Cloud Software Group, Inc.
 */
public class Auth extends XenAPIObject {

    @JsonValue
    public String toWireString() {
        return null;
    }

    /**
     * This call queries the external directory service to obtain the subject_identifier as a string from the human-readable subject_name
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param subjectName The human-readable subject_name, such as a username or a groupname 
     * @return the subject_identifier obtained from the external directory service
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static String getSubjectIdentifier(Connection c, String subjectName) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "auth.get_subject_identifier";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, subjectName };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call queries the external directory service to obtain the user information (e.g. username, organization etc) from the specified subject_identifier
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param subjectIdentifier A string containing the subject_identifier, unique in the external directory service 
     * @return key-value pairs containing at least a key called subject_name
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<String, String> getSubjectInformationFromIdentifier(Connection c, String subjectIdentifier) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "auth.get_subject_information_from_identifier";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, subjectIdentifier };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This calls queries the external directory service to obtain the transitively-closed set of groups that the the subject_identifier is member of.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param subjectIdentifier A string containing the subject_identifier, unique in the external directory service 
     * @return set of subject_identifiers that provides the group membership of subject_identifier passed as argument, it contains, recursively, all groups a subject_identifier is member of.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<String> getGroupMembership(Connection c, String subjectIdentifier) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "auth.get_group_membership";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, subjectIdentifier };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}