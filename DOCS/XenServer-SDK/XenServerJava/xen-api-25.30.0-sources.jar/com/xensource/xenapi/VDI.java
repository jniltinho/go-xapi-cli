/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A virtual disk image
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class VDI extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    VDI(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a VDI, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof VDI)
        {
            VDI other = (VDI) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a VDI
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "allowedOperations", this.allowedOperations);
            print.printf("%1$20s: %2$s\n", "currentOperations", this.currentOperations);
            print.printf("%1$20s: %2$s\n", "SR", this.SR);
            print.printf("%1$20s: %2$s\n", "VBDs", this.VBDs);
            print.printf("%1$20s: %2$s\n", "crashDumps", this.crashDumps);
            print.printf("%1$20s: %2$s\n", "virtualSize", this.virtualSize);
            print.printf("%1$20s: %2$s\n", "physicalUtilisation", this.physicalUtilisation);
            print.printf("%1$20s: %2$s\n", "type", this.type);
            print.printf("%1$20s: %2$s\n", "sharable", this.sharable);
            print.printf("%1$20s: %2$s\n", "readOnly", this.readOnly);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "storageLock", this.storageLock);
            print.printf("%1$20s: %2$s\n", "location", this.location);
            print.printf("%1$20s: %2$s\n", "managed", this.managed);
            print.printf("%1$20s: %2$s\n", "missing", this.missing);
            print.printf("%1$20s: %2$s\n", "parent", this.parent);
            print.printf("%1$20s: %2$s\n", "xenstoreData", this.xenstoreData);
            print.printf("%1$20s: %2$s\n", "smConfig", this.smConfig);
            print.printf("%1$20s: %2$s\n", "isASnapshot", this.isASnapshot);
            print.printf("%1$20s: %2$s\n", "snapshotOf", this.snapshotOf);
            print.printf("%1$20s: %2$s\n", "snapshots", this.snapshots);
            print.printf("%1$20s: %2$s\n", "snapshotTime", this.snapshotTime);
            print.printf("%1$20s: %2$s\n", "tags", this.tags);
            print.printf("%1$20s: %2$s\n", "allowCaching", this.allowCaching);
            print.printf("%1$20s: %2$s\n", "onBoot", this.onBoot);
            print.printf("%1$20s: %2$s\n", "metadataOfPool", this.metadataOfPool);
            print.printf("%1$20s: %2$s\n", "metadataLatest", this.metadataLatest);
            print.printf("%1$20s: %2$s\n", "isToolsIso", this.isToolsIso);
            print.printf("%1$20s: %2$s\n", "cbtEnabled", this.cbtEnabled);
            return writer.toString();
        }

        /**
         * Convert a VDI.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("allowed_operations", this.allowedOperations == null ? new LinkedHashSet<Types.VdiOperations>() : this.allowedOperations);
            map.put("current_operations", this.currentOperations == null ? new HashMap<String, Types.VdiOperations>() : this.currentOperations);
            map.put("SR", this.SR == null ? new SR("OpaqueRef:NULL") : this.SR);
            map.put("VBDs", this.VBDs == null ? new LinkedHashSet<VBD>() : this.VBDs);
            map.put("crash_dumps", this.crashDumps == null ? new LinkedHashSet<Crashdump>() : this.crashDumps);
            map.put("virtual_size", this.virtualSize == null ? 0 : this.virtualSize);
            map.put("physical_utilisation", this.physicalUtilisation == null ? 0 : this.physicalUtilisation);
            map.put("type", this.type == null ? Types.VdiType.UNRECOGNIZED : this.type);
            map.put("sharable", this.sharable == null ? false : this.sharable);
            map.put("read_only", this.readOnly == null ? false : this.readOnly);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("storage_lock", this.storageLock == null ? false : this.storageLock);
            map.put("location", this.location == null ? "" : this.location);
            map.put("managed", this.managed == null ? false : this.managed);
            map.put("missing", this.missing == null ? false : this.missing);
            map.put("parent", this.parent == null ? new VDI("OpaqueRef:NULL") : this.parent);
            map.put("xenstore_data", this.xenstoreData == null ? new HashMap<String, String>() : this.xenstoreData);
            map.put("sm_config", this.smConfig == null ? new HashMap<String, String>() : this.smConfig);
            map.put("is_a_snapshot", this.isASnapshot == null ? false : this.isASnapshot);
            map.put("snapshot_of", this.snapshotOf == null ? new VDI("OpaqueRef:NULL") : this.snapshotOf);
            map.put("snapshots", this.snapshots == null ? new LinkedHashSet<VDI>() : this.snapshots);
            map.put("snapshot_time", this.snapshotTime == null ? new Date(0) : this.snapshotTime);
            map.put("tags", this.tags == null ? new LinkedHashSet<String>() : this.tags);
            map.put("allow_caching", this.allowCaching == null ? false : this.allowCaching);
            map.put("on_boot", this.onBoot == null ? Types.OnBoot.UNRECOGNIZED : this.onBoot);
            map.put("metadata_of_pool", this.metadataOfPool == null ? new Pool("OpaqueRef:NULL") : this.metadataOfPool);
            map.put("metadata_latest", this.metadataLatest == null ? false : this.metadataLatest);
            map.put("is_tools_iso", this.isToolsIso == null ? false : this.isToolsIso);
            map.put("cbt_enabled", this.cbtEnabled == null ? false : this.cbtEnabled);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * list of the operations allowed in this state. This list is advisory only and the server state may have changed by the time this field is read by a client.
         */
        @JsonProperty("allowed_operations")
        public Set<Types.VdiOperations> allowedOperations;

        /**
         * links each of the running tasks using this object (by reference) to a current_operation enum which describes the nature of the task.
         */
        @JsonProperty("current_operations")
        public Map<String, Types.VdiOperations> currentOperations;

        /**
         * storage repository in which the VDI resides
         */
        @JsonProperty("SR")
        public SR SR;

        /**
         * list of vbds that refer to this disk
         */
        @JsonProperty("VBDs")
        public Set<VBD> VBDs;

        /**
         * list of crash dumps that refer to this disk
         */
        @JsonProperty("crash_dumps")
        public Set<Crashdump> crashDumps;

        /**
         * size of disk as presented to the guest (in bytes). Note that, depending on storage backend type, requested size may not be respected exactly
         */
        @JsonProperty("virtual_size")
        public Long virtualSize;

        /**
         * amount of physical space that the disk image is currently taking up on the storage repository (in bytes)
         */
        @JsonProperty("physical_utilisation")
        public Long physicalUtilisation;

        /**
         * type of the VDI
         */
        @JsonProperty("type")
        public Types.VdiType type;

        /**
         * true if this disk may be shared
         */
        @JsonProperty("sharable")
        public Boolean sharable;

        /**
         * true if this disk may ONLY be mounted read-only
         */
        @JsonProperty("read_only")
        public Boolean readOnly;

        /**
         * additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * true if this disk is locked at the storage level
         */
        @JsonProperty("storage_lock")
        public Boolean storageLock;

        /**
         * location information
         * First published in XenServer 4.1.
         */
        @JsonProperty("location")
        public String location;

        /**
         * 
         */
        @JsonProperty("managed")
        public Boolean managed;

        /**
         * true if SR scan operation reported this VDI as not present on disk
         */
        @JsonProperty("missing")
        public Boolean missing;

        /**
         * This field is always null. Deprecated
         */
        @JsonProperty("parent")
        @Deprecated(since = "XenServer 4.0")
        public VDI parent;

        /**
         * data to be inserted into the xenstore tree (/local/domain/0/backend/vbd/&lt;domid&gt;/&lt;device-id&gt;/sm-data) after the VDI is attached. This is generally set by the SM backends on vdi_attach.
         * First published in XenServer 4.1.
         */
        @JsonProperty("xenstore_data")
        public Map<String, String> xenstoreData;

        /**
         * SM dependent data
         * First published in XenServer 4.1.
         */
        @JsonProperty("sm_config")
        public Map<String, String> smConfig;

        /**
         * true if this is a snapshot.
         * First published in XenServer 5.0.
         */
        @JsonProperty("is_a_snapshot")
        public Boolean isASnapshot;

        /**
         * Ref pointing to the VDI this snapshot is of.
         * First published in XenServer 5.0.
         */
        @JsonProperty("snapshot_of")
        public VDI snapshotOf;

        /**
         * List pointing to all the VDIs snapshots.
         * First published in XenServer 5.0.
         */
        @JsonProperty("snapshots")
        public Set<VDI> snapshots;

        /**
         * Date/time when this snapshot was created.
         * First published in XenServer 5.0.
         */
        @JsonProperty("snapshot_time")
        public Date snapshotTime;

        /**
         * user-specified tags for categorization purposes
         * First published in XenServer 5.0.
         */
        @JsonProperty("tags")
        public Set<String> tags;

        /**
         * true if this VDI is to be cached in the local cache SR
         * First published in XenServer 5.6 FP1.
         */
        @JsonProperty("allow_caching")
        public Boolean allowCaching;

        /**
         * The behaviour of this VDI on a VM boot
         * First published in XenServer 5.6 FP1.
         */
        @JsonProperty("on_boot")
        public Types.OnBoot onBoot;

        /**
         * The pool whose metadata is contained in this VDI
         * First published in XenServer 6.0.
         */
        @JsonProperty("metadata_of_pool")
        public Pool metadataOfPool;

        /**
         * Whether this VDI contains the latest known accessible metadata for the pool
         * First published in XenServer 6.0.
         */
        @JsonProperty("metadata_latest")
        public Boolean metadataLatest;

        /**
         * Whether this VDI is a Tools ISO
         * First published in XenServer 7.0.
         */
        @JsonProperty("is_tools_iso")
        public Boolean isToolsIso;

        /**
         * True if changed blocks are tracked for this VDI
         * First published in XenServer 7.3.
         */
        @JsonProperty("cbt_enabled")
        public Boolean cbtEnabled;

    }

    /**
     * Get a record containing the current state of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VDI.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VDI.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the VDI instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VDI getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VDI instance, and return its handle.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return reference to the newly created object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VDI create(Connection c, VDI.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VDI instance, and return its handle.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, VDI.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy the specified VDI instance.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy the specified VDI instance.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the VDI instances with the given label.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VDI> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<VDI>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allowed_operations field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.VdiOperations> getAllowedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.VdiOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the current_operations field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Types.VdiOperations> getCurrentOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_current_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Types.VdiOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the SR field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public SR getSR(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_SR";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VBDs field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VBD> getVBDs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_VBDs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VBD>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the crash_dumps field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Crashdump> getCrashDumps(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_crash_dumps";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Crashdump>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the virtual_size field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getVirtualSize(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_virtual_size";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the physical_utilisation field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getPhysicalUtilisation(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_physical_utilisation";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the type field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.VdiType getType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.VdiType>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the sharable field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getSharable(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_sharable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the read_only field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getReadOnly(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_read_only";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the storage_lock field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getStorageLock(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_storage_lock";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the location field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getLocation(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_location";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the managed field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getManaged(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_managed";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the missing field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getMissing(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_missing";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the parent field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public VDI getParent(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_parent";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the xenstore_data field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getXenstoreData(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_xenstore_data";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the sm_config field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getSmConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_sm_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_a_snapshot field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsASnapshot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_is_a_snapshot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the snapshot_of field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VDI getSnapshotOf(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_snapshot_of";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the snapshots field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VDI> getSnapshots(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_snapshots";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VDI>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the snapshot_time field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getSnapshotTime(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_snapshot_time";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the tags field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getTags(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allow_caching field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getAllowCaching(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_allow_caching";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the on_boot field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.OnBoot getOnBoot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_on_boot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.OnBoot>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the metadata_of_pool field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Pool getMetadataOfPool(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_metadata_of_pool";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Pool>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the metadata_latest field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getMetadataLatest(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_metadata_latest";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_tools_iso field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsToolsIso(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_is_tools_iso";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the cbt_enabled field of the given VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getCbtEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_cbt_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the other_config field of the given VDI.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given VDI.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given VDI.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the xenstore_data field of the given VDI.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param xenstoreData New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setXenstoreData(Connection c, Map<String, String> xenstoreData) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.set_xenstore_data";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, xenstoreData };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the xenstore_data field of the given VDI.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToXenstoreData(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.add_to_xenstore_data";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the xenstore_data field of the given VDI.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromXenstoreData(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.remove_from_xenstore_data";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the sm_config field of the given VDI.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param smConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSmConfig(Connection c, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.set_sm_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, smConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the sm_config field of the given VDI.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToSmConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.add_to_sm_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the sm_config field of the given VDI.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromSmConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.remove_from_sm_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the tags field of the given VDI.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param tags New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setTags(Connection c, Set<String> tags) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.set_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, tags };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given value to the tags field of the given VDI.  If the value is already in that Set, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value New value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addTags(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.add_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given value from the tags field of the given VDI.  If the value is not in that Set, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value Value to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeTags(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.remove_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Take a read-only snapshot of the VDI, returning a reference to the snapshot. If any driver_params are specified then these are passed through to the storage-specific substrate driver that takes the snapshot. NB the snapshot lives in the same Storage Repository as its parent.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return The ID of the newly created VDI.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VDI snapshot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.snapshot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Take a read-only snapshot of the VDI, returning a reference to the snapshot. If any driver_params are specified then these are passed through to the storage-specific substrate driver that takes the snapshot. NB the snapshot lives in the same Storage Repository as its parent.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param driverParams Optional parameters that can be passed through to backend driver in order to specify storage-type-specific snapshot options First published in XenServer 4.1.
     * @return The ID of the newly created VDI.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VDI snapshot(Connection c, Map<String, String> driverParams) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.snapshot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, driverParams };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Take a read-only snapshot of the VDI, returning a reference to the snapshot. If any driver_params are specified then these are passed through to the storage-specific substrate driver that takes the snapshot. NB the snapshot lives in the same Storage Repository as its parent.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task snapshotAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.snapshot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Take a read-only snapshot of the VDI, returning a reference to the snapshot. If any driver_params are specified then these are passed through to the storage-specific substrate driver that takes the snapshot. NB the snapshot lives in the same Storage Repository as its parent.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param driverParams Optional parameters that can be passed through to backend driver in order to specify storage-type-specific snapshot options First published in XenServer 4.1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task snapshotAsync(Connection c, Map<String, String> driverParams) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.snapshot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, driverParams };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Take an exact copy of the VDI and return a reference to the new disk. If any driver_params are specified then these are passed through to the storage-specific substrate driver that implements the clone operation. NB the clone lives in the same Storage Repository as its parent.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return The ID of the newly created VDI.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VDI createClone(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.clone";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Take an exact copy of the VDI and return a reference to the new disk. If any driver_params are specified then these are passed through to the storage-specific substrate driver that implements the clone operation. NB the clone lives in the same Storage Repository as its parent.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param driverParams Optional parameters that are passed through to the backend driver in order to specify storage-type-specific clone options First published in XenServer 4.1.
     * @return The ID of the newly created VDI.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VDI createClone(Connection c, Map<String, String> driverParams) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.clone";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, driverParams };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Take an exact copy of the VDI and return a reference to the new disk. If any driver_params are specified then these are passed through to the storage-specific substrate driver that implements the clone operation. NB the clone lives in the same Storage Repository as its parent.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task createCloneAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.clone";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Take an exact copy of the VDI and return a reference to the new disk. If any driver_params are specified then these are passed through to the storage-specific substrate driver that implements the clone operation. NB the clone lives in the same Storage Repository as its parent.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param driverParams Optional parameters that are passed through to the backend driver in order to specify storage-type-specific clone options First published in XenServer 4.1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task createCloneAsync(Connection c, Map<String, String> driverParams) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.clone";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, driverParams };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Resize the VDI.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param size The new size of the VDI 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void resize(Connection c, Long size) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.resize";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, size };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Resize the VDI.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param size The new size of the VDI 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task resizeAsync(Connection c, Long size) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.resize";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, size };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Resize the VDI which may or may not be attached to running guests.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     * @deprecated since XenServer 7.3
     *
     * @param c The connection the call is made on
     * @param size The new size of the VDI 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.3")
    public void resizeOnline(Connection c, Long size) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.resize_online";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, size };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Resize the VDI which may or may not be attached to running guests.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     * @deprecated since XenServer 7.3
     *
     * @param c The connection the call is made on
     * @param size The new size of the VDI 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.3")
    public Task resizeOnlineAsync(Connection c, Long size) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.resize_online";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, size };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VDI record in the database only
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param uuid The uuid of the disk to introduce 
     * @param nameLabel The name of the disk record 
     * @param nameDescription The description of the disk record 
     * @param SR The SR that the VDI is in 
     * @param type The type of the VDI 
     * @param sharable true if this disk may be shared 
     * @param readOnly true if this disk may ONLY be mounted read-only 
     * @param otherConfig additional configuration 
     * @param location location information 
     * @param xenstoreData Data to insert into xenstore 
     * @return The ref of the newly created VDI record.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     */
    public static VDI introduce(Connection c, String uuid, String nameLabel, String nameDescription, SR SR, Types.VdiType type, Boolean sharable, Boolean readOnly, Map<String, String> otherConfig, String location, Map<String, String> xenstoreData) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported {
        String methodCall = "VDI.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid, nameLabel, nameDescription, SR, type, sharable, readOnly, otherConfig, location, xenstoreData };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VDI record in the database only
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param uuid The uuid of the disk to introduce 
     * @param nameLabel The name of the disk record 
     * @param nameDescription The description of the disk record 
     * @param SR The SR that the VDI is in 
     * @param type The type of the VDI 
     * @param sharable true if this disk may be shared 
     * @param readOnly true if this disk may ONLY be mounted read-only 
     * @param otherConfig additional configuration 
     * @param location location information 
     * @param xenstoreData Data to insert into xenstore 
     * @param smConfig Storage-specific config 
     * @return The ref of the newly created VDI record.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     */
    public static VDI introduce(Connection c, String uuid, String nameLabel, String nameDescription, SR SR, Types.VdiType type, Boolean sharable, Boolean readOnly, Map<String, String> otherConfig, String location, Map<String, String> xenstoreData, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported {
        String methodCall = "VDI.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid, nameLabel, nameDescription, SR, type, sharable, readOnly, otherConfig, location, xenstoreData, smConfig };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VDI record in the database only
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param uuid The uuid of the disk to introduce 
     * @param nameLabel The name of the disk record 
     * @param nameDescription The description of the disk record 
     * @param SR The SR that the VDI is in 
     * @param type The type of the VDI 
     * @param sharable true if this disk may be shared 
     * @param readOnly true if this disk may ONLY be mounted read-only 
     * @param otherConfig additional configuration 
     * @param location location information 
     * @param xenstoreData Data to insert into xenstore 
     * @param smConfig Storage-specific config 
     * @param managed Storage-specific config First published in XenServer 6.1.
     * @param virtualSize Storage-specific config First published in XenServer 6.1.
     * @param physicalUtilisation Storage-specific config First published in XenServer 6.1.
     * @param metadataOfPool Storage-specific config First published in XenServer 6.1.
     * @param isASnapshot Storage-specific config First published in XenServer 6.1.
     * @param snapshotTime Storage-specific config. When the timezone is missing, UTC is assumed First published in XenServer 6.1.
     * @param snapshotOf Storage-specific config First published in XenServer 6.1.
     * @return The ref of the newly created VDI record.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     */
    public static VDI introduce(Connection c, String uuid, String nameLabel, String nameDescription, SR SR, Types.VdiType type, Boolean sharable, Boolean readOnly, Map<String, String> otherConfig, String location, Map<String, String> xenstoreData, Map<String, String> smConfig, Boolean managed, Long virtualSize, Long physicalUtilisation, Pool metadataOfPool, Boolean isASnapshot, Date snapshotTime, VDI snapshotOf) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported {
        String methodCall = "VDI.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid, nameLabel, nameDescription, SR, type, sharable, readOnly, otherConfig, location, xenstoreData, smConfig, managed, virtualSize, physicalUtilisation, metadataOfPool, isASnapshot, snapshotTime, snapshotOf };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VDI record in the database only
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param uuid The uuid of the disk to introduce 
     * @param nameLabel The name of the disk record 
     * @param nameDescription The description of the disk record 
     * @param SR The SR that the VDI is in 
     * @param type The type of the VDI 
     * @param sharable true if this disk may be shared 
     * @param readOnly true if this disk may ONLY be mounted read-only 
     * @param otherConfig additional configuration 
     * @param location location information 
     * @param xenstoreData Data to insert into xenstore 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     */
    public static Task introduceAsync(Connection c, String uuid, String nameLabel, String nameDescription, SR SR, Types.VdiType type, Boolean sharable, Boolean readOnly, Map<String, String> otherConfig, String location, Map<String, String> xenstoreData) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported {
        String methodCall = "Async.VDI.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid, nameLabel, nameDescription, SR, type, sharable, readOnly, otherConfig, location, xenstoreData };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VDI record in the database only
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param uuid The uuid of the disk to introduce 
     * @param nameLabel The name of the disk record 
     * @param nameDescription The description of the disk record 
     * @param SR The SR that the VDI is in 
     * @param type The type of the VDI 
     * @param sharable true if this disk may be shared 
     * @param readOnly true if this disk may ONLY be mounted read-only 
     * @param otherConfig additional configuration 
     * @param location location information 
     * @param xenstoreData Data to insert into xenstore 
     * @param smConfig Storage-specific config 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     */
    public static Task introduceAsync(Connection c, String uuid, String nameLabel, String nameDescription, SR SR, Types.VdiType type, Boolean sharable, Boolean readOnly, Map<String, String> otherConfig, String location, Map<String, String> xenstoreData, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported {
        String methodCall = "Async.VDI.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid, nameLabel, nameDescription, SR, type, sharable, readOnly, otherConfig, location, xenstoreData, smConfig };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VDI record in the database only
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param uuid The uuid of the disk to introduce 
     * @param nameLabel The name of the disk record 
     * @param nameDescription The description of the disk record 
     * @param SR The SR that the VDI is in 
     * @param type The type of the VDI 
     * @param sharable true if this disk may be shared 
     * @param readOnly true if this disk may ONLY be mounted read-only 
     * @param otherConfig additional configuration 
     * @param location location information 
     * @param xenstoreData Data to insert into xenstore 
     * @param smConfig Storage-specific config 
     * @param managed Storage-specific config First published in XenServer 6.1.
     * @param virtualSize Storage-specific config First published in XenServer 6.1.
     * @param physicalUtilisation Storage-specific config First published in XenServer 6.1.
     * @param metadataOfPool Storage-specific config First published in XenServer 6.1.
     * @param isASnapshot Storage-specific config First published in XenServer 6.1.
     * @param snapshotTime Storage-specific config. When the timezone is missing, UTC is assumed First published in XenServer 6.1.
     * @param snapshotOf Storage-specific config First published in XenServer 6.1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     */
    public static Task introduceAsync(Connection c, String uuid, String nameLabel, String nameDescription, SR SR, Types.VdiType type, Boolean sharable, Boolean readOnly, Map<String, String> otherConfig, String location, Map<String, String> xenstoreData, Map<String, String> smConfig, Boolean managed, Long virtualSize, Long physicalUtilisation, Pool metadataOfPool, Boolean isASnapshot, Date snapshotTime, VDI snapshotOf) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported {
        String methodCall = "Async.VDI.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid, nameLabel, nameDescription, SR, type, sharable, readOnly, otherConfig, location, xenstoreData, smConfig, managed, virtualSize, physicalUtilisation, metadataOfPool, isASnapshot, snapshotTime, snapshotOf };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Ask the storage backend to refresh the fields in the VDI object
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     */
    public void update(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported {
        String methodCall = "VDI.update";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Ask the storage backend to refresh the fields in the VDI object
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     */
    public Task updateAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported {
        String methodCall = "Async.VDI.update";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Copy either a full VDI or the block differences between two VDIs into either a fresh VDI or an existing VDI.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param sr The destination SR (only required if the destination VDI is not specified 
     * @return The reference of the VDI where the blocks were written.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VdiReadonly The operation required write access but this VDI is read-only
     * @throws Types.VdiTooSmall The VDI is too small. Please resize it to at least the minimum size.
     * @throws Types.VdiNotSparse The VDI is not stored using a sparse format. It is not possible to query and manipulate only the changed blocks (or 'block differences' or 'disk deltas') between two VDIs. Please select a VDI which uses a sparse-aware technology such as VHD.
     */
    public VDI copy(Connection c, SR sr) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VdiReadonly,
    Types.VdiTooSmall,
    Types.VdiNotSparse {
        String methodCall = "VDI.copy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sr };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Copy either a full VDI or the block differences between two VDIs into either a fresh VDI or an existing VDI.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param sr The destination SR (only required if the destination VDI is not specified 
     * @param baseVdi The base VDI (only required if copying only changed blocks, by default all blocks will be copied) First published in XenServer 6.2 SP1 Hotfix 4.
     * @param intoVdi The destination VDI to copy blocks into (if omitted then a destination SR must be provided and a fresh VDI will be created) First published in XenServer 6.2 SP1 Hotfix 4.
     * @return The reference of the VDI where the blocks were written.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VdiReadonly The operation required write access but this VDI is read-only
     * @throws Types.VdiTooSmall The VDI is too small. Please resize it to at least the minimum size.
     * @throws Types.VdiNotSparse The VDI is not stored using a sparse format. It is not possible to query and manipulate only the changed blocks (or 'block differences' or 'disk deltas') between two VDIs. Please select a VDI which uses a sparse-aware technology such as VHD.
     */
    public VDI copy(Connection c, SR sr, VDI baseVdi, VDI intoVdi) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VdiReadonly,
    Types.VdiTooSmall,
    Types.VdiNotSparse {
        String methodCall = "VDI.copy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sr, baseVdi, intoVdi };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Copy either a full VDI or the block differences between two VDIs into either a fresh VDI or an existing VDI.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param sr The destination SR (only required if the destination VDI is not specified 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VdiReadonly The operation required write access but this VDI is read-only
     * @throws Types.VdiTooSmall The VDI is too small. Please resize it to at least the minimum size.
     * @throws Types.VdiNotSparse The VDI is not stored using a sparse format. It is not possible to query and manipulate only the changed blocks (or 'block differences' or 'disk deltas') between two VDIs. Please select a VDI which uses a sparse-aware technology such as VHD.
     */
    public Task copyAsync(Connection c, SR sr) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VdiReadonly,
    Types.VdiTooSmall,
    Types.VdiNotSparse {
        String methodCall = "Async.VDI.copy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sr };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Copy either a full VDI or the block differences between two VDIs into either a fresh VDI or an existing VDI.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param sr The destination SR (only required if the destination VDI is not specified 
     * @param baseVdi The base VDI (only required if copying only changed blocks, by default all blocks will be copied) First published in XenServer 6.2 SP1 Hotfix 4.
     * @param intoVdi The destination VDI to copy blocks into (if omitted then a destination SR must be provided and a fresh VDI will be created) First published in XenServer 6.2 SP1 Hotfix 4.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VdiReadonly The operation required write access but this VDI is read-only
     * @throws Types.VdiTooSmall The VDI is too small. Please resize it to at least the minimum size.
     * @throws Types.VdiNotSparse The VDI is not stored using a sparse format. It is not possible to query and manipulate only the changed blocks (or 'block differences' or 'disk deltas') between two VDIs. Please select a VDI which uses a sparse-aware technology such as VHD.
     */
    public Task copyAsync(Connection c, SR sr, VDI baseVdi, VDI intoVdi) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VdiReadonly,
    Types.VdiTooSmall,
    Types.VdiNotSparse {
        String methodCall = "Async.VDI.copy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sr, baseVdi, intoVdi };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Removes a VDI record from the database
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void forget(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Removes a VDI record from the database
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task forgetAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sets the VDI's sharable field
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param value The new value of the VDI's sharable field 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSharable(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.set_sharable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets the VDI's read_only field
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value The new value of the VDI's read_only field 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setReadOnly(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.set_read_only";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name label of the VDI. This can only happen when then its SR is currently attached.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value The name lable for the VDI 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameLabel(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name label of the VDI. This can only happen when then its SR is currently attached.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value The name lable for the VDI 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setNameLabelAsync(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name description of the VDI. This can only happen when its SR is currently attached.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value The name description for the VDI 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameDescription(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name description of the VDI. This can only happen when its SR is currently attached.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value The name description for the VDI 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setNameDescriptionAsync(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the value of the on_boot parameter. This value can only be changed when the VDI is not attached to a running VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param value The value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOnBoot(Connection c, Types.OnBoot value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.set_on_boot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the value of the on_boot parameter. This value can only be changed when the VDI is not attached to a running VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param value The value to set 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setOnBootAsync(Connection c, Types.OnBoot value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.set_on_boot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the value of the allow_caching parameter. This value can only be changed when the VDI is not attached to a running VM. The caching behaviour is only affected by this flag for VHD-based VDIs that have one parent and no child VHDs. Moreover, caching only takes place when the host running the VM containing this VDI has a nominated SR for local caching.
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param value The value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setAllowCaching(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.set_allow_caching";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the value of the allow_caching parameter. This value can only be changed when the VDI is not attached to a running VM. The caching behaviour is only affected by this flag for VHD-based VDIs that have one parent and no child VHDs. Moreover, caching only takes place when the host running the VM containing this VDI has a nominated SR for local caching.
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param value The value to set 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setAllowCachingAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.set_allow_caching";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Load the metadata found on the supplied VDI and return a session reference which can be used in API calls to query its contents.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return A session which can be used to query the database
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Session openDatabase(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.open_database";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Session>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Load the metadata found on the supplied VDI and return a session reference which can be used in API calls to query its contents.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task openDatabaseAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.open_database";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Check the VDI cache for the pool UUID of the database on this VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return The cached pool UUID of the database on the VDI.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String readDatabasePoolUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.read_database_pool_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Check the VDI cache for the pool UUID of the database on this VDI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task readDatabasePoolUuidAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.read_database_pool_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Migrate a VDI, which may be attached to a running guest, to a different SR. The destination SR must be visible to the guest.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param sr The destination SR 
     * @param options Other parameters 
     * @return The new reference of the migrated VDI.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VDI poolMigrate(Connection c, SR sr, Map<String, String> options) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.pool_migrate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sr, options };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Migrate a VDI, which may be attached to a running guest, to a different SR. The destination SR must be visible to the guest.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param sr The destination SR 
     * @param options Other parameters 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task poolMigrateAsync(Connection c, SR sr, Map<String, String> options) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VDI.pool_migrate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sr, options };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Enable changed block tracking for the VDI. This call is idempotent - enabling CBT for a VDI for which CBT is already enabled results in a no-op, and no error will be thrown.
     * Minimum allowed role: vm-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     * @throws Types.VdiMissing This operation cannot be performed because the specified VDI could not be found on the storage substrate
     * @throws Types.SrNotAttached The SR is not attached.
     * @throws Types.SrHasNoPbds The SR has no attached PBDs
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VdiIncompatibleType This operation cannot be performed because the specified VDI is of an incompatible type (eg: an HA statefile cannot be attached to a guest)
     * @throws Types.VdiOnBootModeIncompatibleWithOperation This operation is not permitted on VDIs in the 'on-boot=reset' mode, or on VMs having such VDIs.
     */
    public void enableCbt(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported,
    Types.VdiMissing,
    Types.SrNotAttached,
    Types.SrHasNoPbds,
    Types.OperationNotAllowed,
    Types.VdiIncompatibleType,
    Types.VdiOnBootModeIncompatibleWithOperation {
        String methodCall = "VDI.enable_cbt";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Enable changed block tracking for the VDI. This call is idempotent - enabling CBT for a VDI for which CBT is already enabled results in a no-op, and no error will be thrown.
     * Minimum allowed role: vm-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     * @throws Types.VdiMissing This operation cannot be performed because the specified VDI could not be found on the storage substrate
     * @throws Types.SrNotAttached The SR is not attached.
     * @throws Types.SrHasNoPbds The SR has no attached PBDs
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VdiIncompatibleType This operation cannot be performed because the specified VDI is of an incompatible type (eg: an HA statefile cannot be attached to a guest)
     * @throws Types.VdiOnBootModeIncompatibleWithOperation This operation is not permitted on VDIs in the 'on-boot=reset' mode, or on VMs having such VDIs.
     */
    public Task enableCbtAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported,
    Types.VdiMissing,
    Types.SrNotAttached,
    Types.SrHasNoPbds,
    Types.OperationNotAllowed,
    Types.VdiIncompatibleType,
    Types.VdiOnBootModeIncompatibleWithOperation {
        String methodCall = "Async.VDI.enable_cbt";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Disable changed block tracking for the VDI. This call is only allowed on VDIs that support enabling CBT. It is an idempotent operation - disabling CBT for a VDI for which CBT is not enabled results in a no-op, and no error will be thrown.
     * Minimum allowed role: vm-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     * @throws Types.VdiMissing This operation cannot be performed because the specified VDI could not be found on the storage substrate
     * @throws Types.SrNotAttached The SR is not attached.
     * @throws Types.SrHasNoPbds The SR has no attached PBDs
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VdiIncompatibleType This operation cannot be performed because the specified VDI is of an incompatible type (eg: an HA statefile cannot be attached to a guest)
     * @throws Types.VdiOnBootModeIncompatibleWithOperation This operation is not permitted on VDIs in the 'on-boot=reset' mode, or on VMs having such VDIs.
     */
    public void disableCbt(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported,
    Types.VdiMissing,
    Types.SrNotAttached,
    Types.SrHasNoPbds,
    Types.OperationNotAllowed,
    Types.VdiIncompatibleType,
    Types.VdiOnBootModeIncompatibleWithOperation {
        String methodCall = "VDI.disable_cbt";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Disable changed block tracking for the VDI. This call is only allowed on VDIs that support enabling CBT. It is an idempotent operation - disabling CBT for a VDI for which CBT is not enabled results in a no-op, and no error will be thrown.
     * Minimum allowed role: vm-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     * @throws Types.VdiMissing This operation cannot be performed because the specified VDI could not be found on the storage substrate
     * @throws Types.SrNotAttached The SR is not attached.
     * @throws Types.SrHasNoPbds The SR has no attached PBDs
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VdiIncompatibleType This operation cannot be performed because the specified VDI is of an incompatible type (eg: an HA statefile cannot be attached to a guest)
     * @throws Types.VdiOnBootModeIncompatibleWithOperation This operation is not permitted on VDIs in the 'on-boot=reset' mode, or on VMs having such VDIs.
     */
    public Task disableCbtAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported,
    Types.VdiMissing,
    Types.SrNotAttached,
    Types.SrHasNoPbds,
    Types.OperationNotAllowed,
    Types.VdiIncompatibleType,
    Types.VdiOnBootModeIncompatibleWithOperation {
        String methodCall = "Async.VDI.disable_cbt";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Delete the data of the snapshot VDI, but keep its changed block tracking metadata. When successful, this call changes the type of the VDI to cbt_metadata. This operation is idempotent: calling it on a VDI of type cbt_metadata results in a no-op, and no error will be thrown.
     * Minimum allowed role: vm-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     * @throws Types.VdiMissing This operation cannot be performed because the specified VDI could not be found on the storage substrate
     * @throws Types.SrNotAttached The SR is not attached.
     * @throws Types.SrHasNoPbds The SR has no attached PBDs
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VdiIncompatibleType This operation cannot be performed because the specified VDI is of an incompatible type (eg: an HA statefile cannot be attached to a guest)
     * @throws Types.VdiNoCbtMetadata The requested operation is not allowed because the specified VDI does not have changed block tracking metadata.
     * @throws Types.VdiInUse This operation cannot be performed because this VDI is in use by some other operation
     * @throws Types.VdiIsAPhysicalDevice The operation cannot be performed on physical device
     */
    public void dataDestroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported,
    Types.VdiMissing,
    Types.SrNotAttached,
    Types.SrHasNoPbds,
    Types.OperationNotAllowed,
    Types.VdiIncompatibleType,
    Types.VdiNoCbtMetadata,
    Types.VdiInUse,
    Types.VdiIsAPhysicalDevice {
        String methodCall = "VDI.data_destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Delete the data of the snapshot VDI, but keep its changed block tracking metadata. When successful, this call changes the type of the VDI to cbt_metadata. This operation is idempotent: calling it on a VDI of type cbt_metadata results in a no-op, and no error will be thrown.
     * Minimum allowed role: vm-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     * @throws Types.VdiMissing This operation cannot be performed because the specified VDI could not be found on the storage substrate
     * @throws Types.SrNotAttached The SR is not attached.
     * @throws Types.SrHasNoPbds The SR has no attached PBDs
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VdiIncompatibleType This operation cannot be performed because the specified VDI is of an incompatible type (eg: an HA statefile cannot be attached to a guest)
     * @throws Types.VdiNoCbtMetadata The requested operation is not allowed because the specified VDI does not have changed block tracking metadata.
     * @throws Types.VdiInUse This operation cannot be performed because this VDI is in use by some other operation
     * @throws Types.VdiIsAPhysicalDevice The operation cannot be performed on physical device
     */
    public Task dataDestroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported,
    Types.VdiMissing,
    Types.SrNotAttached,
    Types.SrHasNoPbds,
    Types.OperationNotAllowed,
    Types.VdiIncompatibleType,
    Types.VdiNoCbtMetadata,
    Types.VdiInUse,
    Types.VdiIsAPhysicalDevice {
        String methodCall = "Async.VDI.data_destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Compare two VDIs in 64k block increments and report which blocks differ. This operation is not allowed when vdi_to is attached to a VM.
     * Minimum allowed role: vm-operator
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @param vdiTo The second VDI. 
     * @return A base64 string-encoding of the bitmap showing which blocks differ in the two VDIs.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     * @throws Types.VdiMissing This operation cannot be performed because the specified VDI could not be found on the storage substrate
     * @throws Types.SrNotAttached The SR is not attached.
     * @throws Types.SrHasNoPbds The SR has no attached PBDs
     * @throws Types.VdiInUse This operation cannot be performed because this VDI is in use by some other operation
     */
    public String listChangedBlocks(Connection c, VDI vdiTo) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported,
    Types.VdiMissing,
    Types.SrNotAttached,
    Types.SrHasNoPbds,
    Types.VdiInUse {
        String methodCall = "VDI.list_changed_blocks";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, vdiTo };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Compare two VDIs in 64k block increments and report which blocks differ. This operation is not allowed when vdi_to is attached to a VM.
     * Minimum allowed role: vm-operator
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @param vdiTo The second VDI. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrOperationNotSupported The SR backend does not support the operation (check the SR's allowed operations)
     * @throws Types.VdiMissing This operation cannot be performed because the specified VDI could not be found on the storage substrate
     * @throws Types.SrNotAttached The SR is not attached.
     * @throws Types.SrHasNoPbds The SR has no attached PBDs
     * @throws Types.VdiInUse This operation cannot be performed because this VDI is in use by some other operation
     */
    public Task listChangedBlocksAsync(Connection c, VDI vdiTo) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrOperationNotSupported,
    Types.VdiMissing,
    Types.SrNotAttached,
    Types.SrHasNoPbds,
    Types.VdiInUse {
        String methodCall = "Async.VDI.list_changed_blocks";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, vdiTo };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get details specifying how to access this VDI via a Network Block Device server. For each of a set of NBD server addresses on which the VDI is available, the return value set contains a vdi_nbd_server_info object that contains an exportname to request once the NBD connection is established, and connection details for the address. An empty list is returned if there is no network that has a PIF on a host with access to the relevant SR, or if no such network has been assigned an NBD-related purpose in its purpose field. To access the given VDI, any of the vdi_nbd_server_info objects can be used to make a connection to a server, and then the VDI will be available by requesting the exportname.
     * Minimum allowed role: vm-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @return The details necessary for connecting to the VDI over NBD. This includes an authentication token, so must be treated as sensitive material and must not be sent over insecure networks.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VdiIncompatibleType This operation cannot be performed because the specified VDI is of an incompatible type (eg: an HA statefile cannot be attached to a guest)
     */
    public Set<VdiNbdServerInfo.Record> getNbdInfo(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VdiIncompatibleType {
        String methodCall = "VDI.get_nbd_info";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VdiNbdServerInfo.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the VDIs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VDI> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<VDI>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of VDI references to VDI records for all VDIs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<VDI, VDI.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VDI.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<VDI, VDI.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}