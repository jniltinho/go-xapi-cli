/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * machines serving blocks of data for provisioning VMs
 * First published in XenServer 7.1.
 *
 * @author Cloud Software Group, Inc.
 */
public class PVSSite extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    PVSSite(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a PVSSite, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof PVSSite)
        {
            PVSSite other = (PVSSite) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a PVSSite
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "PVSUuid", this.PVSUuid);
            print.printf("%1$20s: %2$s\n", "cacheStorage", this.cacheStorage);
            print.printf("%1$20s: %2$s\n", "servers", this.servers);
            print.printf("%1$20s: %2$s\n", "proxies", this.proxies);
            return writer.toString();
        }

        /**
         * Convert a PVSSite.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("PVS_uuid", this.PVSUuid == null ? "" : this.PVSUuid);
            map.put("cache_storage", this.cacheStorage == null ? new LinkedHashSet<PVSCacheStorage>() : this.cacheStorage);
            map.put("servers", this.servers == null ? new LinkedHashSet<PVSServer>() : this.servers);
            map.put("proxies", this.proxies == null ? new LinkedHashSet<PVSProxy>() : this.proxies);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * Unique identifier of the PVS site, as configured in PVS
         */
        @JsonProperty("PVS_uuid")
        public String PVSUuid;

        /**
         * The SR used by PVS proxy for the cache
         */
        @JsonProperty("cache_storage")
        public Set<PVSCacheStorage> cacheStorage;

        /**
         * The set of PVS servers in the site
         */
        @JsonProperty("servers")
        public Set<PVSServer> servers;

        /**
         * The set of proxies associated with the site
         */
        @JsonProperty("proxies")
        public Set<PVSProxy> proxies;

    }

    /**
     * Get a record containing the current state of the given PVS_site.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PVSSite.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PVSSite.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the PVS_site instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PVSSite getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<PVSSite>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the PVS_site instances with the given label.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<PVSSite> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<PVSSite>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given PVS_site.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given PVS_site.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given PVS_site.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PVS_uuid field of the given PVS_site.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getPVSUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.get_PVS_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the cache_storage field of the given PVS_site.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PVSCacheStorage> getCacheStorage(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.get_cache_storage";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PVSCacheStorage>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the servers field of the given PVS_site.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PVSServer> getServers(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.get_servers";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PVSServer>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the proxies field of the given PVS_site.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PVSProxy> getProxies(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.get_proxies";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PVSProxy>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name/label field of the given PVS_site.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param label New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, label };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name/description field of the given PVS_site.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param description New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameDescription(Connection c, String description) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, description };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Introduce new PVS site
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param nameLabel name of the PVS site 
     * @param nameDescription description of the PVS site 
     * @param PVSUuid unique identifier of the PVS site 
     * @return the new PVS site
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PVSSite introduce(Connection c, String nameLabel, String nameDescription, String PVSUuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, nameLabel, nameDescription, PVSUuid };
        var typeReference = new TypeReference<PVSSite>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Introduce new PVS site
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param nameLabel name of the PVS site 
     * @param nameDescription description of the PVS site 
     * @param PVSUuid unique identifier of the PVS site 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task introduceAsync(Connection c, String nameLabel, String nameDescription, String PVSUuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PVS_site.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, nameLabel, nameDescription, PVSUuid };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Remove a site's meta data
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.PvsSiteContainsRunningProxies The PVS site contains running proxies.
     * @throws Types.PvsSiteContainsServers The PVS site contains servers and cannot be forgotten.
     */
    public void forget(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.PvsSiteContainsRunningProxies,
    Types.PvsSiteContainsServers {
        String methodCall = "PVS_site.forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove a site's meta data
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.PvsSiteContainsRunningProxies The PVS site contains running proxies.
     * @throws Types.PvsSiteContainsServers The PVS site contains servers and cannot be forgotten.
     */
    public Task forgetAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.PvsSiteContainsRunningProxies,
    Types.PvsSiteContainsServers {
        String methodCall = "Async.PVS_site.forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Update the PVS UUID of the PVS site
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param value PVS UUID to be used 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setPVSUuid(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.set_PVS_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Update the PVS UUID of the PVS site
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param value PVS UUID to be used 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setPVSUuidAsync(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PVS_site.set_PVS_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the PVS_sites known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<PVSSite> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<PVSSite>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of PVS_site references to PVS_site records for all PVS_sites known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<PVSSite, PVSSite.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PVS_site.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<PVSSite, PVSSite.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}