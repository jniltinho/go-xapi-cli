/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A virtual TPM device
 * First published in .
 *
 * @author Cloud Software Group, Inc.
 */
public class VTPM extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    VTPM(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a VTPM, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof VTPM)
        {
            VTPM other = (VTPM) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a VTPM
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "allowedOperations", this.allowedOperations);
            print.printf("%1$20s: %2$s\n", "currentOperations", this.currentOperations);
            print.printf("%1$20s: %2$s\n", "VM", this.VM);
            print.printf("%1$20s: %2$s\n", "backend", this.backend);
            print.printf("%1$20s: %2$s\n", "persistenceBackend", this.persistenceBackend);
            print.printf("%1$20s: %2$s\n", "isUnique", this.isUnique);
            print.printf("%1$20s: %2$s\n", "isProtected", this.isProtected);
            return writer.toString();
        }

        /**
         * Convert a VTPM.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("allowed_operations", this.allowedOperations == null ? new LinkedHashSet<Types.VtpmOperations>() : this.allowedOperations);
            map.put("current_operations", this.currentOperations == null ? new HashMap<String, Types.VtpmOperations>() : this.currentOperations);
            map.put("VM", this.VM == null ? new VM("OpaqueRef:NULL") : this.VM);
            map.put("backend", this.backend == null ? new VM("OpaqueRef:NULL") : this.backend);
            map.put("persistence_backend", this.persistenceBackend == null ? Types.PersistenceBackend.UNRECOGNIZED : this.persistenceBackend);
            map.put("is_unique", this.isUnique == null ? false : this.isUnique);
            map.put("is_protected", this.isProtected == null ? false : this.isProtected);
            return map;
        }

        /**
         * Unique identifier/object reference
         * First published in XenServer 4.0.
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * list of the operations allowed in this state. This list is advisory only and the server state may have changed by the time this field is read by a client.
         * First published in XenServer 4.0.
         */
        @JsonProperty("allowed_operations")
        public Set<Types.VtpmOperations> allowedOperations;

        /**
         * links each of the running tasks using this object (by reference) to a current_operation enum which describes the nature of the task.
         * First published in XenServer 4.0.
         */
        @JsonProperty("current_operations")
        public Map<String, Types.VtpmOperations> currentOperations;

        /**
         * The virtual machine the TPM is attached to
         * First published in XenServer 4.0.
         */
        @JsonProperty("VM")
        public VM VM;

        /**
         * The domain where the backend is located (unused)
         * First published in XenServer 4.0.
         */
        @JsonProperty("backend")
        public VM backend;

        /**
         * The backend where the vTPM is persisted
         * Experimental. First published in 22.26.0.
         */
        @JsonProperty("persistence_backend")
        public Types.PersistenceBackend persistenceBackend;

        /**
         * Whether the contents are never copied, satisfying the TPM spec
         * Experimental. First published in 22.26.0.
         */
        @JsonProperty("is_unique")
        public Boolean isUnique;

        /**
         * Whether the contents of the VTPM are secured according to the TPM spec
         * Experimental. First published in 22.26.0.
         */
        @JsonProperty("is_protected")
        public Boolean isProtected;

    }

    /**
     * Get a record containing the current state of the given VTPM.
     * Minimum allowed role: read-only
     * Experimental. First published in 22.26.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VTPM.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VTPM.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the VTPM instance with the specified UUID.
     * Minimum allowed role: read-only
     * Experimental. First published in 22.26.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VTPM getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<VTPM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given VTPM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allowed_operations field of the given VTPM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.VtpmOperations> getAllowedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.get_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.VtpmOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the current_operations field of the given VTPM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Types.VtpmOperations> getCurrentOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.get_current_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Types.VtpmOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VM field of the given VTPM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VM getVM(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.get_VM";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the backend field of the given VTPM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VM getBackend(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.get_backend";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the persistence_backend field of the given VTPM.
     * Minimum allowed role: read-only
     * Experimental. First published in 22.26.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.PersistenceBackend getPersistenceBackend(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.get_persistence_backend";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.PersistenceBackend>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_unique field of the given VTPM.
     * Minimum allowed role: read-only
     * Experimental. First published in 22.26.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsUnique(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.get_is_unique";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_protected field of the given VTPM.
     * Minimum allowed role: read-only
     * Experimental. First published in 22.26.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsProtected(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.get_is_protected";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VTPM instance, and return its handle.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 22.26.0.
     *
     * @param c The connection the call is made on
     * @param vM The VM reference the VTPM will be attached to 
     * @param isUnique Whether the VTPM must be unique 
     * @return The reference of the newly created VTPM
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VTPM create(Connection c, VM vM, Boolean isUnique) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, vM, isUnique };
        var typeReference = new TypeReference<VTPM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VTPM instance, and return its handle.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 22.26.0.
     *
     * @param c The connection the call is made on
     * @param vM The VM reference the VTPM will be attached to 
     * @param isUnique Whether the VTPM must be unique 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, VM vM, Boolean isUnique) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VTPM.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, vM, isUnique };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy the specified VTPM instance, along with its state.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 22.26.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy the specified VTPM instance, along with its state.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 22.26.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VTPM.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the VTPMs known to the system.
     * Minimum allowed role: read-only
     * Experimental. First published in 22.26.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VTPM> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<VTPM>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of VTPM references to VTPM records for all VTPMs known to the system.
     * Minimum allowed role: read-only
     * Experimental. First published in 22.26.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<VTPM, VTPM.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VTPM.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<VTPM, VTPM.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}