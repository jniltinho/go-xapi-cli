/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A physical host
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class Host extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    Host(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a Host, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Host)
        {
            Host other = (Host) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a Host
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "memoryOverhead", this.memoryOverhead);
            print.printf("%1$20s: %2$s\n", "allowedOperations", this.allowedOperations);
            print.printf("%1$20s: %2$s\n", "currentOperations", this.currentOperations);
            print.printf("%1$20s: %2$s\n", "APIVersionMajor", this.APIVersionMajor);
            print.printf("%1$20s: %2$s\n", "APIVersionMinor", this.APIVersionMinor);
            print.printf("%1$20s: %2$s\n", "APIVersionVendor", this.APIVersionVendor);
            print.printf("%1$20s: %2$s\n", "APIVersionVendorImplementation", this.APIVersionVendorImplementation);
            print.printf("%1$20s: %2$s\n", "enabled", this.enabled);
            print.printf("%1$20s: %2$s\n", "softwareVersion", this.softwareVersion);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "capabilities", this.capabilities);
            print.printf("%1$20s: %2$s\n", "cpuConfiguration", this.cpuConfiguration);
            print.printf("%1$20s: %2$s\n", "schedPolicy", this.schedPolicy);
            print.printf("%1$20s: %2$s\n", "supportedBootloaders", this.supportedBootloaders);
            print.printf("%1$20s: %2$s\n", "residentVMs", this.residentVMs);
            print.printf("%1$20s: %2$s\n", "logging", this.logging);
            print.printf("%1$20s: %2$s\n", "PIFs", this.PIFs);
            print.printf("%1$20s: %2$s\n", "suspendImageSr", this.suspendImageSr);
            print.printf("%1$20s: %2$s\n", "crashDumpSr", this.crashDumpSr);
            print.printf("%1$20s: %2$s\n", "crashdumps", this.crashdumps);
            print.printf("%1$20s: %2$s\n", "patches", this.patches);
            print.printf("%1$20s: %2$s\n", "updates", this.updates);
            print.printf("%1$20s: %2$s\n", "PBDs", this.PBDs);
            print.printf("%1$20s: %2$s\n", "hostCPUs", this.hostCPUs);
            print.printf("%1$20s: %2$s\n", "cpuInfo", this.cpuInfo);
            print.printf("%1$20s: %2$s\n", "hostname", this.hostname);
            print.printf("%1$20s: %2$s\n", "address", this.address);
            print.printf("%1$20s: %2$s\n", "metrics", this.metrics);
            print.printf("%1$20s: %2$s\n", "licenseParams", this.licenseParams);
            print.printf("%1$20s: %2$s\n", "haStatefiles", this.haStatefiles);
            print.printf("%1$20s: %2$s\n", "haNetworkPeers", this.haNetworkPeers);
            print.printf("%1$20s: %2$s\n", "blobs", this.blobs);
            print.printf("%1$20s: %2$s\n", "tags", this.tags);
            print.printf("%1$20s: %2$s\n", "externalAuthType", this.externalAuthType);
            print.printf("%1$20s: %2$s\n", "externalAuthServiceName", this.externalAuthServiceName);
            print.printf("%1$20s: %2$s\n", "externalAuthConfiguration", this.externalAuthConfiguration);
            print.printf("%1$20s: %2$s\n", "edition", this.edition);
            print.printf("%1$20s: %2$s\n", "licenseServer", this.licenseServer);
            print.printf("%1$20s: %2$s\n", "biosStrings", this.biosStrings);
            print.printf("%1$20s: %2$s\n", "powerOnMode", this.powerOnMode);
            print.printf("%1$20s: %2$s\n", "powerOnConfig", this.powerOnConfig);
            print.printf("%1$20s: %2$s\n", "localCacheSr", this.localCacheSr);
            print.printf("%1$20s: %2$s\n", "chipsetInfo", this.chipsetInfo);
            print.printf("%1$20s: %2$s\n", "PCIs", this.PCIs);
            print.printf("%1$20s: %2$s\n", "PGPUs", this.PGPUs);
            print.printf("%1$20s: %2$s\n", "PUSBs", this.PUSBs);
            print.printf("%1$20s: %2$s\n", "sslLegacy", this.sslLegacy);
            print.printf("%1$20s: %2$s\n", "guestVCPUsParams", this.guestVCPUsParams);
            print.printf("%1$20s: %2$s\n", "display", this.display);
            print.printf("%1$20s: %2$s\n", "virtualHardwarePlatformVersions", this.virtualHardwarePlatformVersions);
            print.printf("%1$20s: %2$s\n", "controlDomain", this.controlDomain);
            print.printf("%1$20s: %2$s\n", "updatesRequiringReboot", this.updatesRequiringReboot);
            print.printf("%1$20s: %2$s\n", "features", this.features);
            print.printf("%1$20s: %2$s\n", "iscsiIqn", this.iscsiIqn);
            print.printf("%1$20s: %2$s\n", "multipathing", this.multipathing);
            print.printf("%1$20s: %2$s\n", "uefiCertificates", this.uefiCertificates);
            print.printf("%1$20s: %2$s\n", "certificates", this.certificates);
            print.printf("%1$20s: %2$s\n", "editions", this.editions);
            print.printf("%1$20s: %2$s\n", "pendingGuidances", this.pendingGuidances);
            print.printf("%1$20s: %2$s\n", "tlsVerificationEnabled", this.tlsVerificationEnabled);
            print.printf("%1$20s: %2$s\n", "lastSoftwareUpdate", this.lastSoftwareUpdate);
            print.printf("%1$20s: %2$s\n", "httpsOnly", this.httpsOnly);
            print.printf("%1$20s: %2$s\n", "latestSyncedUpdatesApplied", this.latestSyncedUpdatesApplied);
            print.printf("%1$20s: %2$s\n", "numaAffinityPolicy", this.numaAffinityPolicy);
            print.printf("%1$20s: %2$s\n", "pendingGuidancesRecommended", this.pendingGuidancesRecommended);
            print.printf("%1$20s: %2$s\n", "pendingGuidancesFull", this.pendingGuidancesFull);
            print.printf("%1$20s: %2$s\n", "lastUpdateHash", this.lastUpdateHash);
            print.printf("%1$20s: %2$s\n", "sshEnabled", this.sshEnabled);
            print.printf("%1$20s: %2$s\n", "sshEnabledTimeout", this.sshEnabledTimeout);
            print.printf("%1$20s: %2$s\n", "sshExpiry", this.sshExpiry);
            print.printf("%1$20s: %2$s\n", "consoleIdleTimeout", this.consoleIdleTimeout);
            print.printf("%1$20s: %2$s\n", "sshAutoMode", this.sshAutoMode);
            return writer.toString();
        }

        /**
         * Convert a Host.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("memory_overhead", this.memoryOverhead == null ? 0 : this.memoryOverhead);
            map.put("allowed_operations", this.allowedOperations == null ? new LinkedHashSet<Types.HostAllowedOperations>() : this.allowedOperations);
            map.put("current_operations", this.currentOperations == null ? new HashMap<String, Types.HostAllowedOperations>() : this.currentOperations);
            map.put("API_version_major", this.APIVersionMajor == null ? 0 : this.APIVersionMajor);
            map.put("API_version_minor", this.APIVersionMinor == null ? 0 : this.APIVersionMinor);
            map.put("API_version_vendor", this.APIVersionVendor == null ? "" : this.APIVersionVendor);
            map.put("API_version_vendor_implementation", this.APIVersionVendorImplementation == null ? new HashMap<String, String>() : this.APIVersionVendorImplementation);
            map.put("enabled", this.enabled == null ? false : this.enabled);
            map.put("software_version", this.softwareVersion == null ? new HashMap<String, String>() : this.softwareVersion);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("capabilities", this.capabilities == null ? new LinkedHashSet<String>() : this.capabilities);
            map.put("cpu_configuration", this.cpuConfiguration == null ? new HashMap<String, String>() : this.cpuConfiguration);
            map.put("sched_policy", this.schedPolicy == null ? "" : this.schedPolicy);
            map.put("supported_bootloaders", this.supportedBootloaders == null ? new LinkedHashSet<String>() : this.supportedBootloaders);
            map.put("resident_VMs", this.residentVMs == null ? new LinkedHashSet<VM>() : this.residentVMs);
            map.put("logging", this.logging == null ? new HashMap<String, String>() : this.logging);
            map.put("PIFs", this.PIFs == null ? new LinkedHashSet<PIF>() : this.PIFs);
            map.put("suspend_image_sr", this.suspendImageSr == null ? new SR("OpaqueRef:NULL") : this.suspendImageSr);
            map.put("crash_dump_sr", this.crashDumpSr == null ? new SR("OpaqueRef:NULL") : this.crashDumpSr);
            map.put("crashdumps", this.crashdumps == null ? new LinkedHashSet<HostCrashdump>() : this.crashdumps);
            map.put("patches", this.patches == null ? new LinkedHashSet<HostPatch>() : this.patches);
            map.put("updates", this.updates == null ? new LinkedHashSet<PoolUpdate>() : this.updates);
            map.put("PBDs", this.PBDs == null ? new LinkedHashSet<PBD>() : this.PBDs);
            map.put("host_CPUs", this.hostCPUs == null ? new LinkedHashSet<HostCpu>() : this.hostCPUs);
            map.put("cpu_info", this.cpuInfo == null ? new HashMap<String, String>() : this.cpuInfo);
            map.put("hostname", this.hostname == null ? "" : this.hostname);
            map.put("address", this.address == null ? "" : this.address);
            map.put("metrics", this.metrics == null ? new HostMetrics("OpaqueRef:NULL") : this.metrics);
            map.put("license_params", this.licenseParams == null ? new HashMap<String, String>() : this.licenseParams);
            map.put("ha_statefiles", this.haStatefiles == null ? new LinkedHashSet<String>() : this.haStatefiles);
            map.put("ha_network_peers", this.haNetworkPeers == null ? new LinkedHashSet<String>() : this.haNetworkPeers);
            map.put("blobs", this.blobs == null ? new HashMap<String, Blob>() : this.blobs);
            map.put("tags", this.tags == null ? new LinkedHashSet<String>() : this.tags);
            map.put("external_auth_type", this.externalAuthType == null ? "" : this.externalAuthType);
            map.put("external_auth_service_name", this.externalAuthServiceName == null ? "" : this.externalAuthServiceName);
            map.put("external_auth_configuration", this.externalAuthConfiguration == null ? new HashMap<String, String>() : this.externalAuthConfiguration);
            map.put("edition", this.edition == null ? "" : this.edition);
            map.put("license_server", this.licenseServer == null ? new HashMap<String, String>() : this.licenseServer);
            map.put("bios_strings", this.biosStrings == null ? new HashMap<String, String>() : this.biosStrings);
            map.put("power_on_mode", this.powerOnMode == null ? "" : this.powerOnMode);
            map.put("power_on_config", this.powerOnConfig == null ? new HashMap<String, String>() : this.powerOnConfig);
            map.put("local_cache_sr", this.localCacheSr == null ? new SR("OpaqueRef:NULL") : this.localCacheSr);
            map.put("chipset_info", this.chipsetInfo == null ? new HashMap<String, String>() : this.chipsetInfo);
            map.put("PCIs", this.PCIs == null ? new LinkedHashSet<PCI>() : this.PCIs);
            map.put("PGPUs", this.PGPUs == null ? new LinkedHashSet<PGPU>() : this.PGPUs);
            map.put("PUSBs", this.PUSBs == null ? new LinkedHashSet<PUSB>() : this.PUSBs);
            map.put("ssl_legacy", this.sslLegacy == null ? false : this.sslLegacy);
            map.put("guest_VCPUs_params", this.guestVCPUsParams == null ? new HashMap<String, String>() : this.guestVCPUsParams);
            map.put("display", this.display == null ? Types.HostDisplay.UNRECOGNIZED : this.display);
            map.put("virtual_hardware_platform_versions", this.virtualHardwarePlatformVersions == null ? new LinkedHashSet<Long>() : this.virtualHardwarePlatformVersions);
            map.put("control_domain", this.controlDomain == null ? new VM("OpaqueRef:NULL") : this.controlDomain);
            map.put("updates_requiring_reboot", this.updatesRequiringReboot == null ? new LinkedHashSet<PoolUpdate>() : this.updatesRequiringReboot);
            map.put("features", this.features == null ? new LinkedHashSet<Feature>() : this.features);
            map.put("iscsi_iqn", this.iscsiIqn == null ? "" : this.iscsiIqn);
            map.put("multipathing", this.multipathing == null ? false : this.multipathing);
            map.put("uefi_certificates", this.uefiCertificates == null ? "" : this.uefiCertificates);
            map.put("certificates", this.certificates == null ? new LinkedHashSet<Certificate>() : this.certificates);
            map.put("editions", this.editions == null ? new LinkedHashSet<String>() : this.editions);
            map.put("pending_guidances", this.pendingGuidances == null ? new LinkedHashSet<Types.UpdateGuidances>() : this.pendingGuidances);
            map.put("tls_verification_enabled", this.tlsVerificationEnabled == null ? false : this.tlsVerificationEnabled);
            map.put("last_software_update", this.lastSoftwareUpdate == null ? new Date(0) : this.lastSoftwareUpdate);
            map.put("https_only", this.httpsOnly == null ? false : this.httpsOnly);
            map.put("latest_synced_updates_applied", this.latestSyncedUpdatesApplied == null ? Types.LatestSyncedUpdatesAppliedState.UNRECOGNIZED : this.latestSyncedUpdatesApplied);
            map.put("numa_affinity_policy", this.numaAffinityPolicy == null ? Types.HostNumaAffinityPolicy.UNRECOGNIZED : this.numaAffinityPolicy);
            map.put("pending_guidances_recommended", this.pendingGuidancesRecommended == null ? new LinkedHashSet<Types.UpdateGuidances>() : this.pendingGuidancesRecommended);
            map.put("pending_guidances_full", this.pendingGuidancesFull == null ? new LinkedHashSet<Types.UpdateGuidances>() : this.pendingGuidancesFull);
            map.put("last_update_hash", this.lastUpdateHash == null ? "" : this.lastUpdateHash);
            map.put("ssh_enabled", this.sshEnabled == null ? false : this.sshEnabled);
            map.put("ssh_enabled_timeout", this.sshEnabledTimeout == null ? 0 : this.sshEnabledTimeout);
            map.put("ssh_expiry", this.sshExpiry == null ? new Date(0) : this.sshExpiry);
            map.put("console_idle_timeout", this.consoleIdleTimeout == null ? 0 : this.consoleIdleTimeout);
            map.put("ssh_auto_mode", this.sshAutoMode == null ? false : this.sshAutoMode);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * Virtualization memory overhead (bytes).
         */
        @JsonProperty("memory_overhead")
        public Long memoryOverhead;

        /**
         * list of the operations allowed in this state. This list is advisory only and the server state may have changed by the time this field is read by a client.
         */
        @JsonProperty("allowed_operations")
        public Set<Types.HostAllowedOperations> allowedOperations;

        /**
         * links each of the running tasks using this object (by reference) to a current_operation enum which describes the nature of the task.
         */
        @JsonProperty("current_operations")
        public Map<String, Types.HostAllowedOperations> currentOperations;

        /**
         * major version number
         */
        @JsonProperty("API_version_major")
        public Long APIVersionMajor;

        /**
         * minor version number
         */
        @JsonProperty("API_version_minor")
        public Long APIVersionMinor;

        /**
         * identification of vendor
         */
        @JsonProperty("API_version_vendor")
        public String APIVersionVendor;

        /**
         * details of vendor implementation
         */
        @JsonProperty("API_version_vendor_implementation")
        public Map<String, String> APIVersionVendorImplementation;

        /**
         * True if the host is currently enabled
         */
        @JsonProperty("enabled")
        public Boolean enabled;

        /**
         * version strings
         */
        @JsonProperty("software_version")
        public Map<String, String> softwareVersion;

        /**
         * additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * Xen capabilities
         */
        @JsonProperty("capabilities")
        public Set<String> capabilities;

        /**
         * The CPU configuration on this host.  May contain keys such as "nr_nodes", "sockets_per_node", "cores_per_socket", or "threads_per_core"
         */
        @JsonProperty("cpu_configuration")
        public Map<String, String> cpuConfiguration;

        /**
         * Scheduler policy currently in force on this host
         */
        @JsonProperty("sched_policy")
        public String schedPolicy;

        /**
         * a list of the bootloaders installed on the machine
         */
        @JsonProperty("supported_bootloaders")
        public Set<String> supportedBootloaders;

        /**
         * list of VMs currently resident on host
         */
        @JsonProperty("resident_VMs")
        public Set<VM> residentVMs;

        /**
         * logging configuration
         */
        @JsonProperty("logging")
        public Map<String, String> logging;

        /**
         * physical network interfaces
         */
        @JsonProperty("PIFs")
        public Set<PIF> PIFs;

        /**
         * The SR in which VDIs for suspend images are created
         */
        @JsonProperty("suspend_image_sr")
        public SR suspendImageSr;

        /**
         * The SR in which VDIs for crash dumps are created
         */
        @JsonProperty("crash_dump_sr")
        public SR crashDumpSr;

        /**
         * Set of host crash dumps
         */
        @JsonProperty("crashdumps")
        public Set<HostCrashdump> crashdumps;

        /**
         * Set of host patches
         */
        @JsonProperty("patches")
        @Deprecated(since = "XenServer 4.0")
        public Set<HostPatch> patches;

        /**
         * Set of updates
         * First published in XenServer 7.1.
         */
        @JsonProperty("updates")
        public Set<PoolUpdate> updates;

        /**
         * physical blockdevices
         */
        @JsonProperty("PBDs")
        public Set<PBD> PBDs;

        /**
         * The physical CPUs on this host
         */
        @JsonProperty("host_CPUs")
        public Set<HostCpu> hostCPUs;

        /**
         * Details about the physical CPUs on this host
         * First published in XenServer 5.6.
         */
        @JsonProperty("cpu_info")
        public Map<String, String> cpuInfo;

        /**
         * The hostname of this host
         */
        @JsonProperty("hostname")
        public String hostname;

        /**
         * The address by which this host can be contacted from any other host in the pool
         */
        @JsonProperty("address")
        public String address;

        /**
         * metrics associated with this host
         */
        @JsonProperty("metrics")
        public HostMetrics metrics;

        /**
         * State of the current license
         */
        @JsonProperty("license_params")
        public Map<String, String> licenseParams;

        /**
         * The set of statefiles accessible from this host
         * First published in XenServer 5.0.
         */
        @JsonProperty("ha_statefiles")
        public Set<String> haStatefiles;

        /**
         * The set of hosts visible via the network from this host
         * First published in XenServer 5.0.
         */
        @JsonProperty("ha_network_peers")
        public Set<String> haNetworkPeers;

        /**
         * Binary blobs associated with this host
         * First published in XenServer 5.0.
         */
        @JsonProperty("blobs")
        public Map<String, Blob> blobs;

        /**
         * user-specified tags for categorization purposes
         * First published in XenServer 5.0.
         */
        @JsonProperty("tags")
        public Set<String> tags;

        /**
         * type of external authentication service configured; empty if none configured.
         * First published in XenServer 5.5.
         */
        @JsonProperty("external_auth_type")
        public String externalAuthType;

        /**
         * name of external authentication service configured; empty if none configured.
         * First published in XenServer 5.5.
         */
        @JsonProperty("external_auth_service_name")
        public String externalAuthServiceName;

        /**
         * configuration specific to external authentication service
         * First published in XenServer 5.5.
         */
        @JsonProperty("external_auth_configuration")
        public Map<String, String> externalAuthConfiguration;

        /**
         * Product edition
         * First published in XenServer 5.6.
         */
        @JsonProperty("edition")
        public String edition;

        /**
         * Contact information of the license server
         * First published in XenServer 5.6.
         */
        @JsonProperty("license_server")
        public Map<String, String> licenseServer;

        /**
         * BIOS strings
         * First published in XenServer 5.6.
         */
        @JsonProperty("bios_strings")
        public Map<String, String> biosStrings;

        /**
         * The power on mode
         * First published in XenServer 5.6.
         */
        @JsonProperty("power_on_mode")
        public String powerOnMode;

        /**
         * The power on config
         * First published in XenServer 5.6.
         */
        @JsonProperty("power_on_config")
        public Map<String, String> powerOnConfig;

        /**
         * The SR that is used as a local cache
         * First published in XenServer 5.6 FP1.
         */
        @JsonProperty("local_cache_sr")
        public SR localCacheSr;

        /**
         * Information about chipset features
         * First published in XenServer 6.0.
         */
        @JsonProperty("chipset_info")
        public Map<String, String> chipsetInfo;

        /**
         * List of PCI devices in the host
         * First published in XenServer 6.0.
         */
        @JsonProperty("PCIs")
        public Set<PCI> PCIs;

        /**
         * List of physical GPUs in the host
         * First published in XenServer 6.0.
         */
        @JsonProperty("PGPUs")
        public Set<PGPU> PGPUs;

        /**
         * List of physical USBs in the host
         * First published in XenServer 7.3.
         */
        @JsonProperty("PUSBs")
        public Set<PUSB> PUSBs;

        /**
         * Allow SSLv3 protocol and ciphersuites as used by older server versions. This controls both incoming and outgoing connections. When this is set to a different value, the host immediately restarts its SSL/TLS listening service; typically this takes less than a second but existing connections to it will be broken. API login sessions will remain valid.
         * First published in XenServer 7.0.
         */
        @JsonProperty("ssl_legacy")
        @Deprecated(since = "XenServer 7.0")
        public Boolean sslLegacy;

        /**
         * VCPUs params to apply to all resident guests
         * First published in XenServer 6.1.
         */
        @JsonProperty("guest_VCPUs_params")
        public Map<String, String> guestVCPUsParams;

        /**
         * indicates whether the host is configured to output its console to a physical display device
         * First published in XenServer 6.5 SP1.
         */
        @JsonProperty("display")
        public Types.HostDisplay display;

        /**
         * The set of versions of the virtual hardware platform that the host can offer to its guests
         * First published in XenServer 6.5 SP1.
         */
        @JsonProperty("virtual_hardware_platform_versions")
        public Set<Long> virtualHardwarePlatformVersions;

        /**
         * The control domain (domain 0)
         * First published in XenServer 7.1.
         */
        @JsonProperty("control_domain")
        public VM controlDomain;

        /**
         * List of updates which require reboot
         * First published in XenServer 7.1.
         */
        @JsonProperty("updates_requiring_reboot")
        public Set<PoolUpdate> updatesRequiringReboot;

        /**
         * List of features available on this host
         * First published in XenServer 7.2.
         */
        @JsonProperty("features")
        public Set<Feature> features;

        /**
         * The initiator IQN for the host
         * First published in XenServer 7.5.
         */
        @JsonProperty("iscsi_iqn")
        public String iscsiIqn;

        /**
         * Specifies whether multipathing is enabled
         * First published in XenServer 7.5.
         */
        @JsonProperty("multipathing")
        public Boolean multipathing;

        /**
         * The UEFI certificates allowing Secure Boot
         * First published in Citrix Hypervisor 8.1.
         */
        @JsonProperty("uefi_certificates")
        @Deprecated(since = "Citrix Hypervisor 8.1")
        public String uefiCertificates;

        /**
         * List of certificates installed in the host
         * First published in Citrix Hypervisor 8.2.
         */
        @JsonProperty("certificates")
        public Set<Certificate> certificates;

        /**
         * List of all available product editions
         * First published in Citrix Hypervisor 8.2.
         */
        @JsonProperty("editions")
        public Set<String> editions;

        /**
         * The set of pending mandatory guidances after applying updates, which must be applied, as otherwise there may be e.g. VM failures
         * First published in 1.303.0.
         */
        @JsonProperty("pending_guidances")
        public Set<Types.UpdateGuidances> pendingGuidances;

        /**
         * True if this host has TLS verifcation enabled
         * First published in 1.313.0.
         */
        @JsonProperty("tls_verification_enabled")
        public Boolean tlsVerificationEnabled;

        /**
         * Date and time when the last software update was applied
         * Experimental. First published in 22.20.0.
         */
        @JsonProperty("last_software_update")
        public Date lastSoftwareUpdate;

        /**
         * Reflects whether port 80 is open (false) or not (true)
         * Experimental. First published in 22.27.0.
         */
        @JsonProperty("https_only")
        public Boolean httpsOnly;

        /**
         * Default as 'unknown', 'yes' if the host is up to date with updates synced from remote CDN, otherwise 'no'
         * Experimental. First published in 23.18.0.
         */
        @JsonProperty("latest_synced_updates_applied")
        public Types.LatestSyncedUpdatesAppliedState latestSyncedUpdatesApplied;

        /**
         * NUMA-aware VM memory and vCPU placement policy
         * Experimental. First published in 24.0.0.
         */
        @JsonProperty("numa_affinity_policy")
        public Types.HostNumaAffinityPolicy numaAffinityPolicy;

        /**
         * The set of pending recommended guidances after applying updates, which most users should follow to make the updates effective, but if not followed, will not cause a failure
         * Experimental. First published in 24.10.0.
         */
        @JsonProperty("pending_guidances_recommended")
        public Set<Types.UpdateGuidances> pendingGuidancesRecommended;

        /**
         * The set of pending full guidances after applying updates, which a user should follow to make some updates, e.g. specific hardware drivers or CPU features, fully effective, but the 'average user' doesn't need to
         * Experimental. First published in 24.10.0.
         */
        @JsonProperty("pending_guidances_full")
        public Set<Types.UpdateGuidances> pendingGuidancesFull;

        /**
         * The SHA256 checksum of updateinfo of the most recently applied update on the host
         * Experimental. First published in 24.10.0.
         */
        @JsonProperty("last_update_hash")
        public String lastUpdateHash;

        /**
         * True if SSH access is enabled for the host
         * Experimental. First published in 25.21.0.
         */
        @JsonProperty("ssh_enabled")
        public Boolean sshEnabled;

        /**
         * The timeout in seconds after which SSH access will be automatically disabled (0 means never), this setting will be applied every time the SSH is enabled by XAPI
         * Experimental. First published in 25.21.0.
         */
        @JsonProperty("ssh_enabled_timeout")
        public Long sshEnabledTimeout;

        /**
         * The time in UTC after which the SSH access will be automatically disabled
         * Experimental. First published in 25.21.0.
         */
        @JsonProperty("ssh_expiry")
        public Date sshExpiry;

        /**
         * The timeout in seconds after which idle console will be automatically terminated (0 means never)
         * Experimental. First published in 25.21.0.
         */
        @JsonProperty("console_idle_timeout")
        public Long consoleIdleTimeout;

        /**
         * Reflects whether SSH auto mode is enabled for the host
         * Experimental. First published in 25.27.0.
         */
        @JsonProperty("ssh_auto_mode")
        public Boolean sshAutoMode;

    }

    /**
     * Get a record containing the current state of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the host instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Host getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the host instances with the given label.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Host> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<Host>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the memory/overhead field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getMemoryOverhead(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_memory_overhead";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allowed_operations field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.HostAllowedOperations> getAllowedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.HostAllowedOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the current_operations field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Types.HostAllowedOperations> getCurrentOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_current_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Types.HostAllowedOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the API_version/major field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getAPIVersionMajor(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_API_version_major";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the API_version/minor field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getAPIVersionMinor(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_API_version_minor";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the API_version/vendor field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getAPIVersionVendor(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_API_version_vendor";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the API_version/vendor_implementation field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getAPIVersionVendorImplementation(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_API_version_vendor_implementation";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the enabled field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the software_version field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getSoftwareVersion(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_software_version";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the capabilities field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getCapabilities(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_capabilities";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the cpu_configuration field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getCpuConfiguration(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_cpu_configuration";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the sched_policy field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getSchedPolicy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_sched_policy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the supported_bootloaders field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getSupportedBootloaders(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_supported_bootloaders";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the resident_VMs field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VM> getResidentVMs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_resident_VMs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VM>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the logging field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getLogging(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_logging";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PIFs field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PIF> getPIFs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_PIFs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PIF>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the suspend_image_sr field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public SR getSuspendImageSr(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_suspend_image_sr";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the crash_dump_sr field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public SR getCrashDumpSr(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_crash_dump_sr";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the crashdumps field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<HostCrashdump> getCrashdumps(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_crashdumps";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<HostCrashdump>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the patches field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public Set<HostPatch> getPatches(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_patches";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<HostPatch>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the updates field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PoolUpdate> getUpdates(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_updates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PoolUpdate>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PBDs field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PBD> getPBDs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_PBDs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PBD>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host_CPUs field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<HostCpu> getHostCPUs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_host_CPUs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<HostCpu>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the cpu_info field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getCpuInfo(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_cpu_info";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the hostname field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getHostname(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_hostname";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the address field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getAddress(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_address";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the metrics field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public HostMetrics getMetrics(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_metrics";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<HostMetrics>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the license_params field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getLicenseParams(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_license_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_statefiles field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getHaStatefiles(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_ha_statefiles";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_network_peers field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getHaNetworkPeers(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_ha_network_peers";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the blobs field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Blob> getBlobs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_blobs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Blob>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the tags field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getTags(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the external_auth_type field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getExternalAuthType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_external_auth_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the external_auth_service_name field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getExternalAuthServiceName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_external_auth_service_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the external_auth_configuration field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getExternalAuthConfiguration(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_external_auth_configuration";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the edition field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getEdition(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_edition";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the license_server field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getLicenseServer(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_license_server";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the bios_strings field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getBiosStrings(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_bios_strings";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the power_on_mode field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getPowerOnMode(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_power_on_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the power_on_config field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getPowerOnConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_power_on_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the local_cache_sr field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public SR getLocalCacheSr(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_local_cache_sr";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the chipset_info field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getChipsetInfo(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_chipset_info";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PCIs field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PCI> getPCIs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_PCIs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PCI>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PGPUs field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PGPU> getPGPUs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_PGPUs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PGPU>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PUSBs field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PUSB> getPUSBs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_PUSBs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PUSB>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ssl_legacy field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     * @deprecated since Citrix Hypervisor 8.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "Citrix Hypervisor 8.2")
    public Boolean getSslLegacy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_ssl_legacy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the guest_VCPUs_params field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getGuestVCPUsParams(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_guest_VCPUs_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the display field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 6.5 SP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.HostDisplay getDisplay(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_display";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.HostDisplay>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the virtual_hardware_platform_versions field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 6.5 SP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Long> getVirtualHardwarePlatformVersions(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_virtual_hardware_platform_versions";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Long>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the control_domain field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VM getControlDomain(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_control_domain";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the updates_requiring_reboot field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PoolUpdate> getUpdatesRequiringReboot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_updates_requiring_reboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PoolUpdate>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the features field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Feature> getFeatures(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_features";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Feature>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the iscsi_iqn field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getIscsiIqn(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_iscsi_iqn";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the multipathing field of the given host.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getMultipathing(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_multipathing";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uefi_certificates field of the given host.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.1.
     * @deprecated since 22.16.0
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "22.16.0")
    public String getUefiCertificates(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_uefi_certificates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the certificates field of the given host.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Certificate> getCertificates(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_certificates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Certificate>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the editions field of the given host.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getEditions(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_editions";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the pending_guidances field of the given host.
     * Minimum allowed role: read-only
     * First published in 1.303.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.UpdateGuidances> getPendingGuidances(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_pending_guidances";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.UpdateGuidances>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the tls_verification_enabled field of the given host.
     * Minimum allowed role: read-only
     * First published in 1.313.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getTlsVerificationEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_tls_verification_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the last_software_update field of the given host.
     * Minimum allowed role: read-only
     * Experimental. First published in 22.20.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getLastSoftwareUpdate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_last_software_update";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the https_only field of the given host.
     * Minimum allowed role: read-only
     * Experimental. First published in 22.27.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getHttpsOnly(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_https_only";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the latest_synced_updates_applied field of the given host.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.18.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.LatestSyncedUpdatesAppliedState getLatestSyncedUpdatesApplied(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_latest_synced_updates_applied";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.LatestSyncedUpdatesAppliedState>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the numa_affinity_policy field of the given host.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.0.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.HostNumaAffinityPolicy getNumaAffinityPolicy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_numa_affinity_policy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.HostNumaAffinityPolicy>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the pending_guidances_recommended field of the given host.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.10.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.UpdateGuidances> getPendingGuidancesRecommended(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_pending_guidances_recommended";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.UpdateGuidances>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the pending_guidances_full field of the given host.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.10.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.UpdateGuidances> getPendingGuidancesFull(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_pending_guidances_full";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.UpdateGuidances>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the last_update_hash field of the given host.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.10.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getLastUpdateHash(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_last_update_hash";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ssh_enabled field of the given host.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.21.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getSshEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_ssh_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ssh_enabled_timeout field of the given host.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.21.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getSshEnabledTimeout(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_ssh_enabled_timeout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ssh_expiry field of the given host.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.21.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getSshExpiry(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_ssh_expiry";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the console_idle_timeout field of the given host.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.21.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getConsoleIdleTimeout(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_console_idle_timeout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ssh_auto_mode field of the given host.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.27.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getSshAutoMode(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_ssh_auto_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name/label field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param label New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, label };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name/description field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param description New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameDescription(Connection c, String description) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, description };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the other_config field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given host.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the logging field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param logging New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setLogging(Connection c, Map<String, String> logging) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_logging";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, logging };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the logging field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToLogging(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.add_to_logging";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the logging field of the given host.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromLogging(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.remove_from_logging";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the suspend_image_sr field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param suspendImageSr New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSuspendImageSr(Connection c, SR suspendImageSr) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_suspend_image_sr";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, suspendImageSr };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the crash_dump_sr field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param crashDumpSr New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setCrashDumpSr(Connection c, SR crashDumpSr) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_crash_dump_sr";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, crashDumpSr };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the hostname field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param hostname New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHostname(Connection c, String hostname) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_hostname";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, hostname };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the address field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param address New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setAddress(Connection c, String address) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_address";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, address };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the tags field of the given host.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param tags New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setTags(Connection c, Set<String> tags) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, tags };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given value to the tags field of the given host.  If the value is already in that Set, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value New value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addTags(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.add_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given value from the tags field of the given host.  If the value is not in that Set, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value Value to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeTags(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.remove_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the license_server field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param licenseServer New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setLicenseServer(Connection c, Map<String, String> licenseServer) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_license_server";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, licenseServer };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the license_server field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToLicenseServer(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.add_to_license_server";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the license_server field of the given host.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromLicenseServer(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.remove_from_license_server";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the guest_VCPUs_params field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param guestVCPUsParams New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setGuestVCPUsParams(Connection c, Map<String, String> guestVCPUsParams) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_guest_VCPUs_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, guestVCPUsParams };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the guest_VCPUs_params field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToGuestVCPUsParams(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.add_to_guest_VCPUs_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the guest_VCPUs_params field of the given host.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromGuestVCPUsParams(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.remove_from_guest_VCPUs_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the display field of the given host.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1.
     *
     * @param c The connection the call is made on
     * @param display New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setDisplay(Connection c, Types.HostDisplay display) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_display";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, display };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Puts the host into a state in which no new VMs can be started. Currently active VMs on the host continue to execute.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void disable(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.disable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Puts the host into a state in which no new VMs can be started. Currently active VMs on the host continue to execute.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task disableAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.disable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Puts the host into a state in which new VMs can be started.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void enable(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.enable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Puts the host into a state in which new VMs can be started.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task enableAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.enable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Shutdown the host. (This function can only be called if there are no currently running VMs on the host and it is disabled.)
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void shutdown(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Shutdown the host. (This function can only be called if there are no currently running VMs on the host and it is disabled.)
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task shutdownAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Reboot the host. (This function can only be called if there are no currently running VMs on the host and it is disabled.)
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void reboot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.reboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Reboot the host. (This function can only be called if there are no currently running VMs on the host and it is disabled.)
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task rebootAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.reboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host xen dmesg.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return dmesg string
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String dmesg(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.dmesg";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host xen dmesg.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task dmesgAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.dmesg";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host xen dmesg, and clear the buffer.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return dmesg string
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String dmesgClear(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.dmesg_clear";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host xen dmesg, and clear the buffer.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task dmesgClearAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.dmesg_clear";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host's log file
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return The contents of the host's primary log file
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getLog(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_log";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host's log file
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getLogAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.get_log";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Inject the given string as debugging keys into Xen
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param keys The keys to send 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void sendDebugKeys(Connection c, String keys) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.send_debug_keys";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, keys };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Inject the given string as debugging keys into Xen
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param keys The keys to send 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task sendDebugKeysAsync(Connection c, String keys) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.send_debug_keys";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, keys };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Run xen-bugtool --yestoall and upload the output to support
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param url The URL to upload to 
     * @param options Extra configuration operations 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void bugreportUpload(Connection c, String url, Map<String, String> options) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.bugreport_upload";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, url, options };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Run xen-bugtool --yestoall and upload the output to support
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param url The URL to upload to 
     * @param options Extra configuration operations 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task bugreportUploadAsync(Connection c, String url, Map<String, String> options) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.bugreport_upload";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, url, options };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * List all supported methods
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return The name of every supported method.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<String> listMethods(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.list_methods";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Apply a new license to a host
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param contents The contents of the license file, base64 encoded 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.LicenseProcessingError There was an error processing your license. Please contact your support representative.
     */
    @Deprecated(since = "XenServer 6.2")
    public void licenseApply(Connection c, String contents) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.LicenseProcessingError {
        String methodCall = "host.license_apply";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, contents };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Apply a new license to a host
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param contents The contents of the license file, base64 encoded 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.LicenseProcessingError There was an error processing your license. Please contact your support representative.
     */
    @Deprecated(since = "XenServer 6.2")
    public Task licenseApplyAsync(Connection c, String contents) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.LicenseProcessingError {
        String methodCall = "Async.host.license_apply";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, contents };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Apply a new license to a host
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1 Hotfix 31.
     *
     * @param c The connection the call is made on
     * @param contents The contents of the license file, base64 encoded 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.LicenseProcessingError There was an error processing your license. Please contact your support representative.
     */
    public void licenseAdd(Connection c, String contents) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.LicenseProcessingError {
        String methodCall = "host.license_add";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, contents };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Apply a new license to a host
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1 Hotfix 31.
     *
     * @param c The connection the call is made on
     * @param contents The contents of the license file, base64 encoded 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.LicenseProcessingError There was an error processing your license. Please contact your support representative.
     */
    public Task licenseAddAsync(Connection c, String contents) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.LicenseProcessingError {
        String methodCall = "Async.host.license_add";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, contents };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Remove any license file from the specified host, and switch that host to the unlicensed edition
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1 Hotfix 31.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void licenseRemove(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.license_remove";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove any license file from the specified host, and switch that host to the unlicensed edition
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1 Hotfix 31.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task licenseRemoveAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.license_remove";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy specified host record in database
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy specified host record in database
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Attempt to power-on the host (if the capability exists).
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void powerOn(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.power_on";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Attempt to power-on the host (if the capability exists).
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task powerOnAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.power_on";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call disables HA on the local host. This should only be used with extreme care.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param soft Disable HA temporarily, revert upon host reboot or further changes, idempotent First published in XenServer 7.1.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void emergencyHaDisable(Connection c, Boolean soft) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.emergency_ha_disable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, soft };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return A set of data sources
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<DataSource.Record> getDataSources(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_data_sources";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<DataSource.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Start recording the specified data source
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param dataSource The data source to record 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void recordDataSource(Connection c, String dataSource) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.record_data_source";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dataSource };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Query the latest value of the specified data source
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param dataSource The data source to query 
     * @return The latest value, averaged over the last 5 seconds
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Double queryDataSource(Connection c, String dataSource) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.query_data_source";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dataSource };
        var typeReference = new TypeReference<Double>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Forget the recorded statistics related to the specified data source
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param dataSource The data source whose archives are to be forgotten 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void forgetDataSourceArchives(Connection c, String dataSource) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.forget_data_source_archives";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dataSource };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Check this host can be evacuated.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void assertCanEvacuate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.assert_can_evacuate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Check this host can be evacuated.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task assertCanEvacuateAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.assert_can_evacuate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a set of VMs which prevent the host being evacuated, with per-VM error codes
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return VMs which block evacuation together with reasons
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<VM, Set<String>> getVmsWhichPreventEvacuation(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_vms_which_prevent_evacuation";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<VM, Set<String>>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a set of VMs which prevent the host being evacuated, with per-VM error codes
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getVmsWhichPreventEvacuationAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.get_vms_which_prevent_evacuation";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a set of VMs which are not co-operating with the host's memory control system
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     * @deprecated since XenServer 6.1
     *
     * @param c The connection the call is made on
     * @return VMs which are not co-operating
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.1")
    public Set<VM> getUncooperativeResidentVMs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_uncooperative_resident_VMs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VM>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a set of VMs which are not co-operating with the host's memory control system
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     * @deprecated since XenServer 6.1
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.1")
    public Task getUncooperativeResidentVMsAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.get_uncooperative_resident_VMs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Migrate all VMs off of this host, where possible.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void evacuate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.evacuate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Migrate all VMs off of this host, where possible.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param network Optional preferred network for migration First published in 1.297.0.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void evacuate(Connection c, Network network) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.evacuate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, network };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Migrate all VMs off of this host, where possible.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param network Optional preferred network for migration First published in 1.297.0.
     * @param evacuateBatchSize The maximum number of VMs to be migrated per batch 0 will use the value `evacuation-batch-size` defined in xapi.conf First published in 23.27.0.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void evacuate(Connection c, Network network, Long evacuateBatchSize) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.evacuate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, network, evacuateBatchSize };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Migrate all VMs off of this host, where possible.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task evacuateAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.evacuate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Migrate all VMs off of this host, where possible.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param network Optional preferred network for migration First published in 1.297.0.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task evacuateAsync(Connection c, Network network) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.evacuate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, network };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Migrate all VMs off of this host, where possible.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param network Optional preferred network for migration First published in 1.297.0.
     * @param evacuateBatchSize The maximum number of VMs to be migrated per batch 0 will use the value `evacuation-batch-size` defined in xapi.conf First published in 23.27.0.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task evacuateAsync(Connection c, Network network, Long evacuateBatchSize) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.evacuate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, network, evacuateBatchSize };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Re-configure syslog logging
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void syslogReconfigure(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.syslog_reconfigure";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Re-configure syslog logging
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task syslogReconfigureAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.syslog_reconfigure";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Reconfigure the management network interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param pif reference to a PIF object corresponding to the management interface 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void managementReconfigure(Connection c, PIF pif) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.management_reconfigure";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, pif };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Reconfigure the management network interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param pif reference to a PIF object corresponding to the management interface 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task managementReconfigureAsync(Connection c, PIF pif) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.management_reconfigure";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, pif };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Reconfigure the management network interface. Should only be used if Host.management_reconfigure is impossible because the network configuration is broken.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param iface name of the interface to use as a management interface 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void localManagementReconfigure(Connection c, String iface) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.local_management_reconfigure";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, iface };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Disable the management network interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void managementDisable(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.management_disable";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Returns the management interface for the specified host
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @return The management interface for the host
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PIF getManagementIface(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_management_interface";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns the management interface for the specified host
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getManagementIfaceAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.get_management_interface";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return An XML fragment containing the system status capabilities.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getSystemStatusCapabilities(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_system_status_capabilities";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Restarts the agent after a 10 second pause. WARNING: this is a dangerous operation. Any operations in progress will be aborted, and unrecoverable data loss may occur. The caller is responsible for ensuring that there are no operations in progress when this method is called.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void restartAgent(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.restart_agent";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Restarts the agent after a 10 second pause. WARNING: this is a dangerous operation. Any operations in progress will be aborted, and unrecoverable data loss may occur. The caller is responsible for ensuring that there are no operations in progress when this method is called.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task restartAgentAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.restart_agent";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Shuts the agent down after a 10 second pause. WARNING: this is a dangerous operation. Any operations in progress will be aborted, and unrecoverable data loss may occur. The caller is responsible for ensuring that there are no operations in progress when this method is called.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void shutdownAgent(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.shutdown_agent";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets the host name to the specified string.  Both the API and lower-level system hostname are changed immediately.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param hostname The new host name 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.HostNameInvalid The server name is invalid.
     */
    public void setHostnameLive(Connection c, String hostname) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.HostNameInvalid {
        String methodCall = "host.set_hostname_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, hostname };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Computes the amount of free memory on the host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return the amount of free memory on the host.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long computeFreeMemory(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.compute_free_memory";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Computes the amount of free memory on the host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task computeFreeMemoryAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.compute_free_memory";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Computes the virtualization memory overhead of a host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return the virtualization memory overhead of the host.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long computeMemoryOverhead(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.compute_memory_overhead";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Computes the virtualization memory overhead of a host.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task computeMemoryOverheadAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.compute_memory_overhead";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This causes the synchronisation of the non-database data (messages, RRDs and so on) stored on the master to be synchronised with the host
     * Minimum allowed role: pool-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void syncData(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.sync_data";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * This causes the RRDs to be backed up to the master
     * Minimum allowed role: pool-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param delay Delay in seconds from when the call is received to perform the backup 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void backupRrds(Connection c, Double delay) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.backup_rrds";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, delay };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this host
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @return The reference of the blob, needed for populating its data
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Blob createNewBlob(Connection c, String name, String mimeType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType };
        var typeReference = new TypeReference<Blob>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this host
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @param _public True if the blob should be publicly available First published in XenServer 6.1.
     * @return The reference of the blob, needed for populating its data
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Blob createNewBlob(Connection c, String name, String mimeType, Boolean _public) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType, _public };
        var typeReference = new TypeReference<Blob>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this host
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task createNewBlobAsync(Connection c, String name, String mimeType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this host
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @param _public True if the blob should be publicly available First published in XenServer 6.1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task createNewBlobAsync(Connection c, String name, String mimeType, Boolean _public) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType, _public };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Call an API plugin on this host
     * Minimum allowed role: pool-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param plugin The name of the plugin 
     * @param fn The name of the function within the plugin 
     * @param args Arguments for the function 
     * @return Result from the plugin
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String callPlugin(Connection c, String plugin, String fn, Map<String, String> args) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.call_plugin";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, plugin, fn, args };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Call an API plugin on this host
     * Minimum allowed role: pool-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param plugin The name of the plugin 
     * @param fn The name of the function within the plugin 
     * @param args Arguments for the function 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task callPluginAsync(Connection c, String plugin, String fn, Map<String, String> args) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.call_plugin";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, plugin, fn, args };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return true if the extension is available on the host
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param name The name of the API call 
     * @return True if the extension exists, false otherwise
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean hasExtension(Connection c, String name) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.has_extension";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return true if the extension is available on the host
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param name The name of the API call 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task hasExtensionAsync(Connection c, String name) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.has_extension";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Call an API extension on this host
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param call Rpc call for the extension 
     * @return Result from the extension
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String callExtension(Connection c, String call) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.call_extension";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, call };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call queries the host's clock for the current time
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return The current time
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getServertime(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_servertime";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call queries the host's clock for the current time in the host's local timezone
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return The current local time
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getServerLocaltime(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_server_localtime";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call enables external authentication on a host
     * Minimum allowed role: pool-admin
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param config A list of key-values containing the configuration data 
     * @param serviceName The name of the service 
     * @param authType The type of authentication (e.g. AD for Active Directory) 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void enableExternalAuth(Connection c, Map<String, String> config, String serviceName, String authType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.enable_external_auth";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, config, serviceName, authType };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * This call disables external authentication on the local host
     * Minimum allowed role: pool-admin
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param config Optional parameters as a list of key-values containing the configuration data 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void disableExternalAuth(Connection c, Map<String, String> config) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.disable_external_auth";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, config };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Retrieves recommended host migrations to perform when evacuating the host from the wlb server. If a VM cannot be migrated from the host the reason is listed instead of a recommendation.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return VMs and the reasons why they would block evacuation, or their target host recommended by the wlb server
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<VM, Set<String>> retrieveWlbEvacuateRecommendations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.retrieve_wlb_evacuate_recommendations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<VM, Set<String>>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Retrieves recommended host migrations to perform when evacuating the host from the wlb server. If a VM cannot be migrated from the host the reason is listed instead of a recommendation.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task retrieveWlbEvacuateRecommendationsAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.retrieve_wlb_evacuate_recommendations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the installed server public TLS certificate.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return The installed server public TLS certificate, in PEM form.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getServerCertificate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_server_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the installed server public TLS certificate.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getServerCertificateAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.get_server_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Replace the internal self-signed host certficate with a new one.
     * Minimum allowed role: pool-admin
     * First published in 1.307.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void refreshServerCertificate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.refresh_server_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Replace the internal self-signed host certficate with a new one.
     * Minimum allowed role: pool-admin
     * First published in 1.307.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task refreshServerCertificateAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.refresh_server_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Install the TLS server certificate.
     * Minimum allowed role: pool-admin
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @param certificate The server certificate, in PEM form 
     * @param privateKey The unencrypted private key used to sign the certificate, in PKCS#8 form 
     * @param certificateChain The certificate chain, in PEM form 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void installServerCertificate(Connection c, String certificate, String privateKey, String certificateChain) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.install_server_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, certificate, privateKey, certificateChain };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Install the TLS server certificate.
     * Minimum allowed role: pool-admin
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @param certificate The server certificate, in PEM form 
     * @param privateKey The unencrypted private key used to sign the certificate, in PKCS#8 form 
     * @param certificateChain The certificate chain, in PEM form 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task installServerCertificateAsync(Connection c, String certificate, String privateKey, String certificateChain) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.install_server_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, certificate, privateKey, certificateChain };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Delete the current TLS server certificate and replace by a new, self-signed one. This should only be used with extreme care.
     * Minimum allowed role: Not Applicable
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void emergencyResetServerCertificate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.emergency_reset_server_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Delete the current TLS server certificate and replace by a new, self-signed one. This should only be used with extreme care.
     * Minimum allowed role: pool-admin
     * First published in 1.290.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void resetServerCertificate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.reset_server_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Delete the current TLS server certificate and replace by a new, self-signed one. This should only be used with extreme care.
     * Minimum allowed role: pool-admin
     * First published in 1.290.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task resetServerCertificateAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.reset_server_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Change to another edition, or reactivate the current edition after a license has expired. This may be subject to the successful checkout of an appropriate license.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param edition The requested edition 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void applyEdition(Connection c, String edition) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.apply_edition";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, edition };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Change to another edition, or reactivate the current edition after a license has expired. This may be subject to the successful checkout of an appropriate license.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param edition The requested edition 
     * @param force Update the license params even if the apply call fails First published in XenServer 6.2.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void applyEdition(Connection c, String edition, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.apply_edition";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, edition, force };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Refresh the list of installed Supplemental Packs.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public void refreshPackInfo(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.refresh_pack_info";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Refresh the list of installed Supplemental Packs.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public Task refreshPackInfoAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.refresh_pack_info";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the power-on-mode, host, user and password
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param powerOnMode power-on-mode can be empty, wake-on-lan, IPMI or other 
     * @param powerOnConfig Power on config 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setPowerOnMode(Connection c, String powerOnMode, Map<String, String> powerOnConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_power_on_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, powerOnMode, powerOnConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the power-on-mode, host, user and password
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param powerOnMode power-on-mode can be empty, wake-on-lan, IPMI or other 
     * @param powerOnConfig Power on config 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setPowerOnModeAsync(Connection c, String powerOnMode, Map<String, String> powerOnConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.set_power_on_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, powerOnMode, powerOnConfig };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the CPU features to be used after a reboot, if the given features string is valid.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     * @deprecated since XenServer 7.0
     *
     * @param c The connection the call is made on
     * @param features The features string (32 hexadecimal digits) 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.0")
    public void setCpuFeatures(Connection c, String features) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_cpu_features";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, features };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the feature mask, such that after a reboot all features of the CPU are enabled.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6.
     * @deprecated since XenServer 7.0
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.0")
    public void resetCpuFeatures(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.reset_cpu_features";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Enable the use of a local SR for caching purposes
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param sr The SR to use as a local cache 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void enableLocalStorageCaching(Connection c, SR sr) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.enable_local_storage_caching";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sr };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Disable the use of a local SR for caching purposes
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void disableLocalStorageCaching(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.disable_local_storage_caching";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Prepare to receive a VM, returning a token which can be passed to VM.migrate.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param network The network through which migration traffic should be received. 
     * @param options Extra configuration operations 
     * @return A value which should be passed to VM.migrate
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> migrateReceive(Connection c, Network network, Map<String, String> options) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.migrate_receive";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, network, options };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Prepare to receive a VM, returning a token which can be passed to VM.migrate.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param network The network through which migration traffic should be received. 
     * @param options Extra configuration operations 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task migrateReceiveAsync(Connection c, Network network, Map<String, String> options) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.migrate_receive";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, network, options };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Declare that a host is dead. This is a dangerous operation, and should only be called if the administrator is absolutely sure the host is definitely dead
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void declareDead(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.declare_dead";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Declare that a host is dead. This is a dangerous operation, and should only be called if the administrator is absolutely sure the host is definitely dead
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task declareDeadAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.declare_dead";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Enable console output to the physical display device next time this host boots
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1.
     *
     * @param c The connection the call is made on
     * @return This host's physical display usage
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.HostDisplay enableDisplay(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.enable_display";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.HostDisplay>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Enable console output to the physical display device next time this host boots
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task enableDisplayAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.enable_display";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Disable console output to the physical display device next time this host boots
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1.
     *
     * @param c The connection the call is made on
     * @return This host's physical display usage
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.HostDisplay disableDisplay(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.disable_display";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.HostDisplay>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Disable console output to the physical display device next time this host boots
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task disableDisplayAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.disable_display";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Enable/disable SSLv3 for interoperability with older server versions. When this is set to a different value, the host immediately restarts its SSL/TLS listening service; typically this takes less than a second but existing connections to it will be broken. API login sessions will remain valid.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param value True to allow SSLv3 and ciphersuites as used in old XenServer versions 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSslLegacy(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_ssl_legacy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Enable/disable SSLv3 for interoperability with older server versions. When this is set to a different value, the host immediately restarts its SSL/TLS listening service; typically this takes less than a second but existing connections to it will be broken. API login sessions will remain valid.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param value True to allow SSLv3 and ciphersuites as used in old XenServer versions 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setSslLegacyAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.set_ssl_legacy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sets the initiator IQN for the host
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @param value The value to which the IQN should be set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setIscsiIqn(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_iscsi_iqn";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets the initiator IQN for the host
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @param value The value to which the IQN should be set 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setIscsiIqnAsync(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.set_iscsi_iqn";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Specifies whether multipathing is enabled
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @param value Whether multipathing should be enabled 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setMultipathing(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_multipathing";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Specifies whether multipathing is enabled
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @param value Whether multipathing should be enabled 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setMultipathingAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.set_multipathing";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sets the UEFI certificates on a host
     * Minimum allowed role: Not Applicable
     * First published in Citrix Hypervisor 8.1.
     * @deprecated since 22.16.0
     *
     * @param c The connection the call is made on
     * @param value The certificates to apply to a host 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "22.16.0")
    public void setUefiCertificates(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_uefi_certificates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets the UEFI certificates on a host
     * Minimum allowed role: Not Applicable
     * First published in Citrix Hypervisor 8.1.
     * @deprecated since 22.16.0
     *
     * @param c The connection the call is made on
     * @param value The certificates to apply to a host 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "22.16.0")
    public Task setUefiCertificatesAsync(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.set_uefi_certificates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sets xen's sched-gran on a host. See: https://xenbits.xen.org/docs/unstable/misc/xen-command-line.html#sched-gran-x86
     * Minimum allowed role: Not Applicable
     * First published in 1.271.0.
     *
     * @param c The connection the call is made on
     * @param value The sched-gran to apply to a host 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSchedGran(Connection c, Types.HostSchedGran value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_sched_gran";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets xen's sched-gran on a host. See: https://xenbits.xen.org/docs/unstable/misc/xen-command-line.html#sched-gran-x86
     * Minimum allowed role: Not Applicable
     * First published in 1.271.0.
     *
     * @param c The connection the call is made on
     * @param value The sched-gran to apply to a host 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setSchedGranAsync(Connection c, Types.HostSchedGran value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.set_sched_gran";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Gets xen's sched-gran on a host
     * Minimum allowed role: Not Applicable
     * First published in 1.271.0.
     *
     * @param c The connection the call is made on
     * @return The host's sched-gran
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.HostSchedGran getSchedGran(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_sched_gran";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.HostSchedGran>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Gets xen's sched-gran on a host
     * Minimum allowed role: Not Applicable
     * First published in 1.271.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getSchedGranAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.get_sched_gran";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set VM placement NUMA affinity policy
     * Minimum allowed role: pool-admin
     * Experimental. First published in 24.0.0.
     *
     * @param c The connection the call is made on
     * @param value The NUMA affinity policy to apply to a host 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNumaAffinityPolicy(Connection c, Types.HostNumaAffinityPolicy value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_numa_affinity_policy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set VM placement NUMA affinity policy
     * Minimum allowed role: pool-admin
     * Experimental. First published in 24.0.0.
     *
     * @param c The connection the call is made on
     * @param value The NUMA affinity policy to apply to a host 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setNumaAffinityPolicyAsync(Connection c, Types.HostNumaAffinityPolicy value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.set_numa_affinity_policy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Disable TLS verification for this host only
     * Minimum allowed role: Not Applicable
     * First published in 1.290.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void emergencyDisableTlsVerification(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.emergency_disable_tls_verification";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Reenable TLS verification for this host only, and only after it was emergency disabled
     * Minimum allowed role: Not Applicable
     * First published in 1.298.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void emergencyReenableTlsVerification(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.emergency_reenable_tls_verification";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * apply updates from current enabled repository on a host
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param hash The hash of updateinfo to be applied which is returned by previous pool.sync_udpates 
     * @return The list of results after applying updates, including livepatch apply failures and recommended guidances
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Set<String>> applyUpdates(Connection c, String hash) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.apply_updates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, hash };
        var typeReference = new TypeReference<Set<Set<String>>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * apply updates from current enabled repository on a host
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param hash The hash of updateinfo to be applied which is returned by previous pool.sync_udpates 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task applyUpdatesAsync(Connection c, String hash) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.apply_updates";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, hash };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Scan the host and update its driver information.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void rescanDrivers(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.rescan_drivers";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Scan the host and update its driver information.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task rescanDriversAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.rescan_drivers";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * updates the host firewall to open or close port 80 depending on the value
     * Minimum allowed role: pool-operator
     * Experimental. First published in 22.27.0.
     *
     * @param c The connection the call is made on
     * @param value true - http port 80 will be blocked, false - http port 80 will be open 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHttpsOnly(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_https_only";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * updates the host firewall to open or close port 80 depending on the value
     * Minimum allowed role: pool-operator
     * Experimental. First published in 22.27.0.
     *
     * @param c The connection the call is made on
     * @param value true - http port 80 will be blocked, false - http port 80 will be open 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setHttpsOnlyAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.set_https_only";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * apply all recommended guidances both on the host and on all HVM VMs on the host after updates are applied on the host
     * Minimum allowed role: pool-operator
     * Experimental. First published in 23.18.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void applyRecommendedGuidances(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.apply_recommended_guidances";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * apply all recommended guidances both on the host and on all HVM VMs on the host after updates are applied on the host
     * Minimum allowed role: pool-operator
     * Experimental. First published in 23.18.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task applyRecommendedGuidancesAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.apply_recommended_guidances";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Clear the pending mandatory guidance on this host
     * Minimum allowed role: Not Applicable
     * Experimental. First published in 24.10.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void emergencyClearMandatoryGuidance(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.emergency_clear_mandatory_guidance";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Enable SSH access on the host. It will start the service sshd only if it is not running. It will also enable the service sshd only if it is not enabled. A newly joined host in the pool or an ejected host from the pool would keep the original status.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.13.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void enableSsh(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.enable_ssh";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Enable SSH access on the host. It will start the service sshd only if it is not running. It will also enable the service sshd only if it is not enabled. A newly joined host in the pool or an ejected host from the pool would keep the original status.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.13.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task enableSshAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.enable_ssh";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Disable SSH access on the host. It will stop the service sshd only if it is running. It will also disable the service sshd only if it is enabled. A newly joined host in the pool or an ejected host from the pool would keep the original status.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.13.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void disableSsh(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.disable_ssh";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Disable SSH access on the host. It will stop the service sshd only if it is running. It will also disable the service sshd only if it is enabled. A newly joined host in the pool or an ejected host from the pool would keep the original status.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.13.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task disableSshAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.disable_ssh";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the SSH service enabled timeout for the host
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.21.0.
     *
     * @param c The connection the call is made on
     * @param value The SSH enabled timeout in seconds (0 means no timeout, max 2 days) 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSshEnabledTimeout(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_ssh_enabled_timeout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the SSH service enabled timeout for the host
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.21.0.
     *
     * @param c The connection the call is made on
     * @param value The SSH enabled timeout in seconds (0 means no timeout, max 2 days) 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setSshEnabledTimeoutAsync(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.set_ssh_enabled_timeout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the console idle timeout for the host
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.21.0.
     *
     * @param c The connection the call is made on
     * @param value The console idle timeout in seconds 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setConsoleIdleTimeout(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_console_idle_timeout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the console idle timeout for the host
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.21.0.
     *
     * @param c The connection the call is made on
     * @param value The console idle timeout in seconds 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setConsoleIdleTimeoutAsync(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.set_console_idle_timeout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the SSH auto mode for the host
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.27.0.
     *
     * @param c The connection the call is made on
     * @param value The SSH auto mode for the host，when set to true, SSH to normally be disabled and SSH to be enabled only in case of emergency e.g., xapi is down 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSshAutoMode(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.set_ssh_auto_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the SSH auto mode for the host
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.27.0.
     *
     * @param c The connection the call is made on
     * @param value The SSH auto mode for the host，when set to true, SSH to normally be disabled and SSH to be enabled only in case of emergency e.g., xapi is down 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setSshAutoModeAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.host.set_ssh_auto_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the hosts known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Host> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<Host>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of host references to host records for all hosts known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<Host, Host.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<Host, Host.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}