/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A tunnel for network traffic
 * First published in XenServer 5.6 FP1.
 *
 * @author Cloud Software Group, Inc.
 */
public class Tunnel extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    Tunnel(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a Tunnel, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Tunnel)
        {
            Tunnel other = (Tunnel) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a Tunnel
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "accessPIF", this.accessPIF);
            print.printf("%1$20s: %2$s\n", "transportPIF", this.transportPIF);
            print.printf("%1$20s: %2$s\n", "status", this.status);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "protocol", this.protocol);
            return writer.toString();
        }

        /**
         * Convert a Tunnel.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("access_PIF", this.accessPIF == null ? new PIF("OpaqueRef:NULL") : this.accessPIF);
            map.put("transport_PIF", this.transportPIF == null ? new PIF("OpaqueRef:NULL") : this.transportPIF);
            map.put("status", this.status == null ? new HashMap<String, String>() : this.status);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("protocol", this.protocol == null ? Types.TunnelProtocol.UNRECOGNIZED : this.protocol);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * The interface through which the tunnel is accessed
         */
        @JsonProperty("access_PIF")
        public PIF accessPIF;

        /**
         * The interface used by the tunnel
         */
        @JsonProperty("transport_PIF")
        public PIF transportPIF;

        /**
         * Status information about the tunnel
         */
        @JsonProperty("status")
        public Map<String, String> status;

        /**
         * Additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * The protocol used for tunneling (either GRE or VxLAN)
         * First published in 1.250.0.
         */
        @JsonProperty("protocol")
        public Types.TunnelProtocol protocol;

    }

    /**
     * Get a record containing the current state of the given tunnel.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Tunnel.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Tunnel.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the tunnel instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Tunnel getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<Tunnel>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given tunnel.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the access_PIF field of the given tunnel.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PIF getAccessPIF(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.get_access_PIF";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the transport_PIF field of the given tunnel.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PIF getTransportPIF(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.get_transport_PIF";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the status field of the given tunnel.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getStatus(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.get_status";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given tunnel.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the protocol field of the given tunnel.
     * Minimum allowed role: read-only
     * First published in 1.250.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.TunnelProtocol getProtocol(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.get_protocol";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.TunnelProtocol>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the status field of the given tunnel.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param status New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setStatus(Connection c, Map<String, String> status) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.set_status";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, status };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the status field of the given tunnel.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToStatus(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.add_to_status";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the status field of the given tunnel.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromStatus(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.remove_from_status";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the other_config field of the given tunnel.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given tunnel.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given tunnel.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the protocol field of the given tunnel.
     * Minimum allowed role: pool-operator
     * First published in 1.250.0.
     *
     * @param c The connection the call is made on
     * @param protocol New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setProtocol(Connection c, Types.TunnelProtocol protocol) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.set_protocol";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, protocol };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Create a tunnel
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param transportPIF PIF which receives the tagged traffic First published in XenServer 7.0.
     * @param network Network to receive the tunnelled traffic First published in XenServer 7.0.
     * @return The reference of the created tunnel object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OpenvswitchNotActive This operation needs the OpenVSwitch networking backend to be enabled on all hosts in the pool.
     * @throws Types.TransportPifNotConfigured The tunnel transport PIF has no IP configuration set.
     * @throws Types.IsTunnelAccessPif Cannot create a VLAN or tunnel on top of a tunnel access PIF - use the underlying transport PIF instead.
     */
    public static Tunnel create(Connection c, PIF transportPIF, Network network) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OpenvswitchNotActive,
    Types.TransportPifNotConfigured,
    Types.IsTunnelAccessPif {
        String methodCall = "tunnel.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, transportPIF, network };
        var typeReference = new TypeReference<Tunnel>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a tunnel
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param transportPIF PIF which receives the tagged traffic First published in XenServer 7.0.
     * @param network Network to receive the tunnelled traffic First published in XenServer 7.0.
     * @param protocol Protocol used for the tunnel (GRE or VxLAN) First published in 1.250.0.
     * @return The reference of the created tunnel object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OpenvswitchNotActive This operation needs the OpenVSwitch networking backend to be enabled on all hosts in the pool.
     * @throws Types.TransportPifNotConfigured The tunnel transport PIF has no IP configuration set.
     * @throws Types.IsTunnelAccessPif Cannot create a VLAN or tunnel on top of a tunnel access PIF - use the underlying transport PIF instead.
     */
    public static Tunnel create(Connection c, PIF transportPIF, Network network, Types.TunnelProtocol protocol) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OpenvswitchNotActive,
    Types.TransportPifNotConfigured,
    Types.IsTunnelAccessPif {
        String methodCall = "tunnel.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, transportPIF, network, protocol };
        var typeReference = new TypeReference<Tunnel>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a tunnel
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param transportPIF PIF which receives the tagged traffic First published in XenServer 7.0.
     * @param network Network to receive the tunnelled traffic First published in XenServer 7.0.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OpenvswitchNotActive This operation needs the OpenVSwitch networking backend to be enabled on all hosts in the pool.
     * @throws Types.TransportPifNotConfigured The tunnel transport PIF has no IP configuration set.
     * @throws Types.IsTunnelAccessPif Cannot create a VLAN or tunnel on top of a tunnel access PIF - use the underlying transport PIF instead.
     */
    public static Task createAsync(Connection c, PIF transportPIF, Network network) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OpenvswitchNotActive,
    Types.TransportPifNotConfigured,
    Types.IsTunnelAccessPif {
        String methodCall = "Async.tunnel.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, transportPIF, network };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a tunnel
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @param transportPIF PIF which receives the tagged traffic First published in XenServer 7.0.
     * @param network Network to receive the tunnelled traffic First published in XenServer 7.0.
     * @param protocol Protocol used for the tunnel (GRE or VxLAN) First published in 1.250.0.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OpenvswitchNotActive This operation needs the OpenVSwitch networking backend to be enabled on all hosts in the pool.
     * @throws Types.TransportPifNotConfigured The tunnel transport PIF has no IP configuration set.
     * @throws Types.IsTunnelAccessPif Cannot create a VLAN or tunnel on top of a tunnel access PIF - use the underlying transport PIF instead.
     */
    public static Task createAsync(Connection c, PIF transportPIF, Network network, Types.TunnelProtocol protocol) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OpenvswitchNotActive,
    Types.TransportPifNotConfigured,
    Types.IsTunnelAccessPif {
        String methodCall = "Async.tunnel.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, transportPIF, network, protocol };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy a tunnel
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy a tunnel
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.tunnel.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the tunnels known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Tunnel> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<Tunnel>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of tunnel references to tunnel records for all tunnels known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<Tunnel, Tunnel.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "tunnel.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<Tunnel, Tunnel.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}