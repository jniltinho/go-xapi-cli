/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A virtual network
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class Network extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    Network(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a Network, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Network)
        {
            Network other = (Network) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a Network
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "allowedOperations", this.allowedOperations);
            print.printf("%1$20s: %2$s\n", "currentOperations", this.currentOperations);
            print.printf("%1$20s: %2$s\n", "VIFs", this.VIFs);
            print.printf("%1$20s: %2$s\n", "PIFs", this.PIFs);
            print.printf("%1$20s: %2$s\n", "MTU", this.MTU);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "bridge", this.bridge);
            print.printf("%1$20s: %2$s\n", "managed", this.managed);
            print.printf("%1$20s: %2$s\n", "blobs", this.blobs);
            print.printf("%1$20s: %2$s\n", "tags", this.tags);
            print.printf("%1$20s: %2$s\n", "defaultLockingMode", this.defaultLockingMode);
            print.printf("%1$20s: %2$s\n", "assignedIps", this.assignedIps);
            print.printf("%1$20s: %2$s\n", "purpose", this.purpose);
            return writer.toString();
        }

        /**
         * Convert a Network.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("allowed_operations", this.allowedOperations == null ? new LinkedHashSet<Types.NetworkOperations>() : this.allowedOperations);
            map.put("current_operations", this.currentOperations == null ? new HashMap<String, Types.NetworkOperations>() : this.currentOperations);
            map.put("VIFs", this.VIFs == null ? new LinkedHashSet<VIF>() : this.VIFs);
            map.put("PIFs", this.PIFs == null ? new LinkedHashSet<PIF>() : this.PIFs);
            map.put("MTU", this.MTU == null ? 0 : this.MTU);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("bridge", this.bridge == null ? "" : this.bridge);
            map.put("managed", this.managed == null ? false : this.managed);
            map.put("blobs", this.blobs == null ? new HashMap<String, Blob>() : this.blobs);
            map.put("tags", this.tags == null ? new LinkedHashSet<String>() : this.tags);
            map.put("default_locking_mode", this.defaultLockingMode == null ? Types.NetworkDefaultLockingMode.UNRECOGNIZED : this.defaultLockingMode);
            map.put("assigned_ips", this.assignedIps == null ? new HashMap<VIF, String>() : this.assignedIps);
            map.put("purpose", this.purpose == null ? new LinkedHashSet<Types.NetworkPurpose>() : this.purpose);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * list of the operations allowed in this state. This list is advisory only and the server state may have changed by the time this field is read by a client.
         */
        @JsonProperty("allowed_operations")
        public Set<Types.NetworkOperations> allowedOperations;

        /**
         * links each of the running tasks using this object (by reference) to a current_operation enum which describes the nature of the task.
         */
        @JsonProperty("current_operations")
        public Map<String, Types.NetworkOperations> currentOperations;

        /**
         * list of connected vifs
         */
        @JsonProperty("VIFs")
        public Set<VIF> VIFs;

        /**
         * list of connected pifs
         */
        @JsonProperty("PIFs")
        public Set<PIF> PIFs;

        /**
         * MTU in octets
         * First published in XenServer 5.6.
         */
        @JsonProperty("MTU")
        public Long MTU;

        /**
         * additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * name of the bridge corresponding to this network on the local host
         */
        @JsonProperty("bridge")
        public String bridge;

        /**
         * true if the bridge is managed by xapi
         * First published in XenServer 7.2.
         */
        @JsonProperty("managed")
        public Boolean managed;

        /**
         * Binary blobs associated with this network
         * First published in XenServer 5.0.
         */
        @JsonProperty("blobs")
        public Map<String, Blob> blobs;

        /**
         * user-specified tags for categorization purposes
         * First published in XenServer 5.0.
         */
        @JsonProperty("tags")
        public Set<String> tags;

        /**
         * The network will use this value to determine the behaviour of all VIFs where locking_mode = default
         * First published in XenServer 6.1.
         */
        @JsonProperty("default_locking_mode")
        public Types.NetworkDefaultLockingMode defaultLockingMode;

        /**
         * The IP addresses assigned to VIFs on networks that have active xapi-managed DHCP
         * First published in XenServer 6.5.
         */
        @JsonProperty("assigned_ips")
        public Map<VIF, String> assignedIps;

        /**
         * Set of purposes for which the server will use this network
         * First published in XenServer 7.3.
         */
        @JsonProperty("purpose")
        public Set<Types.NetworkPurpose> purpose;

    }

    /**
     * Get a record containing the current state of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Network.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Network.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the network instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Network getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<Network>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new network instance, and return its handle.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return reference to the newly created object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Network create(Connection c, Network.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<Network>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new network instance, and return its handle.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, Network.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.network.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy the specified network instance.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy the specified network instance.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.network.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the network instances with the given label.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Network> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<Network>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allowed_operations field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.NetworkOperations> getAllowedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.NetworkOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the current_operations field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Types.NetworkOperations> getCurrentOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_current_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Types.NetworkOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VIFs field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VIF> getVIFs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_VIFs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VIF>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PIFs field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PIF> getPIFs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_PIFs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PIF>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the MTU field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getMTU(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_MTU";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the bridge field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getBridge(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_bridge";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the managed field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getManaged(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_managed";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the blobs field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Blob> getBlobs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_blobs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Blob>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the tags field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getTags(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the default_locking_mode field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.NetworkDefaultLockingMode getDefaultLockingMode(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_default_locking_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.NetworkDefaultLockingMode>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the assigned_ips field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 6.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<VIF, String> getAssignedIps(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_assigned_ips";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<VIF, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the purpose field of the given network.
     * Minimum allowed role: read-only
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.NetworkPurpose> getPurpose(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_purpose";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.NetworkPurpose>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name/label field of the given network.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param label New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, label };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name/description field of the given network.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param description New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameDescription(Connection c, String description) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, description };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the MTU field of the given network.
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param MTU New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setMTU(Connection c, Long MTU) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.set_MTU";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, MTU };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the other_config field of the given network.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given network.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given network.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the tags field of the given network.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param tags New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setTags(Connection c, Set<String> tags) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.set_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, tags };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given value to the tags field of the given network.  If the value is already in that Set, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value New value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addTags(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.add_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given value from the tags field of the given network.  If the value is not in that Set, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value Value to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeTags(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.remove_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @return The reference of the blob, needed for populating its data
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Blob createNewBlob(Connection c, String name, String mimeType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType };
        var typeReference = new TypeReference<Blob>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @param _public True if the blob should be publicly available First published in XenServer 6.1.
     * @return The reference of the blob, needed for populating its data
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Blob createNewBlob(Connection c, String name, String mimeType, Boolean _public) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType, _public };
        var typeReference = new TypeReference<Blob>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task createNewBlobAsync(Connection c, String name, String mimeType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.network.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @param _public True if the blob should be publicly available First published in XenServer 6.1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task createNewBlobAsync(Connection c, String name, String mimeType, Boolean _public) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.network.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType, _public };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the default locking mode for VIFs attached to this network
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param value The default locking mode for VIFs attached to this network. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setDefaultLockingMode(Connection c, Types.NetworkDefaultLockingMode value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.set_default_locking_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the default locking mode for VIFs attached to this network
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param value The default locking mode for VIFs attached to this network. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setDefaultLockingModeAsync(Connection c, Types.NetworkDefaultLockingMode value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.network.set_default_locking_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Give a network a new purpose (if not present already)
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @param value The purpose to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.NetworkIncompatiblePurposes You tried to add a purpose to a network but the new purpose is not compatible with an existing purpose of the network or other networks.
     */
    public void addPurpose(Connection c, Types.NetworkPurpose value) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.NetworkIncompatiblePurposes {
        String methodCall = "network.add_purpose";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Give a network a new purpose (if not present already)
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @param value The purpose to add 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.NetworkIncompatiblePurposes You tried to add a purpose to a network but the new purpose is not compatible with an existing purpose of the network or other networks.
     */
    public Task addPurposeAsync(Connection c, Types.NetworkPurpose value) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.NetworkIncompatiblePurposes {
        String methodCall = "Async.network.add_purpose";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Remove a purpose from a network (if present)
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @param value The purpose to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removePurpose(Connection c, Types.NetworkPurpose value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.remove_purpose";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove a purpose from a network (if present)
     * Minimum allowed role: pool-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @param value The purpose to remove 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task removePurposeAsync(Connection c, Types.NetworkPurpose value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.network.remove_purpose";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the networks known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Network> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<Network>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of network references to network records for all networks known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<Network, Network.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "network.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<Network, Network.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}