/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * Data sources for logging in RRDs
 * First published in XenServer 5.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class DataSource extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    DataSource(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a DataSource, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof DataSource)
        {
            DataSource other = (DataSource) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a DataSource
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "enabled", this.enabled);
            print.printf("%1$20s: %2$s\n", "standard", this.standard);
            print.printf("%1$20s: %2$s\n", "units", this.units);
            print.printf("%1$20s: %2$s\n", "min", this.min);
            print.printf("%1$20s: %2$s\n", "max", this.max);
            print.printf("%1$20s: %2$s\n", "value", this.value);
            return writer.toString();
        }

        /**
         * Convert a DataSource.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("enabled", this.enabled == null ? false : this.enabled);
            map.put("standard", this.standard == null ? false : this.standard);
            map.put("units", this.units == null ? "" : this.units);
            map.put("min", this.min == null ? 0.0 : this.min);
            map.put("max", this.max == null ? 0.0 : this.max);
            map.put("value", this.value == null ? 0.0 : this.value);
            return map;
        }

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * true if the data source is being logged
         */
        @JsonProperty("enabled")
        public Boolean enabled;

        /**
         * true if the data source is enabled by default. Non-default data sources cannot be disabled
         */
        @JsonProperty("standard")
        public Boolean standard;

        /**
         * the units of the value
         */
        @JsonProperty("units")
        public String units;

        /**
         * the minimum value of the data source
         */
        @JsonProperty("min")
        public Double min;

        /**
         * the maximum value of the data source
         */
        @JsonProperty("max")
        public Double max;

        /**
         * current value of the data source
         */
        @JsonProperty("value")
        public Double value;

    }

}