/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A virtual GPU (vGPU)
 * First published in XenServer 6.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class VGPU extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    VGPU(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a VGPU, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof VGPU)
        {
            VGPU other = (VGPU) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a VGPU
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "VM", this.VM);
            print.printf("%1$20s: %2$s\n", "GPUGroup", this.GPUGroup);
            print.printf("%1$20s: %2$s\n", "device", this.device);
            print.printf("%1$20s: %2$s\n", "currentlyAttached", this.currentlyAttached);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "type", this.type);
            print.printf("%1$20s: %2$s\n", "residentOn", this.residentOn);
            print.printf("%1$20s: %2$s\n", "scheduledToBeResidentOn", this.scheduledToBeResidentOn);
            print.printf("%1$20s: %2$s\n", "compatibilityMetadata", this.compatibilityMetadata);
            print.printf("%1$20s: %2$s\n", "extraArgs", this.extraArgs);
            print.printf("%1$20s: %2$s\n", "PCI", this.PCI);
            return writer.toString();
        }

        /**
         * Convert a VGPU.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("VM", this.VM == null ? new VM("OpaqueRef:NULL") : this.VM);
            map.put("GPU_group", this.GPUGroup == null ? new GPUGroup("OpaqueRef:NULL") : this.GPUGroup);
            map.put("device", this.device == null ? "" : this.device);
            map.put("currently_attached", this.currentlyAttached == null ? false : this.currentlyAttached);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("type", this.type == null ? new VGPUType("OpaqueRef:NULL") : this.type);
            map.put("resident_on", this.residentOn == null ? new PGPU("OpaqueRef:NULL") : this.residentOn);
            map.put("scheduled_to_be_resident_on", this.scheduledToBeResidentOn == null ? new PGPU("OpaqueRef:NULL") : this.scheduledToBeResidentOn);
            map.put("compatibility_metadata", this.compatibilityMetadata == null ? new HashMap<String, String>() : this.compatibilityMetadata);
            map.put("extra_args", this.extraArgs == null ? "" : this.extraArgs);
            map.put("PCI", this.PCI == null ? new PCI("OpaqueRef:NULL") : this.PCI);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * VM that owns the vGPU
         */
        @JsonProperty("VM")
        public VM VM;

        /**
         * GPU group used by the vGPU
         */
        @JsonProperty("GPU_group")
        public GPUGroup GPUGroup;

        /**
         * Order in which the devices are plugged into the VM
         */
        @JsonProperty("device")
        public String device;

        /**
         * Reflects whether the virtual device is currently connected to a physical device
         */
        @JsonProperty("currently_attached")
        public Boolean currentlyAttached;

        /**
         * Additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * Preset type for this VGPU
         * First published in XenServer 6.2 SP1 Tech-Preview.
         */
        @JsonProperty("type")
        public VGPUType type;

        /**
         * The PGPU on which this VGPU is running
         * First published in XenServer 6.2 SP1 Tech-Preview.
         */
        @JsonProperty("resident_on")
        public PGPU residentOn;

        /**
         * The PGPU on which this VGPU is scheduled to run
         * First published in XenServer 7.0.
         */
        @JsonProperty("scheduled_to_be_resident_on")
        public PGPU scheduledToBeResidentOn;

        /**
         * VGPU metadata to determine whether a VGPU can migrate between two PGPUs
         * First published in XenServer 7.3.
         */
        @JsonProperty("compatibility_metadata")
        public Map<String, String> compatibilityMetadata;

        /**
         * Extra arguments for vGPU and passed to demu
         * First published in Citrix Hypervisor 8.1.
         */
        @JsonProperty("extra_args")
        public String extraArgs;

        /**
         * Device passed trough to VM, either as full device or SR-IOV virtual function
         * First published in Citrix Hypervisor 8.1.
         */
        @JsonProperty("PCI")
        public PCI PCI;

    }

    /**
     * Get a record containing the current state of the given VGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VGPU.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VGPU.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the VGPU instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VGPU getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<VGPU>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given VGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VM field of the given VGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VM getVM(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_VM";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the GPU_group field of the given VGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public GPUGroup getGPUGroup(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_GPU_group";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<GPUGroup>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the device field of the given VGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getDevice(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_device";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the currently_attached field of the given VGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getCurrentlyAttached(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_currently_attached";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given VGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the type field of the given VGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VGPUType getType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VGPUType>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the resident_on field of the given VGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PGPU getResidentOn(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_resident_on";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PGPU>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the scheduled_to_be_resident_on field of the given VGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PGPU getScheduledToBeResidentOn(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_scheduled_to_be_resident_on";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PGPU>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the compatibility_metadata field of the given VGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getCompatibilityMetadata(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_compatibility_metadata";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the extra_args field of the given VGPU.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getExtraArgs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_extra_args";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PCI field of the given VGPU.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PCI getPCI(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_PCI";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PCI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the other_config field of the given VGPU.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given VGPU.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given VGPU.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the extra_args field of the given VGPU.
     * Minimum allowed role: pool-operator
     * First published in Citrix Hypervisor 8.1.
     *
     * @param c The connection the call is made on
     * @param extraArgs New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setExtraArgs(Connection c, String extraArgs) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.set_extra_args";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, extraArgs };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param VM No description 
     * @param GPUGroup No description 
     * @param device No description 
     * @param otherConfig No description 
     * @return The reference of the created VGPU object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VGPU create(Connection c, VM VM, GPUGroup GPUGroup, String device, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, VM, GPUGroup, device, otherConfig };
        var typeReference = new TypeReference<VGPU>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param VM No description 
     * @param GPUGroup No description 
     * @param device No description 
     * @param otherConfig No description 
     * @param type No description First published in XenServer 6.2 SP1 Tech-Preview.
     * @return The reference of the created VGPU object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VGPU create(Connection c, VM VM, GPUGroup GPUGroup, String device, Map<String, String> otherConfig, VGPUType type) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, VM, GPUGroup, device, otherConfig, type };
        var typeReference = new TypeReference<VGPU>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param VM No description 
     * @param GPUGroup No description 
     * @param device No description 
     * @param otherConfig No description 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, VM VM, GPUGroup GPUGroup, String device, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VGPU.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, VM, GPUGroup, device, otherConfig };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param VM No description 
     * @param GPUGroup No description 
     * @param device No description 
     * @param otherConfig No description 
     * @param type No description First published in XenServer 6.2 SP1 Tech-Preview.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, VM VM, GPUGroup GPUGroup, String device, Map<String, String> otherConfig, VGPUType type) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VGPU.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, VM, GPUGroup, device, otherConfig, type };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VGPU.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the VGPUs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VGPU> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<VGPU>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of VGPU references to VGPU records for all VGPUs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<VGPU, VGPU.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<VGPU, VGPU.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}