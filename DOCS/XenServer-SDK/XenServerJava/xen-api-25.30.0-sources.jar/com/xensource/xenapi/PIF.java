/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A physical network interface (note separate VLANs are represented as several PIFs)
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class PIF extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    PIF(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a PIF, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof PIF)
        {
            PIF other = (PIF) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a PIF
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "device", this.device);
            print.printf("%1$20s: %2$s\n", "network", this.network);
            print.printf("%1$20s: %2$s\n", "host", this.host);
            print.printf("%1$20s: %2$s\n", "MAC", this.MAC);
            print.printf("%1$20s: %2$s\n", "MTU", this.MTU);
            print.printf("%1$20s: %2$s\n", "VLAN", this.VLAN);
            print.printf("%1$20s: %2$s\n", "metrics", this.metrics);
            print.printf("%1$20s: %2$s\n", "physical", this.physical);
            print.printf("%1$20s: %2$s\n", "currentlyAttached", this.currentlyAttached);
            print.printf("%1$20s: %2$s\n", "ipConfigurationMode", this.ipConfigurationMode);
            print.printf("%1$20s: %2$s\n", "IP", this.IP);
            print.printf("%1$20s: %2$s\n", "netmask", this.netmask);
            print.printf("%1$20s: %2$s\n", "gateway", this.gateway);
            print.printf("%1$20s: %2$s\n", "DNS", this.DNS);
            print.printf("%1$20s: %2$s\n", "bondSlaveOf", this.bondSlaveOf);
            print.printf("%1$20s: %2$s\n", "bondMasterOf", this.bondMasterOf);
            print.printf("%1$20s: %2$s\n", "VLANMasterOf", this.VLANMasterOf);
            print.printf("%1$20s: %2$s\n", "VLANSlaveOf", this.VLANSlaveOf);
            print.printf("%1$20s: %2$s\n", "management", this.management);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "disallowUnplug", this.disallowUnplug);
            print.printf("%1$20s: %2$s\n", "tunnelAccessPIFOf", this.tunnelAccessPIFOf);
            print.printf("%1$20s: %2$s\n", "tunnelTransportPIFOf", this.tunnelTransportPIFOf);
            print.printf("%1$20s: %2$s\n", "ipv6ConfigurationMode", this.ipv6ConfigurationMode);
            print.printf("%1$20s: %2$s\n", "IPv6", this.IPv6);
            print.printf("%1$20s: %2$s\n", "ipv6Gateway", this.ipv6Gateway);
            print.printf("%1$20s: %2$s\n", "primaryAddressType", this.primaryAddressType);
            print.printf("%1$20s: %2$s\n", "managed", this.managed);
            print.printf("%1$20s: %2$s\n", "properties", this.properties);
            print.printf("%1$20s: %2$s\n", "capabilities", this.capabilities);
            print.printf("%1$20s: %2$s\n", "igmpSnoopingStatus", this.igmpSnoopingStatus);
            print.printf("%1$20s: %2$s\n", "sriovPhysicalPIFOf", this.sriovPhysicalPIFOf);
            print.printf("%1$20s: %2$s\n", "sriovLogicalPIFOf", this.sriovLogicalPIFOf);
            print.printf("%1$20s: %2$s\n", "PCI", this.PCI);
            return writer.toString();
        }

        /**
         * Convert a PIF.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("device", this.device == null ? "" : this.device);
            map.put("network", this.network == null ? new Network("OpaqueRef:NULL") : this.network);
            map.put("host", this.host == null ? new Host("OpaqueRef:NULL") : this.host);
            map.put("MAC", this.MAC == null ? "" : this.MAC);
            map.put("MTU", this.MTU == null ? 0 : this.MTU);
            map.put("VLAN", this.VLAN == null ? 0 : this.VLAN);
            map.put("metrics", this.metrics == null ? new PIFMetrics("OpaqueRef:NULL") : this.metrics);
            map.put("physical", this.physical == null ? false : this.physical);
            map.put("currently_attached", this.currentlyAttached == null ? false : this.currentlyAttached);
            map.put("ip_configuration_mode", this.ipConfigurationMode == null ? Types.IpConfigurationMode.UNRECOGNIZED : this.ipConfigurationMode);
            map.put("IP", this.IP == null ? "" : this.IP);
            map.put("netmask", this.netmask == null ? "" : this.netmask);
            map.put("gateway", this.gateway == null ? "" : this.gateway);
            map.put("DNS", this.DNS == null ? "" : this.DNS);
            map.put("bond_slave_of", this.bondSlaveOf == null ? new Bond("OpaqueRef:NULL") : this.bondSlaveOf);
            map.put("bond_master_of", this.bondMasterOf == null ? new LinkedHashSet<Bond>() : this.bondMasterOf);
            map.put("VLAN_master_of", this.VLANMasterOf == null ? new VLAN("OpaqueRef:NULL") : this.VLANMasterOf);
            map.put("VLAN_slave_of", this.VLANSlaveOf == null ? new LinkedHashSet<VLAN>() : this.VLANSlaveOf);
            map.put("management", this.management == null ? false : this.management);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("disallow_unplug", this.disallowUnplug == null ? false : this.disallowUnplug);
            map.put("tunnel_access_PIF_of", this.tunnelAccessPIFOf == null ? new LinkedHashSet<Tunnel>() : this.tunnelAccessPIFOf);
            map.put("tunnel_transport_PIF_of", this.tunnelTransportPIFOf == null ? new LinkedHashSet<Tunnel>() : this.tunnelTransportPIFOf);
            map.put("ipv6_configuration_mode", this.ipv6ConfigurationMode == null ? Types.Ipv6ConfigurationMode.UNRECOGNIZED : this.ipv6ConfigurationMode);
            map.put("IPv6", this.IPv6 == null ? new LinkedHashSet<String>() : this.IPv6);
            map.put("ipv6_gateway", this.ipv6Gateway == null ? "" : this.ipv6Gateway);
            map.put("primary_address_type", this.primaryAddressType == null ? Types.PrimaryAddressType.UNRECOGNIZED : this.primaryAddressType);
            map.put("managed", this.managed == null ? false : this.managed);
            map.put("properties", this.properties == null ? new HashMap<String, String>() : this.properties);
            map.put("capabilities", this.capabilities == null ? new LinkedHashSet<String>() : this.capabilities);
            map.put("igmp_snooping_status", this.igmpSnoopingStatus == null ? Types.PifIgmpStatus.UNRECOGNIZED : this.igmpSnoopingStatus);
            map.put("sriov_physical_PIF_of", this.sriovPhysicalPIFOf == null ? new LinkedHashSet<NetworkSriov>() : this.sriovPhysicalPIFOf);
            map.put("sriov_logical_PIF_of", this.sriovLogicalPIFOf == null ? new LinkedHashSet<NetworkSriov>() : this.sriovLogicalPIFOf);
            map.put("PCI", this.PCI == null ? new PCI("OpaqueRef:NULL") : this.PCI);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * machine-readable name of the interface (e.g. eth0)
         */
        @JsonProperty("device")
        public String device;

        /**
         * virtual network to which this pif is connected
         */
        @JsonProperty("network")
        public Network network;

        /**
         * physical machine to which this pif is connected
         */
        @JsonProperty("host")
        public Host host;

        /**
         * ethernet MAC address of physical interface
         */
        @JsonProperty("MAC")
        public String MAC;

        /**
         * MTU in octets
         */
        @JsonProperty("MTU")
        public Long MTU;

        /**
         * VLAN tag for all traffic passing through this interface
         */
        @JsonProperty("VLAN")
        public Long VLAN;

        /**
         * metrics associated with this PIF
         */
        @JsonProperty("metrics")
        public PIFMetrics metrics;

        /**
         * true if this represents a physical network interface
         * First published in XenServer 4.1.
         */
        @JsonProperty("physical")
        public Boolean physical;

        /**
         * true if this interface is online
         * First published in XenServer 4.1.
         */
        @JsonProperty("currently_attached")
        public Boolean currentlyAttached;

        /**
         * Sets if and how this interface gets an IP address
         * First published in XenServer 4.1.
         */
        @JsonProperty("ip_configuration_mode")
        public Types.IpConfigurationMode ipConfigurationMode;

        /**
         * IP address
         * First published in XenServer 4.1.
         */
        @JsonProperty("IP")
        public String IP;

        /**
         * IP netmask
         * First published in XenServer 4.1.
         */
        @JsonProperty("netmask")
        public String netmask;

        /**
         * IP gateway
         * First published in XenServer 4.1.
         */
        @JsonProperty("gateway")
        public String gateway;

        /**
         * Comma separated list of the IP addresses of the DNS servers to use
         * First published in XenServer 4.1.
         */
        @JsonProperty("DNS")
        public String DNS;

        /**
         * Indicates which bond this interface is part of
         * First published in XenServer 4.1.
         */
        @JsonProperty("bond_slave_of")
        public Bond bondSlaveOf;

        /**
         * Indicates this PIF represents the results of a bond
         * First published in XenServer 4.1.
         */
        @JsonProperty("bond_master_of")
        public Set<Bond> bondMasterOf;

        /**
         * Indicates which VLAN this interface receives untagged traffic from
         * First published in XenServer 4.1.
         */
        @JsonProperty("VLAN_master_of")
        public VLAN VLANMasterOf;

        /**
         * Indicates which VLANs this interface transmits tagged traffic to
         * First published in XenServer 4.1.
         */
        @JsonProperty("VLAN_slave_of")
        public Set<VLAN> VLANSlaveOf;

        /**
         * Indicates whether the control software is listening for connections on this interface
         * First published in XenServer 4.1.
         */
        @JsonProperty("management")
        public Boolean management;

        /**
         * Additional configuration
         * First published in XenServer 4.1.
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * Prevent this PIF from being unplugged; set this to notify the management tool-stack that the PIF has a special use and should not be unplugged under any circumstances (e.g. because you're running storage traffic over it)
         * First published in XenServer 5.0.
         */
        @JsonProperty("disallow_unplug")
        public Boolean disallowUnplug;

        /**
         * Indicates to which tunnel this PIF gives access
         * First published in XenServer 5.6 FP1.
         */
        @JsonProperty("tunnel_access_PIF_of")
        public Set<Tunnel> tunnelAccessPIFOf;

        /**
         * Indicates to which tunnel this PIF provides transport
         * First published in XenServer 5.6 FP1.
         */
        @JsonProperty("tunnel_transport_PIF_of")
        public Set<Tunnel> tunnelTransportPIFOf;

        /**
         * Sets if and how this interface gets an IPv6 address
         * First published in XenServer 6.1.
         */
        @JsonProperty("ipv6_configuration_mode")
        public Types.Ipv6ConfigurationMode ipv6ConfigurationMode;

        /**
         * IPv6 address
         * First published in XenServer 6.1.
         */
        @JsonProperty("IPv6")
        public Set<String> IPv6;

        /**
         * IPv6 gateway
         * First published in XenServer 6.1.
         */
        @JsonProperty("ipv6_gateway")
        public String ipv6Gateway;

        /**
         * Which protocol should define the primary address of this interface
         * First published in XenServer 6.1.
         */
        @JsonProperty("primary_address_type")
        public Types.PrimaryAddressType primaryAddressType;

        /**
         * Indicates whether the interface is managed by xapi. If it is not, then xapi will not configure the interface, the commands PIF.plug/unplug/reconfigure_ip(v6) cannot be used, nor can the interface be bonded or have VLANs based on top through xapi.
         * First published in XenServer 6.2 SP1.
         */
        @JsonProperty("managed")
        public Boolean managed;

        /**
         * Additional configuration properties for the interface.
         * First published in XenServer 6.5.
         */
        @JsonProperty("properties")
        public Map<String, String> properties;

        /**
         * Additional capabilities on the interface.
         * First published in XenServer 7.0.
         */
        @JsonProperty("capabilities")
        public Set<String> capabilities;

        /**
         * The IGMP snooping status of the corresponding network bridge
         * First published in XenServer 7.3.
         */
        @JsonProperty("igmp_snooping_status")
        public Types.PifIgmpStatus igmpSnoopingStatus;

        /**
         * Indicates which network_sriov this interface is physical of
         * First published in XenServer 7.5.
         */
        @JsonProperty("sriov_physical_PIF_of")
        public Set<NetworkSriov> sriovPhysicalPIFOf;

        /**
         * Indicates which network_sriov this interface is logical of
         * First published in XenServer 7.5.
         */
        @JsonProperty("sriov_logical_PIF_of")
        public Set<NetworkSriov> sriovLogicalPIFOf;

        /**
         * Link to underlying PCI device
         * First published in XenServer 7.5.
         */
        @JsonProperty("PCI")
        public PCI PCI;

    }

    /**
     * Get a record containing the current state of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PIF.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PIF.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the PIF instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PIF getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the device field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getDevice(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_device";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the network field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Network getNetwork(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_network";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Network>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getHost(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_host";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the MAC field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getMAC(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_MAC";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the MTU field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getMTU(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_MTU";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VLAN field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getVLAN(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_VLAN";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the metrics field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PIFMetrics getMetrics(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_metrics";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PIFMetrics>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the physical field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getPhysical(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_physical";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the currently_attached field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getCurrentlyAttached(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_currently_attached";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ip_configuration_mode field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.IpConfigurationMode getIpConfigurationMode(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_ip_configuration_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.IpConfigurationMode>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the IP field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getIP(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_IP";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the netmask field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNetmask(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_netmask";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the gateway field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getGateway(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_gateway";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the DNS field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getDNS(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_DNS";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the bond_slave_of field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Bond getBondSlaveOf(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_bond_slave_of";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Bond>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the bond_master_of field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Bond> getBondMasterOf(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_bond_master_of";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Bond>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VLAN_master_of field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VLAN getVLANMasterOf(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_VLAN_master_of";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VLAN>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VLAN_slave_of field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VLAN> getVLANSlaveOf(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_VLAN_slave_of";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VLAN>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the management field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getManagement(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_management";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the disallow_unplug field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getDisallowUnplug(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_disallow_unplug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the tunnel_access_PIF_of field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Tunnel> getTunnelAccessPIFOf(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_tunnel_access_PIF_of";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Tunnel>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the tunnel_transport_PIF_of field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Tunnel> getTunnelTransportPIFOf(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_tunnel_transport_PIF_of";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Tunnel>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ipv6_configuration_mode field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.Ipv6ConfigurationMode getIpv6ConfigurationMode(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_ipv6_configuration_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.Ipv6ConfigurationMode>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the IPv6 field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getIPv6(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_IPv6";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ipv6_gateway field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getIpv6Gateway(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_ipv6_gateway";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the primary_address_type field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.PrimaryAddressType getPrimaryAddressType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_primary_address_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.PrimaryAddressType>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the managed field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getManaged(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_managed";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the properties field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 6.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getProperties(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_properties";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the capabilities field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getCapabilities(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_capabilities";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the igmp_snooping_status field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.PifIgmpStatus getIgmpSnoopingStatus(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_igmp_snooping_status";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.PifIgmpStatus>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the sriov_physical_PIF_of field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<NetworkSriov> getSriovPhysicalPIFOf(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_sriov_physical_PIF_of";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<NetworkSriov>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the sriov_logical_PIF_of field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<NetworkSriov> getSriovLogicalPIFOf(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_sriov_logical_PIF_of";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<NetworkSriov>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PCI field of the given PIF.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PCI getPCI(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_PCI";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PCI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the other_config field of the given PIF.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given PIF.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given PIF.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Create a VLAN interface from an existing physical interface. This call is deprecated: use VLAN.create instead
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     * @deprecated since XenServer 4.1
     *
     * @param c The connection the call is made on
     * @param device physical interface on which to create the VLAN interface 
     * @param network network to which this interface should be connected 
     * @param host physical machine to which this PIF is connected 
     * @param VLAN VLAN tag for the new interface 
     * @return The reference of the created PIF object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VlanTagInvalid You tried to create a VLAN, but the tag you gave was invalid -- it must be between 0 and 4094. The parameter echoes the VLAN tag you gave.
     */
    @Deprecated(since = "XenServer 4.1")
    public static PIF createVLAN(Connection c, String device, Network network, Host host, Long VLAN) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VlanTagInvalid {
        String methodCall = "PIF.create_VLAN";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, device, network, host, VLAN };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a VLAN interface from an existing physical interface. This call is deprecated: use VLAN.create instead
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     * @deprecated since XenServer 4.1
     *
     * @param c The connection the call is made on
     * @param device physical interface on which to create the VLAN interface 
     * @param network network to which this interface should be connected 
     * @param host physical machine to which this PIF is connected 
     * @param VLAN VLAN tag for the new interface 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VlanTagInvalid You tried to create a VLAN, but the tag you gave was invalid -- it must be between 0 and 4094. The parameter echoes the VLAN tag you gave.
     */
    @Deprecated(since = "XenServer 4.1")
    public static Task createVLANAsync(Connection c, String device, Network network, Host host, Long VLAN) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VlanTagInvalid {
        String methodCall = "Async.PIF.create_VLAN";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, device, network, host, VLAN };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy the PIF object (provided it is a VLAN interface). This call is deprecated: use VLAN.destroy or Bond.destroy instead
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     * @deprecated since XenServer 4.1
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.PifIsPhysical You tried to destroy a PIF, but it represents an aspect of the physical host configuration, and so cannot be destroyed. The parameter echoes the PIF handle you gave.
     */
    @Deprecated(since = "XenServer 4.1")
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.PifIsPhysical {
        String methodCall = "PIF.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy the PIF object (provided it is a VLAN interface). This call is deprecated: use VLAN.destroy or Bond.destroy instead
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     * @deprecated since XenServer 4.1
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.PifIsPhysical You tried to destroy a PIF, but it represents an aspect of the physical host configuration, and so cannot be destroyed. The parameter echoes the PIF handle you gave.
     */
    @Deprecated(since = "XenServer 4.1")
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.PifIsPhysical {
        String methodCall = "Async.PIF.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Reconfigure the IP address settings for this interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param mode whether to use dynamic/static/no-assignment 
     * @param IP the new IP address 
     * @param netmask the new netmask 
     * @param gateway the new gateway 
     * @param DNS the new DNS settings 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusteringEnabled An operation was attempted while clustering was enabled on the cluster_host.
     */
    public void reconfigureIp(Connection c, Types.IpConfigurationMode mode, String IP, String netmask, String gateway, String DNS) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusteringEnabled {
        String methodCall = "PIF.reconfigure_ip";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, mode, IP, netmask, gateway, DNS };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Reconfigure the IP address settings for this interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param mode whether to use dynamic/static/no-assignment 
     * @param IP the new IP address 
     * @param netmask the new netmask 
     * @param gateway the new gateway 
     * @param DNS the new DNS settings 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusteringEnabled An operation was attempted while clustering was enabled on the cluster_host.
     */
    public Task reconfigureIpAsync(Connection c, Types.IpConfigurationMode mode, String IP, String netmask, String gateway, String DNS) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusteringEnabled {
        String methodCall = "Async.PIF.reconfigure_ip";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, mode, IP, netmask, gateway, DNS };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Reconfigure the IPv6 address settings for this interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param mode whether to use dynamic/static/no-assignment 
     * @param IPv6 the new IPv6 address (in &lt;addr&gt;/&lt;prefix length&gt; format) 
     * @param gateway the new gateway 
     * @param DNS the new DNS settings 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusteringEnabled An operation was attempted while clustering was enabled on the cluster_host.
     */
    public void reconfigureIpv6(Connection c, Types.Ipv6ConfigurationMode mode, String IPv6, String gateway, String DNS) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusteringEnabled {
        String methodCall = "PIF.reconfigure_ipv6";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, mode, IPv6, gateway, DNS };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Reconfigure the IPv6 address settings for this interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param mode whether to use dynamic/static/no-assignment 
     * @param IPv6 the new IPv6 address (in &lt;addr&gt;/&lt;prefix length&gt; format) 
     * @param gateway the new gateway 
     * @param DNS the new DNS settings 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusteringEnabled An operation was attempted while clustering was enabled on the cluster_host.
     */
    public Task reconfigureIpv6Async(Connection c, Types.Ipv6ConfigurationMode mode, String IPv6, String gateway, String DNS) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusteringEnabled {
        String methodCall = "Async.PIF.reconfigure_ipv6";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, mode, IPv6, gateway, DNS };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Change the primary address type used by this PIF
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param primaryAddressType Whether to prefer IPv4 or IPv6 connections 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setPrimaryAddressType(Connection c, Types.PrimaryAddressType primaryAddressType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.set_primary_address_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, primaryAddressType };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Change the primary address type used by this PIF
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param primaryAddressType Whether to prefer IPv4 or IPv6 connections 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setPrimaryAddressTypeAsync(Connection c, Types.PrimaryAddressType primaryAddressType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PIF.set_primary_address_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, primaryAddressType };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Scan for physical interfaces on a host and create PIF objects to represent them
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param host The host on which to scan 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void scan(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.scan";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Scan for physical interfaces on a host and create PIF objects to represent them
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param host The host on which to scan 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task scanAsync(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PIF.scan";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a PIF object matching a particular network interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param host The host on which the interface exists 
     * @param MAC The MAC address of the interface 
     * @param device The device name to use for the interface 
     * @return The reference of the created PIF object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PIF introduce(Connection c, Host host, String MAC, String device) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, MAC, device };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a PIF object matching a particular network interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param host The host on which the interface exists 
     * @param MAC The MAC address of the interface 
     * @param device The device name to use for the interface 
     * @param managed Indicates whether the interface is managed by xapi (defaults to "true") First published in XenServer 6.2 SP1.
     * @return The reference of the created PIF object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PIF introduce(Connection c, Host host, String MAC, String device, Boolean managed) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, MAC, device, managed };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a PIF object matching a particular network interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param host The host on which the interface exists 
     * @param MAC The MAC address of the interface 
     * @param device The device name to use for the interface 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task introduceAsync(Connection c, Host host, String MAC, String device) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PIF.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, MAC, device };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a PIF object matching a particular network interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param host The host on which the interface exists 
     * @param MAC The MAC address of the interface 
     * @param device The device name to use for the interface 
     * @param managed Indicates whether the interface is managed by xapi (defaults to "true") First published in XenServer 6.2 SP1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task introduceAsync(Connection c, Host host, String MAC, String device, Boolean managed) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PIF.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, MAC, device, managed };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy the PIF object matching a particular network interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.PifTunnelStillExists Operation cannot proceed while a tunnel exists on this interface.
     * @throws Types.ClusteringEnabled An operation was attempted while clustering was enabled on the cluster_host.
     */
    public void forget(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.PifTunnelStillExists,
    Types.ClusteringEnabled {
        String methodCall = "PIF.forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy the PIF object matching a particular network interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.PifTunnelStillExists Operation cannot proceed while a tunnel exists on this interface.
     * @throws Types.ClusteringEnabled An operation was attempted while clustering was enabled on the cluster_host.
     */
    public Task forgetAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.PifTunnelStillExists,
    Types.ClusteringEnabled {
        String methodCall = "Async.PIF.forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Attempt to bring down a physical interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.HaOperationWouldBreakFailoverPlan This operation cannot be performed because it would invalidate VM failover planning such that the system would be unable to guarantee to restart protected VMs after a Host failure.
     * @throws Types.VifInUse Network has active VIFs
     * @throws Types.PifDoesNotAllowUnplug The operation you requested cannot be performed because the specified PIF does not allow unplug.
     * @throws Types.PifHasFcoeSrInUse The operation you requested cannot be performed because the specified PIF has FCoE SR in use.
     */
    public void unplug(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.HaOperationWouldBreakFailoverPlan,
    Types.VifInUse,
    Types.PifDoesNotAllowUnplug,
    Types.PifHasFcoeSrInUse {
        String methodCall = "PIF.unplug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Attempt to bring down a physical interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.HaOperationWouldBreakFailoverPlan This operation cannot be performed because it would invalidate VM failover planning such that the system would be unable to guarantee to restart protected VMs after a Host failure.
     * @throws Types.VifInUse Network has active VIFs
     * @throws Types.PifDoesNotAllowUnplug The operation you requested cannot be performed because the specified PIF does not allow unplug.
     * @throws Types.PifHasFcoeSrInUse The operation you requested cannot be performed because the specified PIF has FCoE SR in use.
     */
    public Task unplugAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.HaOperationWouldBreakFailoverPlan,
    Types.VifInUse,
    Types.PifDoesNotAllowUnplug,
    Types.PifHasFcoeSrInUse {
        String methodCall = "Async.PIF.unplug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set whether unplugging the PIF is allowed
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.ClusteringEnabled An operation was attempted while clustering was enabled on the cluster_host.
     */
    public void setDisallowUnplug(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OtherOperationInProgress,
    Types.ClusteringEnabled {
        String methodCall = "PIF.set_disallow_unplug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set whether unplugging the PIF is allowed
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value New value to set 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.ClusteringEnabled An operation was attempted while clustering was enabled on the cluster_host.
     */
    public Task setDisallowUnplugAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OtherOperationInProgress,
    Types.ClusteringEnabled {
        String methodCall = "Async.PIF.set_disallow_unplug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Attempt to bring up a physical interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.TransportPifNotConfigured The tunnel transport PIF has no IP configuration set.
     */
    public void plug(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.TransportPifNotConfigured {
        String methodCall = "PIF.plug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Attempt to bring up a physical interface
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.TransportPifNotConfigured The tunnel transport PIF has no IP configuration set.
     */
    public Task plugAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.TransportPifNotConfigured {
        String methodCall = "Async.PIF.plug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new PIF record in the database only
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param device No description 
     * @param network No description 
     * @param host No description 
     * @param MAC No description 
     * @param MTU No description 
     * @param VLAN No description 
     * @param physical No description 
     * @param ipConfigurationMode No description 
     * @param IP No description 
     * @param netmask No description 
     * @param gateway No description 
     * @param DNS No description 
     * @param bondSlaveOf No description 
     * @param VLANMasterOf No description 
     * @param management No description 
     * @param otherConfig No description 
     * @param disallowUnplug No description 
     * @return The ref of the newly created PIF record.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PIF dbIntroduce(Connection c, String device, Network network, Host host, String MAC, Long MTU, Long VLAN, Boolean physical, Types.IpConfigurationMode ipConfigurationMode, String IP, String netmask, String gateway, String DNS, Bond bondSlaveOf, VLAN VLANMasterOf, Boolean management, Map<String, String> otherConfig, Boolean disallowUnplug) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.db_introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, device, network, host, MAC, MTU, VLAN, physical, ipConfigurationMode, IP, netmask, gateway, DNS, bondSlaveOf, VLANMasterOf, management, otherConfig, disallowUnplug };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new PIF record in the database only
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param device No description 
     * @param network No description 
     * @param host No description 
     * @param MAC No description 
     * @param MTU No description 
     * @param VLAN No description 
     * @param physical No description 
     * @param ipConfigurationMode No description 
     * @param IP No description 
     * @param netmask No description 
     * @param gateway No description 
     * @param DNS No description 
     * @param bondSlaveOf No description 
     * @param VLANMasterOf No description 
     * @param management No description 
     * @param otherConfig No description 
     * @param disallowUnplug No description 
     * @param ipv6ConfigurationMode No description First published in XenServer 6.0.
     * @param IPv6 No description First published in XenServer 6.0.
     * @param ipv6Gateway No description First published in XenServer 6.0.
     * @param primaryAddressType No description First published in XenServer 6.0.
     * @return The ref of the newly created PIF record.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PIF dbIntroduce(Connection c, String device, Network network, Host host, String MAC, Long MTU, Long VLAN, Boolean physical, Types.IpConfigurationMode ipConfigurationMode, String IP, String netmask, String gateway, String DNS, Bond bondSlaveOf, VLAN VLANMasterOf, Boolean management, Map<String, String> otherConfig, Boolean disallowUnplug, Types.Ipv6ConfigurationMode ipv6ConfigurationMode, Set<String> IPv6, String ipv6Gateway, Types.PrimaryAddressType primaryAddressType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.db_introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, device, network, host, MAC, MTU, VLAN, physical, ipConfigurationMode, IP, netmask, gateway, DNS, bondSlaveOf, VLANMasterOf, management, otherConfig, disallowUnplug, ipv6ConfigurationMode, IPv6, ipv6Gateway, primaryAddressType };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new PIF record in the database only
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param device No description 
     * @param network No description 
     * @param host No description 
     * @param MAC No description 
     * @param MTU No description 
     * @param VLAN No description 
     * @param physical No description 
     * @param ipConfigurationMode No description 
     * @param IP No description 
     * @param netmask No description 
     * @param gateway No description 
     * @param DNS No description 
     * @param bondSlaveOf No description 
     * @param VLANMasterOf No description 
     * @param management No description 
     * @param otherConfig No description 
     * @param disallowUnplug No description 
     * @param ipv6ConfigurationMode No description First published in XenServer 6.0.
     * @param IPv6 No description First published in XenServer 6.0.
     * @param ipv6Gateway No description First published in XenServer 6.0.
     * @param primaryAddressType No description First published in XenServer 6.0.
     * @param managed No description First published in XenServer 6.2 SP1.
     * @return The ref of the newly created PIF record.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PIF dbIntroduce(Connection c, String device, Network network, Host host, String MAC, Long MTU, Long VLAN, Boolean physical, Types.IpConfigurationMode ipConfigurationMode, String IP, String netmask, String gateway, String DNS, Bond bondSlaveOf, VLAN VLANMasterOf, Boolean management, Map<String, String> otherConfig, Boolean disallowUnplug, Types.Ipv6ConfigurationMode ipv6ConfigurationMode, Set<String> IPv6, String ipv6Gateway, Types.PrimaryAddressType primaryAddressType, Boolean managed) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.db_introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, device, network, host, MAC, MTU, VLAN, physical, ipConfigurationMode, IP, netmask, gateway, DNS, bondSlaveOf, VLANMasterOf, management, otherConfig, disallowUnplug, ipv6ConfigurationMode, IPv6, ipv6Gateway, primaryAddressType, managed };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new PIF record in the database only
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param device No description 
     * @param network No description 
     * @param host No description 
     * @param MAC No description 
     * @param MTU No description 
     * @param VLAN No description 
     * @param physical No description 
     * @param ipConfigurationMode No description 
     * @param IP No description 
     * @param netmask No description 
     * @param gateway No description 
     * @param DNS No description 
     * @param bondSlaveOf No description 
     * @param VLANMasterOf No description 
     * @param management No description 
     * @param otherConfig No description 
     * @param disallowUnplug No description 
     * @param ipv6ConfigurationMode No description First published in XenServer 6.0.
     * @param IPv6 No description First published in XenServer 6.0.
     * @param ipv6Gateway No description First published in XenServer 6.0.
     * @param primaryAddressType No description First published in XenServer 6.0.
     * @param managed No description First published in XenServer 6.2 SP1.
     * @param properties No description First published in XenServer 6.5.
     * @return The ref of the newly created PIF record.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PIF dbIntroduce(Connection c, String device, Network network, Host host, String MAC, Long MTU, Long VLAN, Boolean physical, Types.IpConfigurationMode ipConfigurationMode, String IP, String netmask, String gateway, String DNS, Bond bondSlaveOf, VLAN VLANMasterOf, Boolean management, Map<String, String> otherConfig, Boolean disallowUnplug, Types.Ipv6ConfigurationMode ipv6ConfigurationMode, Set<String> IPv6, String ipv6Gateway, Types.PrimaryAddressType primaryAddressType, Boolean managed, Map<String, String> properties) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.db_introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, device, network, host, MAC, MTU, VLAN, physical, ipConfigurationMode, IP, netmask, gateway, DNS, bondSlaveOf, VLANMasterOf, management, otherConfig, disallowUnplug, ipv6ConfigurationMode, IPv6, ipv6Gateway, primaryAddressType, managed, properties };
        var typeReference = new TypeReference<PIF>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new PIF record in the database only
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param device No description 
     * @param network No description 
     * @param host No description 
     * @param MAC No description 
     * @param MTU No description 
     * @param VLAN No description 
     * @param physical No description 
     * @param ipConfigurationMode No description 
     * @param IP No description 
     * @param netmask No description 
     * @param gateway No description 
     * @param DNS No description 
     * @param bondSlaveOf No description 
     * @param VLANMasterOf No description 
     * @param management No description 
     * @param otherConfig No description 
     * @param disallowUnplug No description 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task dbIntroduceAsync(Connection c, String device, Network network, Host host, String MAC, Long MTU, Long VLAN, Boolean physical, Types.IpConfigurationMode ipConfigurationMode, String IP, String netmask, String gateway, String DNS, Bond bondSlaveOf, VLAN VLANMasterOf, Boolean management, Map<String, String> otherConfig, Boolean disallowUnplug) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PIF.db_introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, device, network, host, MAC, MTU, VLAN, physical, ipConfigurationMode, IP, netmask, gateway, DNS, bondSlaveOf, VLANMasterOf, management, otherConfig, disallowUnplug };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new PIF record in the database only
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param device No description 
     * @param network No description 
     * @param host No description 
     * @param MAC No description 
     * @param MTU No description 
     * @param VLAN No description 
     * @param physical No description 
     * @param ipConfigurationMode No description 
     * @param IP No description 
     * @param netmask No description 
     * @param gateway No description 
     * @param DNS No description 
     * @param bondSlaveOf No description 
     * @param VLANMasterOf No description 
     * @param management No description 
     * @param otherConfig No description 
     * @param disallowUnplug No description 
     * @param ipv6ConfigurationMode No description First published in XenServer 6.0.
     * @param IPv6 No description First published in XenServer 6.0.
     * @param ipv6Gateway No description First published in XenServer 6.0.
     * @param primaryAddressType No description First published in XenServer 6.0.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task dbIntroduceAsync(Connection c, String device, Network network, Host host, String MAC, Long MTU, Long VLAN, Boolean physical, Types.IpConfigurationMode ipConfigurationMode, String IP, String netmask, String gateway, String DNS, Bond bondSlaveOf, VLAN VLANMasterOf, Boolean management, Map<String, String> otherConfig, Boolean disallowUnplug, Types.Ipv6ConfigurationMode ipv6ConfigurationMode, Set<String> IPv6, String ipv6Gateway, Types.PrimaryAddressType primaryAddressType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PIF.db_introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, device, network, host, MAC, MTU, VLAN, physical, ipConfigurationMode, IP, netmask, gateway, DNS, bondSlaveOf, VLANMasterOf, management, otherConfig, disallowUnplug, ipv6ConfigurationMode, IPv6, ipv6Gateway, primaryAddressType };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new PIF record in the database only
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param device No description 
     * @param network No description 
     * @param host No description 
     * @param MAC No description 
     * @param MTU No description 
     * @param VLAN No description 
     * @param physical No description 
     * @param ipConfigurationMode No description 
     * @param IP No description 
     * @param netmask No description 
     * @param gateway No description 
     * @param DNS No description 
     * @param bondSlaveOf No description 
     * @param VLANMasterOf No description 
     * @param management No description 
     * @param otherConfig No description 
     * @param disallowUnplug No description 
     * @param ipv6ConfigurationMode No description First published in XenServer 6.0.
     * @param IPv6 No description First published in XenServer 6.0.
     * @param ipv6Gateway No description First published in XenServer 6.0.
     * @param primaryAddressType No description First published in XenServer 6.0.
     * @param managed No description First published in XenServer 6.2 SP1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task dbIntroduceAsync(Connection c, String device, Network network, Host host, String MAC, Long MTU, Long VLAN, Boolean physical, Types.IpConfigurationMode ipConfigurationMode, String IP, String netmask, String gateway, String DNS, Bond bondSlaveOf, VLAN VLANMasterOf, Boolean management, Map<String, String> otherConfig, Boolean disallowUnplug, Types.Ipv6ConfigurationMode ipv6ConfigurationMode, Set<String> IPv6, String ipv6Gateway, Types.PrimaryAddressType primaryAddressType, Boolean managed) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PIF.db_introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, device, network, host, MAC, MTU, VLAN, physical, ipConfigurationMode, IP, netmask, gateway, DNS, bondSlaveOf, VLANMasterOf, management, otherConfig, disallowUnplug, ipv6ConfigurationMode, IPv6, ipv6Gateway, primaryAddressType, managed };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new PIF record in the database only
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param device No description 
     * @param network No description 
     * @param host No description 
     * @param MAC No description 
     * @param MTU No description 
     * @param VLAN No description 
     * @param physical No description 
     * @param ipConfigurationMode No description 
     * @param IP No description 
     * @param netmask No description 
     * @param gateway No description 
     * @param DNS No description 
     * @param bondSlaveOf No description 
     * @param VLANMasterOf No description 
     * @param management No description 
     * @param otherConfig No description 
     * @param disallowUnplug No description 
     * @param ipv6ConfigurationMode No description First published in XenServer 6.0.
     * @param IPv6 No description First published in XenServer 6.0.
     * @param ipv6Gateway No description First published in XenServer 6.0.
     * @param primaryAddressType No description First published in XenServer 6.0.
     * @param managed No description First published in XenServer 6.2 SP1.
     * @param properties No description First published in XenServer 6.5.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task dbIntroduceAsync(Connection c, String device, Network network, Host host, String MAC, Long MTU, Long VLAN, Boolean physical, Types.IpConfigurationMode ipConfigurationMode, String IP, String netmask, String gateway, String DNS, Bond bondSlaveOf, VLAN VLANMasterOf, Boolean management, Map<String, String> otherConfig, Boolean disallowUnplug, Types.Ipv6ConfigurationMode ipv6ConfigurationMode, Set<String> IPv6, String ipv6Gateway, Types.PrimaryAddressType primaryAddressType, Boolean managed, Map<String, String> properties) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PIF.db_introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, device, network, host, MAC, MTU, VLAN, physical, ipConfigurationMode, IP, netmask, gateway, DNS, bondSlaveOf, VLANMasterOf, management, otherConfig, disallowUnplug, ipv6ConfigurationMode, IPv6, ipv6Gateway, primaryAddressType, managed, properties };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy a PIF database record.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void dbForget(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.db_forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy a PIF database record.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task dbForgetAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PIF.db_forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the value of a property of the PIF
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5.
     *
     * @param c The connection the call is made on
     * @param name The property name 
     * @param value The property value 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setProperty(Connection c, String name, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.set_property";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the value of a property of the PIF
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5.
     *
     * @param c The connection the call is made on
     * @param name The property name 
     * @param value The property value 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setPropertyAsync(Connection c, String name, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PIF.set_property";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the PIFs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<PIF> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<PIF>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of PIF references to PIF records for all PIFs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<PIF, PIF.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PIF.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<PIF, PIF.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}