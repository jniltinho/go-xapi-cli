/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * Cluster-wide Cluster metadata
 * First published in XenServer 7.6.
 *
 * @author Cloud Software Group, Inc.
 */
public class Cluster extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    Cluster(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a Cluster, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Cluster)
        {
            Cluster other = (Cluster) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a Cluster
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "clusterHosts", this.clusterHosts);
            print.printf("%1$20s: %2$s\n", "pendingForget", this.pendingForget);
            print.printf("%1$20s: %2$s\n", "clusterToken", this.clusterToken);
            print.printf("%1$20s: %2$s\n", "clusterStack", this.clusterStack);
            print.printf("%1$20s: %2$s\n", "clusterStackVersion", this.clusterStackVersion);
            print.printf("%1$20s: %2$s\n", "isQuorate", this.isQuorate);
            print.printf("%1$20s: %2$s\n", "quorum", this.quorum);
            print.printf("%1$20s: %2$s\n", "liveHosts", this.liveHosts);
            print.printf("%1$20s: %2$s\n", "expectedHosts", this.expectedHosts);
            print.printf("%1$20s: %2$s\n", "allowedOperations", this.allowedOperations);
            print.printf("%1$20s: %2$s\n", "currentOperations", this.currentOperations);
            print.printf("%1$20s: %2$s\n", "poolAutoJoin", this.poolAutoJoin);
            print.printf("%1$20s: %2$s\n", "tokenTimeout", this.tokenTimeout);
            print.printf("%1$20s: %2$s\n", "tokenTimeoutCoefficient", this.tokenTimeoutCoefficient);
            print.printf("%1$20s: %2$s\n", "clusterConfig", this.clusterConfig);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            return writer.toString();
        }

        /**
         * Convert a Cluster.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("cluster_hosts", this.clusterHosts == null ? new LinkedHashSet<ClusterHost>() : this.clusterHosts);
            map.put("pending_forget", this.pendingForget == null ? new LinkedHashSet<String>() : this.pendingForget);
            map.put("cluster_token", this.clusterToken == null ? "" : this.clusterToken);
            map.put("cluster_stack", this.clusterStack == null ? "" : this.clusterStack);
            map.put("cluster_stack_version", this.clusterStackVersion == null ? 0 : this.clusterStackVersion);
            map.put("is_quorate", this.isQuorate == null ? false : this.isQuorate);
            map.put("quorum", this.quorum == null ? 0 : this.quorum);
            map.put("live_hosts", this.liveHosts == null ? 0 : this.liveHosts);
            map.put("expected_hosts", this.expectedHosts == null ? 0 : this.expectedHosts);
            map.put("allowed_operations", this.allowedOperations == null ? new LinkedHashSet<Types.ClusterOperation>() : this.allowedOperations);
            map.put("current_operations", this.currentOperations == null ? new HashMap<String, Types.ClusterOperation>() : this.currentOperations);
            map.put("pool_auto_join", this.poolAutoJoin == null ? false : this.poolAutoJoin);
            map.put("token_timeout", this.tokenTimeout == null ? 0.0 : this.tokenTimeout);
            map.put("token_timeout_coefficient", this.tokenTimeoutCoefficient == null ? 0.0 : this.tokenTimeoutCoefficient);
            map.put("cluster_config", this.clusterConfig == null ? new HashMap<String, String>() : this.clusterConfig);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * A list of the cluster_host objects associated with the Cluster
         */
        @JsonProperty("cluster_hosts")
        public Set<ClusterHost> clusterHosts;

        /**
         * Internal field used by Host.destroy to store the IP of cluster members marked as permanently dead but not yet removed
         */
        @JsonProperty("pending_forget")
        public Set<String> pendingForget;

        /**
         * The secret key used by xapi-clusterd when it talks to itself on other hosts
         */
        @JsonProperty("cluster_token")
        public String clusterToken;

        /**
         * Simply the string 'corosync'. No other cluster stacks are currently supported
         */
        @JsonProperty("cluster_stack")
        public String clusterStack;

        /**
         * Version of cluster stack, not writable via the API. Defaulting to 2 for backwards compatibility when upgrading from a cluster without this field, which means it is necessarily running version 2 of corosync, the only cluster stack supported so far.
         * Experimental. First published in 24.15.0.
         */
        @JsonProperty("cluster_stack_version")
        public Long clusterStackVersion;

        /**
         * Whether the cluster stack thinks the cluster is quorate
         * Experimental. First published in 24.3.0.
         */
        @JsonProperty("is_quorate")
        public Boolean isQuorate;

        /**
         * Number of live hosts in order to be quorate
         * Experimental. First published in 24.3.0.
         */
        @JsonProperty("quorum")
        public Long quorum;

        /**
         * Current number of live hosts, according to the cluster stack
         * Experimental. First published in 24.3.0.
         */
        @JsonProperty("live_hosts")
        public Long liveHosts;

        /**
         * Total number of hosts expected by the cluster stack
         * Experimental. First published in 25.17.0.
         */
        @JsonProperty("expected_hosts")
        public Long expectedHosts;

        /**
         * list of the operations allowed in this state. This list is advisory only and the server state may have changed by the time this field is read by a client.
         */
        @JsonProperty("allowed_operations")
        public Set<Types.ClusterOperation> allowedOperations;

        /**
         * links each of the running tasks using this object (by reference) to a current_operation enum which describes the nature of the task.
         */
        @JsonProperty("current_operations")
        public Map<String, Types.ClusterOperation> currentOperations;

        /**
         * True if automatically joining new pool members to the cluster. This will be `true` in the first release
         */
        @JsonProperty("pool_auto_join")
        public Boolean poolAutoJoin;

        /**
         * The corosync token timeout in seconds
         */
        @JsonProperty("token_timeout")
        public Double tokenTimeout;

        /**
         * The corosync token timeout coefficient in seconds
         */
        @JsonProperty("token_timeout_coefficient")
        public Double tokenTimeoutCoefficient;

        /**
         * Contains read-only settings for the cluster, such as timeouts and other options. It can only be set at cluster create time
         */
        @JsonProperty("cluster_config")
        public Map<String, String> clusterConfig;

        /**
         * Additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

    }

    /**
     * Get a record containing the current state of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Cluster.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Cluster.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the Cluster instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Cluster getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<Cluster>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the cluster_hosts field of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<ClusterHost> getClusterHosts(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_cluster_hosts";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<ClusterHost>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the pending_forget field of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getPendingForget(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_pending_forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the cluster_token field of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getClusterToken(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_cluster_token";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the cluster_stack field of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getClusterStack(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_cluster_stack";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the cluster_stack_version field of the given Cluster.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.15.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getClusterStackVersion(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_cluster_stack_version";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_quorate field of the given Cluster.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.3.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsQuorate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_is_quorate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the quorum field of the given Cluster.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.3.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getQuorum(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_quorum";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the live_hosts field of the given Cluster.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.3.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getLiveHosts(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_live_hosts";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the expected_hosts field of the given Cluster.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.17.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getExpectedHosts(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_expected_hosts";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allowed_operations field of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.ClusterOperation> getAllowedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.ClusterOperation>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the current_operations field of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Types.ClusterOperation> getCurrentOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_current_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Types.ClusterOperation>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the pool_auto_join field of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getPoolAutoJoin(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_pool_auto_join";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the token_timeout field of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Double getTokenTimeout(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_token_timeout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Double>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the token_timeout_coefficient field of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Double getTokenTimeoutCoefficient(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_token_timeout_coefficient";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Double>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the cluster_config field of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getClusterConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_cluster_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given Cluster.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the other_config field of the given Cluster.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given Cluster.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given Cluster.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Creates a Cluster object and one Cluster_host object as its first member
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param PIF The PIF to connect the cluster's first cluster_host to 
     * @param clusterStack simply the string 'corosync'. No other cluster stacks are currently supported 
     * @param poolAutoJoin true if xapi is automatically joining new pool members to the cluster 
     * @param tokenTimeout Corosync token timeout in seconds 
     * @param tokenTimeoutCoefficient Corosync token timeout coefficient in seconds 
     * @return the new Cluster
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.InvalidClusterStack The cluster stack provided is not supported.
     * @throws Types.InvalidValue The value given is invalid
     * @throws Types.PifAllowsUnplug The operation you requested cannot be performed because the specified PIF allows unplug.
     * @throws Types.RequiredPifIsUnplugged The operation you requested cannot be performed because the specified PIF is currently unplugged.
     */
    public static Cluster create(Connection c, PIF PIF, String clusterStack, Boolean poolAutoJoin, Double tokenTimeout, Double tokenTimeoutCoefficient) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.InvalidClusterStack,
    Types.InvalidValue,
    Types.PifAllowsUnplug,
    Types.RequiredPifIsUnplugged {
        String methodCall = "Cluster.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, PIF, clusterStack, poolAutoJoin, tokenTimeout, tokenTimeoutCoefficient };
        var typeReference = new TypeReference<Cluster>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Creates a Cluster object and one Cluster_host object as its first member
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param PIF The PIF to connect the cluster's first cluster_host to 
     * @param clusterStack simply the string 'corosync'. No other cluster stacks are currently supported 
     * @param poolAutoJoin true if xapi is automatically joining new pool members to the cluster 
     * @param tokenTimeout Corosync token timeout in seconds 
     * @param tokenTimeoutCoefficient Corosync token timeout coefficient in seconds 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.InvalidClusterStack The cluster stack provided is not supported.
     * @throws Types.InvalidValue The value given is invalid
     * @throws Types.PifAllowsUnplug The operation you requested cannot be performed because the specified PIF allows unplug.
     * @throws Types.RequiredPifIsUnplugged The operation you requested cannot be performed because the specified PIF is currently unplugged.
     */
    public static Task createAsync(Connection c, PIF PIF, String clusterStack, Boolean poolAutoJoin, Double tokenTimeout, Double tokenTimeoutCoefficient) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.InvalidClusterStack,
    Types.InvalidValue,
    Types.PifAllowsUnplug,
    Types.RequiredPifIsUnplugged {
        String methodCall = "Async.Cluster.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, PIF, clusterStack, poolAutoJoin, tokenTimeout, tokenTimeoutCoefficient };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroys a Cluster object and the one remaining Cluster_host member
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusterDoesNotHaveOneNode An operation failed as it expected the cluster to have only one node but found multiple cluster_hosts.
     * @throws Types.ClusterStackInUse The cluster stack is still in use by at least one plugged PBD.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusterDoesNotHaveOneNode,
    Types.ClusterStackInUse {
        String methodCall = "Cluster.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroys a Cluster object and the one remaining Cluster_host member
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusterDoesNotHaveOneNode An operation failed as it expected the cluster to have only one node but found multiple cluster_hosts.
     * @throws Types.ClusterStackInUse The cluster stack is still in use by at least one plugged PBD.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusterDoesNotHaveOneNode,
    Types.ClusterStackInUse {
        String methodCall = "Async.Cluster.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns the network used by the cluster for inter-host communication, i.e. the network shared by all cluster host PIFs
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return network of cluster
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Network getNetwork(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_network";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Network>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns the network used by the cluster for inter-host communication, i.e. the network shared by all cluster host PIFs
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getNetworkAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Cluster.get_network";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Attempt to create a Cluster from the entire pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param network the single network on which corosync carries out its inter-host communications 
     * @param clusterStack simply the string 'corosync'. No other cluster stacks are currently supported 
     * @param tokenTimeout Corosync token timeout in seconds 
     * @param tokenTimeoutCoefficient Corosync token timeout coefficient in seconds 
     * @return the new Cluster
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Cluster poolCreate(Connection c, Network network, String clusterStack, Double tokenTimeout, Double tokenTimeoutCoefficient) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.pool_create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, network, clusterStack, tokenTimeout, tokenTimeoutCoefficient };
        var typeReference = new TypeReference<Cluster>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Attempt to create a Cluster from the entire pool
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param network the single network on which corosync carries out its inter-host communications 
     * @param clusterStack simply the string 'corosync'. No other cluster stacks are currently supported 
     * @param tokenTimeout Corosync token timeout in seconds 
     * @param tokenTimeoutCoefficient Corosync token timeout coefficient in seconds 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task poolCreateAsync(Connection c, Network network, String clusterStack, Double tokenTimeout, Double tokenTimeoutCoefficient) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Cluster.pool_create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, network, clusterStack, tokenTimeout, tokenTimeoutCoefficient };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Attempt to force destroy the Cluster_host objects, and then destroy the Cluster.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusterForceDestroyFailed Force destroy failed on a Cluster_host while force destroying the cluster.
     */
    public void poolForceDestroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusterForceDestroyFailed {
        String methodCall = "Cluster.pool_force_destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Attempt to force destroy the Cluster_host objects, and then destroy the Cluster.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusterForceDestroyFailed Force destroy failed on a Cluster_host while force destroying the cluster.
     */
    public Task poolForceDestroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusterForceDestroyFailed {
        String methodCall = "Async.Cluster.pool_force_destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Attempt to destroy the Cluster_host objects for all hosts in the pool and then destroy the Cluster.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusterStackInUse The cluster stack is still in use by at least one plugged PBD.
     * @throws Types.ClusteringDisabled An operation was attempted while clustering was disabled on the cluster_host.
     * @throws Types.ClusterHostIsLast The last cluster host cannot be destroyed. Destroy the cluster instead
     */
    public void poolDestroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusterStackInUse,
    Types.ClusteringDisabled,
    Types.ClusterHostIsLast {
        String methodCall = "Cluster.pool_destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Attempt to destroy the Cluster_host objects for all hosts in the pool and then destroy the Cluster.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.ClusterStackInUse The cluster stack is still in use by at least one plugged PBD.
     * @throws Types.ClusteringDisabled An operation was attempted while clustering was disabled on the cluster_host.
     * @throws Types.ClusterHostIsLast The last cluster host cannot be destroyed. Destroy the cluster instead
     */
    public Task poolDestroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.ClusterStackInUse,
    Types.ClusteringDisabled,
    Types.ClusterHostIsLast {
        String methodCall = "Async.Cluster.pool_destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Resynchronise the cluster_host objects across the pool. Creates them where they need creating and then plugs them
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void poolResync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.pool_resync";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Resynchronise the cluster_host objects across the pool. Creates them where they need creating and then plugs them
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task poolResyncAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Cluster.pool_resync";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the Clusters known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Cluster> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<Cluster>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of Cluster references to Cluster records for all Clusters known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<Cluster, Cluster.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Cluster.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<Cluster, Cluster.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}