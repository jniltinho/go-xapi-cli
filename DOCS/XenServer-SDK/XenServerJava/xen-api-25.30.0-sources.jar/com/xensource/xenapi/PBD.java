/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * The physical block devices through which hosts access SRs
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class PBD extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    PBD(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a PBD, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof PBD)
        {
            PBD other = (PBD) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a PBD
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "host", this.host);
            print.printf("%1$20s: %2$s\n", "SR", this.SR);
            print.printf("%1$20s: %2$s\n", "deviceConfig", this.deviceConfig);
            print.printf("%1$20s: %2$s\n", "currentlyAttached", this.currentlyAttached);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            return writer.toString();
        }

        /**
         * Convert a PBD.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("host", this.host == null ? new Host("OpaqueRef:NULL") : this.host);
            map.put("SR", this.SR == null ? new SR("OpaqueRef:NULL") : this.SR);
            map.put("device_config", this.deviceConfig == null ? new HashMap<String, String>() : this.deviceConfig);
            map.put("currently_attached", this.currentlyAttached == null ? false : this.currentlyAttached);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * physical machine on which the pbd is available
         */
        @JsonProperty("host")
        public Host host;

        /**
         * the storage repository that the pbd realises
         */
        @JsonProperty("SR")
        public SR SR;

        /**
         * a config string to string map that is provided to the host's SR-backend-driver
         */
        @JsonProperty("device_config")
        public Map<String, String> deviceConfig;

        /**
         * is the SR currently attached on this host?
         */
        @JsonProperty("currently_attached")
        public Boolean currentlyAttached;

        /**
         * additional configuration
         * First published in XenServer 4.1.
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

    }

    /**
     * Get a record containing the current state of the given PBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PBD.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PBD.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the PBD instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PBD getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<PBD>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new PBD instance, and return its handle.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return reference to the newly created object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PBD create(Connection c, PBD.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<PBD>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new PBD instance, and return its handle.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, PBD.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PBD.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy the specified PBD instance.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy the specified PBD instance.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PBD.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given PBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host field of the given PBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getHost(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.get_host";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the SR field of the given PBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public SR getSR(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.get_SR";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the device_config field of the given PBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getDeviceConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.get_device_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the currently_attached field of the given PBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getCurrentlyAttached(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.get_currently_attached";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given PBD.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the other_config field of the given PBD.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given PBD.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given PBD.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Activate the specified PBD, causing the referenced SR to be attached and scanned
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrUnknownDriver The SR could not be connected because the driver was not recognised.
     */
    public void plug(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrUnknownDriver {
        String methodCall = "PBD.plug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Activate the specified PBD, causing the referenced SR to be attached and scanned
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrUnknownDriver The SR could not be connected because the driver was not recognised.
     */
    public Task plugAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrUnknownDriver {
        String methodCall = "Async.PBD.plug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Deactivate the specified PBD, causing the referenced SR to be detached and nolonger scanned
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void unplug(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.unplug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Deactivate the specified PBD, causing the referenced SR to be detached and nolonger scanned
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task unplugAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PBD.unplug";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sets the PBD's device_config field
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param value The new value of the PBD's device_config 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setDeviceConfig(Connection c, Map<String, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.set_device_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets the PBD's device_config field
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param value The new value of the PBD's device_config 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setDeviceConfigAsync(Connection c, Map<String, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PBD.set_device_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the PBDs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<PBD> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<PBD>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of PBD references to PBD records for all PBDs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<PBD, PBD.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PBD.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<PBD, PBD.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}