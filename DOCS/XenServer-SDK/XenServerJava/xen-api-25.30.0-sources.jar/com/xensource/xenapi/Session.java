/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A session
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class Session extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    Session(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a Session, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Session)
        {
            Session other = (Session) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a Session
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "thisHost", this.thisHost);
            print.printf("%1$20s: %2$s\n", "thisUser", this.thisUser);
            print.printf("%1$20s: %2$s\n", "lastActive", this.lastActive);
            print.printf("%1$20s: %2$s\n", "pool", this.pool);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "isLocalSuperuser", this.isLocalSuperuser);
            print.printf("%1$20s: %2$s\n", "subject", this.subject);
            print.printf("%1$20s: %2$s\n", "validationTime", this.validationTime);
            print.printf("%1$20s: %2$s\n", "authUserSid", this.authUserSid);
            print.printf("%1$20s: %2$s\n", "authUserName", this.authUserName);
            print.printf("%1$20s: %2$s\n", "rbacPermissions", this.rbacPermissions);
            print.printf("%1$20s: %2$s\n", "tasks", this.tasks);
            print.printf("%1$20s: %2$s\n", "parent", this.parent);
            print.printf("%1$20s: %2$s\n", "originator", this.originator);
            print.printf("%1$20s: %2$s\n", "clientCertificate", this.clientCertificate);
            return writer.toString();
        }

        /**
         * Convert a Session.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("this_host", this.thisHost == null ? new Host("OpaqueRef:NULL") : this.thisHost);
            map.put("this_user", this.thisUser == null ? new User("OpaqueRef:NULL") : this.thisUser);
            map.put("last_active", this.lastActive == null ? new Date(0) : this.lastActive);
            map.put("pool", this.pool == null ? false : this.pool);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("is_local_superuser", this.isLocalSuperuser == null ? false : this.isLocalSuperuser);
            map.put("subject", this.subject == null ? new Subject("OpaqueRef:NULL") : this.subject);
            map.put("validation_time", this.validationTime == null ? new Date(0) : this.validationTime);
            map.put("auth_user_sid", this.authUserSid == null ? "" : this.authUserSid);
            map.put("auth_user_name", this.authUserName == null ? "" : this.authUserName);
            map.put("rbac_permissions", this.rbacPermissions == null ? new LinkedHashSet<String>() : this.rbacPermissions);
            map.put("tasks", this.tasks == null ? new LinkedHashSet<Task>() : this.tasks);
            map.put("parent", this.parent == null ? new Session("OpaqueRef:NULL") : this.parent);
            map.put("originator", this.originator == null ? "" : this.originator);
            map.put("client_certificate", this.clientCertificate == null ? false : this.clientCertificate);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * Currently connected host
         */
        @JsonProperty("this_host")
        public Host thisHost;

        /**
         * Currently connected user
         */
        @JsonProperty("this_user")
        public User thisUser;

        /**
         * Timestamp for last time session was active
         */
        @JsonProperty("last_active")
        public Date lastActive;

        /**
         * True if this session relates to a intra-pool login, false otherwise
         */
        @JsonProperty("pool")
        public Boolean pool;

        /**
         * additional configuration
         * First published in XenServer 4.1.
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * true iff this session was created using local superuser credentials
         * First published in XenServer 5.5.
         */
        @JsonProperty("is_local_superuser")
        public Boolean isLocalSuperuser;

        /**
         * references the subject instance that created the session. If a session instance has is_local_superuser set, then the value of this field is undefined.
         * First published in XenServer 5.5.
         */
        @JsonProperty("subject")
        public Subject subject;

        /**
         * time when session was last validated
         * First published in XenServer 5.5.
         */
        @JsonProperty("validation_time")
        public Date validationTime;

        /**
         * the subject identifier of the user that was externally authenticated. If a session instance has is_local_superuser set, then the value of this field is undefined.
         * First published in XenServer 5.5.
         */
        @JsonProperty("auth_user_sid")
        public String authUserSid;

        /**
         * the subject name of the user that was externally authenticated. If a session instance has is_local_superuser set, then the value of this field is undefined.
         * First published in XenServer 5.6.
         */
        @JsonProperty("auth_user_name")
        public String authUserName;

        /**
         * list with all RBAC permissions for this session
         * First published in XenServer 5.6.
         */
        @JsonProperty("rbac_permissions")
        public Set<String> rbacPermissions;

        /**
         * list of tasks created using the current session
         * First published in XenServer 5.6.
         */
        @JsonProperty("tasks")
        public Set<Task> tasks;

        /**
         * references the parent session that created this session
         * First published in XenServer 5.6.
         */
        @JsonProperty("parent")
        public Session parent;

        /**
         * a key string provided by a API user to distinguish itself from other users sharing the same login name
         * First published in XenServer 6.2.
         */
        @JsonProperty("originator")
        public String originator;

        /**
         * indicates whether this session was authenticated using a client certificate
         * First published in 21.2.0.
         */
        @JsonProperty("client_certificate")
        public Boolean clientCertificate;

    }

    /**
     * Get a record containing the current state of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Session.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Session.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the session instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Session getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<Session>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the this_host field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getThisHost(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_this_host";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the this_user field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public User getThisUser(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_this_user";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<User>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the last_active field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getLastActive(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_last_active";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the pool field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getPool(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_pool";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_local_superuser field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsLocalSuperuser(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_is_local_superuser";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the subject field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Subject getSubject(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_subject";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Subject>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the validation_time field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getValidationTime(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_validation_time";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the auth_user_sid field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getAuthUserSid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_auth_user_sid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the auth_user_name field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getAuthUserName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_auth_user_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the rbac_permissions field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getRbacPermissions(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_rbac_permissions";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the tasks field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Task> getTasks(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_tasks";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Task>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the parent field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Session getParent(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_parent";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Session>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the originator field of the given session.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getOriginator(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_originator";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the client_certificate field of the given session.
     * Minimum allowed role: read-only
     * First published in 21.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getClientCertificate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_client_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the other_config field of the given session.
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given session.
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given session.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Attempt to authenticate the user, returning a session reference if successful
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uname Username for login. 
     * @param pwd Password for login. 
     * @return reference of newly created session
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SessionAuthenticationFailed The credentials given by the user are incorrect, so access has been denied, and you have not been issued a session handle.
     * @throws Types.HostIsSlave You cannot make regular API calls directly on a supporter. Please pass API calls via the coordinator host.
     */
    public static Session loginWithPassword(Connection c, String uname, String pwd) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SessionAuthenticationFailed,
    Types.HostIsSlave {
        String methodCall = "session.login_with_password";
        Object[] methodParameters = { uname, pwd };
        var typeReference = new TypeReference<Session>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Attempt to authenticate the user, returning a session reference if successful
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uname Username for login. 
     * @param pwd Password for login. 
     * @param version Client API version. First published in XenServer 4.1.
     * @return reference of newly created session
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SessionAuthenticationFailed The credentials given by the user are incorrect, so access has been denied, and you have not been issued a session handle.
     * @throws Types.HostIsSlave You cannot make regular API calls directly on a supporter. Please pass API calls via the coordinator host.
     */
    public static Session loginWithPassword(Connection c, String uname, String pwd, String version) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SessionAuthenticationFailed,
    Types.HostIsSlave {
        String methodCall = "session.login_with_password";
        Object[] methodParameters = { uname, pwd, version };
        var typeReference = new TypeReference<Session>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Attempt to authenticate the user, returning a session reference if successful
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uname Username for login. 
     * @param pwd Password for login. 
     * @param version Client API version. First published in XenServer 4.1.
     * @param originator Key string for distinguishing different API users sharing the same login name. First published in XenServer 6.2.
     * @return reference of newly created session
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SessionAuthenticationFailed The credentials given by the user are incorrect, so access has been denied, and you have not been issued a session handle.
     * @throws Types.HostIsSlave You cannot make regular API calls directly on a supporter. Please pass API calls via the coordinator host.
     */
    public static Session loginWithPassword(Connection c, String uname, String pwd, String version, String originator) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SessionAuthenticationFailed,
    Types.HostIsSlave {
        String methodCall = "session.login_with_password";
        Object[] methodParameters = { uname, pwd, version, originator };
        var typeReference = new TypeReference<Session>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Log out of a session
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void logout(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.logout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Change the account password; if your session is authenticated with root privileges then the old_pwd is validated and the new_pwd is set regardless
     * Minimum allowed role: Not Applicable
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param oldPwd Old password for account 
     * @param newPwd New password for account 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void changePassword(Connection c, String oldPwd, String newPwd) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.change_password";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, oldPwd, newPwd };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Authenticate locally against a slave in emergency mode. Note the resulting sessions are only good for use on this host.
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param uname Username for login. 
     * @param pwd Password for login. 
     * @return ID of newly created session
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Session slaveLocalLoginWithPassword(Connection c, String uname, String pwd) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.slave_local_login_with_password";
        Object[] methodParameters = { uname, pwd };
        var typeReference = new TypeReference<Session>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: Not Applicable
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param filename Database dump filename. 
     * @return ID of newly created session
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Session createFromDbFile(Connection c, String filename) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.create_from_db_file";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, filename };
        var typeReference = new TypeReference<Session>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: Not Applicable
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param filename Database dump filename. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createFromDbFileAsync(Connection c, String filename) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.session.create_from_db_file";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, filename };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Log out of local session.
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void localLogout(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.local_logout";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Return a list of all the user subject-identifiers of all existing sessions
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return The list of user subject-identifiers of all existing sessions
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<String> getAllSubjectIdentifiers(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.get_all_subject_identifiers";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the user subject-identifiers of all existing sessions
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task getAllSubjectIdentifiersAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.session.get_all_subject_identifiers";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Log out all sessions associated to a user subject-identifier, except the session associated with the context calling this function
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param subjectIdentifier User subject-identifier of the sessions to be destroyed 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void logoutSubjectIdentifier(Connection c, String subjectIdentifier) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "session.logout_subject_identifier";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, subjectIdentifier };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Log out all sessions associated to a user subject-identifier, except the session associated with the context calling this function
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @param subjectIdentifier User subject-identifier of the sessions to be destroyed 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task logoutSubjectIdentifierAsync(Connection c, String subjectIdentifier) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.session.logout_subject_identifier";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, subjectIdentifier };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}