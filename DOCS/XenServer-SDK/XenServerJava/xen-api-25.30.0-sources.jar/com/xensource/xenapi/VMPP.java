/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * VM Protection Policy
 * First published in XenServer 5.6 FP1.
 *
 * @author Cloud Software Group, Inc.
 */
public class VMPP extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    VMPP(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a VMPP, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof VMPP)
        {
            VMPP other = (VMPP) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a VMPP
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "isPolicyEnabled", this.isPolicyEnabled);
            print.printf("%1$20s: %2$s\n", "backupType", this.backupType);
            print.printf("%1$20s: %2$s\n", "backupRetentionValue", this.backupRetentionValue);
            print.printf("%1$20s: %2$s\n", "backupFrequency", this.backupFrequency);
            print.printf("%1$20s: %2$s\n", "backupSchedule", this.backupSchedule);
            print.printf("%1$20s: %2$s\n", "isBackupRunning", this.isBackupRunning);
            print.printf("%1$20s: %2$s\n", "backupLastRunTime", this.backupLastRunTime);
            print.printf("%1$20s: %2$s\n", "archiveTargetType", this.archiveTargetType);
            print.printf("%1$20s: %2$s\n", "archiveTargetConfig", this.archiveTargetConfig);
            print.printf("%1$20s: %2$s\n", "archiveFrequency", this.archiveFrequency);
            print.printf("%1$20s: %2$s\n", "archiveSchedule", this.archiveSchedule);
            print.printf("%1$20s: %2$s\n", "isArchiveRunning", this.isArchiveRunning);
            print.printf("%1$20s: %2$s\n", "archiveLastRunTime", this.archiveLastRunTime);
            print.printf("%1$20s: %2$s\n", "VMs", this.VMs);
            print.printf("%1$20s: %2$s\n", "isAlarmEnabled", this.isAlarmEnabled);
            print.printf("%1$20s: %2$s\n", "alarmConfig", this.alarmConfig);
            print.printf("%1$20s: %2$s\n", "recentAlerts", this.recentAlerts);
            return writer.toString();
        }

        /**
         * Convert a VMPP.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("is_policy_enabled", this.isPolicyEnabled == null ? false : this.isPolicyEnabled);
            map.put("backup_type", this.backupType == null ? Types.VmppBackupType.UNRECOGNIZED : this.backupType);
            map.put("backup_retention_value", this.backupRetentionValue == null ? 0 : this.backupRetentionValue);
            map.put("backup_frequency", this.backupFrequency == null ? Types.VmppBackupFrequency.UNRECOGNIZED : this.backupFrequency);
            map.put("backup_schedule", this.backupSchedule == null ? new HashMap<String, String>() : this.backupSchedule);
            map.put("is_backup_running", this.isBackupRunning == null ? false : this.isBackupRunning);
            map.put("backup_last_run_time", this.backupLastRunTime == null ? new Date(0) : this.backupLastRunTime);
            map.put("archive_target_type", this.archiveTargetType == null ? Types.VmppArchiveTargetType.UNRECOGNIZED : this.archiveTargetType);
            map.put("archive_target_config", this.archiveTargetConfig == null ? new HashMap<String, String>() : this.archiveTargetConfig);
            map.put("archive_frequency", this.archiveFrequency == null ? Types.VmppArchiveFrequency.UNRECOGNIZED : this.archiveFrequency);
            map.put("archive_schedule", this.archiveSchedule == null ? new HashMap<String, String>() : this.archiveSchedule);
            map.put("is_archive_running", this.isArchiveRunning == null ? false : this.isArchiveRunning);
            map.put("archive_last_run_time", this.archiveLastRunTime == null ? new Date(0) : this.archiveLastRunTime);
            map.put("VMs", this.VMs == null ? new LinkedHashSet<VM>() : this.VMs);
            map.put("is_alarm_enabled", this.isAlarmEnabled == null ? false : this.isAlarmEnabled);
            map.put("alarm_config", this.alarmConfig == null ? new HashMap<String, String>() : this.alarmConfig);
            map.put("recent_alerts", this.recentAlerts == null ? new LinkedHashSet<String>() : this.recentAlerts);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * enable or disable this policy
         */
        @JsonProperty("is_policy_enabled")
        public Boolean isPolicyEnabled;

        /**
         * type of the backup sub-policy
         */
        @JsonProperty("backup_type")
        public Types.VmppBackupType backupType;

        /**
         * maximum number of backups that should be stored at any time
         */
        @JsonProperty("backup_retention_value")
        public Long backupRetentionValue;

        /**
         * frequency of the backup schedule
         */
        @JsonProperty("backup_frequency")
        public Types.VmppBackupFrequency backupFrequency;

        /**
         * schedule of the backup containing 'hour', 'min', 'days'. Date/time-related information is in Local Timezone
         */
        @JsonProperty("backup_schedule")
        public Map<String, String> backupSchedule;

        /**
         * true if this protection policy's backup is running
         */
        @JsonProperty("is_backup_running")
        public Boolean isBackupRunning;

        /**
         * time of the last backup
         */
        @JsonProperty("backup_last_run_time")
        public Date backupLastRunTime;

        /**
         * type of the archive target config
         */
        @JsonProperty("archive_target_type")
        public Types.VmppArchiveTargetType archiveTargetType;

        /**
         * configuration for the archive, including its 'location', 'username', 'password'
         */
        @JsonProperty("archive_target_config")
        public Map<String, String> archiveTargetConfig;

        /**
         * frequency of the archive schedule
         */
        @JsonProperty("archive_frequency")
        public Types.VmppArchiveFrequency archiveFrequency;

        /**
         * schedule of the archive containing 'hour', 'min', 'days'. Date/time-related information is in Local Timezone
         */
        @JsonProperty("archive_schedule")
        public Map<String, String> archiveSchedule;

        /**
         * true if this protection policy's archive is running
         */
        @JsonProperty("is_archive_running")
        public Boolean isArchiveRunning;

        /**
         * time of the last archive
         */
        @JsonProperty("archive_last_run_time")
        public Date archiveLastRunTime;

        /**
         * all VMs attached to this protection policy
         */
        @JsonProperty("VMs")
        public Set<VM> VMs;

        /**
         * true if alarm is enabled for this policy
         */
        @JsonProperty("is_alarm_enabled")
        public Boolean isAlarmEnabled;

        /**
         * configuration for the alarm
         */
        @JsonProperty("alarm_config")
        public Map<String, String> alarmConfig;

        /**
         * recent alerts
         */
        @JsonProperty("recent_alerts")
        public Set<String> recentAlerts;

    }

    /**
     * Get a record containing the current state of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public VMPP.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VMPP.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the VMPP instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public static VMPP getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<VMPP>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VMPP instance, and return its handle.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return reference to the newly created object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public static VMPP create(Connection c, VMPP.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<VMPP>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VMPP instance, and return its handle.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public static Task createAsync(Connection c, VMPP.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VMPP.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy the specified VMPP instance.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy the specified VMPP instance.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VMPP.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the VMPP instances with the given label.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public static Set<VMPP> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<VMPP>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_policy_enabled field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Boolean getIsPolicyEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_is_policy_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the backup_type field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Types.VmppBackupType getBackupType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_backup_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.VmppBackupType>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the backup_retention_value field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Long getBackupRetentionValue(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_backup_retention_value";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the backup_frequency field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Types.VmppBackupFrequency getBackupFrequency(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_backup_frequency";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.VmppBackupFrequency>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the backup_schedule field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Map<String, String> getBackupSchedule(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_backup_schedule";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_backup_running field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Boolean getIsBackupRunning(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_is_backup_running";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the backup_last_run_time field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Date getBackupLastRunTime(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_backup_last_run_time";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the archive_target_type field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Types.VmppArchiveTargetType getArchiveTargetType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_archive_target_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.VmppArchiveTargetType>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the archive_target_config field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Map<String, String> getArchiveTargetConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_archive_target_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the archive_frequency field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Types.VmppArchiveFrequency getArchiveFrequency(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_archive_frequency";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.VmppArchiveFrequency>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the archive_schedule field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Map<String, String> getArchiveSchedule(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_archive_schedule";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_archive_running field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Boolean getIsArchiveRunning(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_is_archive_running";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the archive_last_run_time field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Date getArchiveLastRunTime(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_archive_last_run_time";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VMs field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Set<VM> getVMs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_VMs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VM>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_alarm_enabled field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Boolean getIsAlarmEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_is_alarm_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the alarm_config field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Map<String, String> getAlarmConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_alarm_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the recent_alerts field of the given VMPP.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Set<String> getRecentAlerts(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_recent_alerts";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name/label field of the given VMPP.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param label New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, label };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name/description field of the given VMPP.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param description New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setNameDescription(Connection c, String description) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, description };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the is_policy_enabled field of the given VMPP.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param isPolicyEnabled New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setIsPolicyEnabled(Connection c, Boolean isPolicyEnabled) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_is_policy_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, isPolicyEnabled };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the backup_type field of the given VMPP.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param backupType New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setBackupType(Connection c, Types.VmppBackupType backupType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_backup_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, backupType };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * This call executes the protection policy immediately
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return An XMLRPC result
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public String protectNow(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.protect_now";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call archives the snapshot provided as a parameter
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param snapshot The snapshot to archive 
     * @return An XMLRPC result
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public static String archiveNow(Connection c, VM snapshot) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.archive_now";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, snapshot };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * This call fetches a history of alerts for a given protection policy
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param hoursFromNow how many hours in the past the oldest record to fetch is 
     * @return A list of alerts encoded in xml
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Set<String> getAlerts(Connection c, Long hoursFromNow) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_alerts";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, hoursFromNow };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param value the value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setBackupRetentionValue(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_backup_retention_value";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the value of the backup_frequency field
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param value the backup frequency 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setBackupFrequency(Connection c, Types.VmppBackupFrequency value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_backup_frequency";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param value the value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setBackupSchedule(Connection c, Map<String, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_backup_schedule";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the value of the archive_frequency field
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param value the archive frequency 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setArchiveFrequency(Connection c, Types.VmppArchiveFrequency value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_archive_frequency";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param value the value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setArchiveSchedule(Connection c, Map<String, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_archive_schedule";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the value of the archive_target_config_type field
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param value the archive target config type 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setArchiveTargetType(Connection c, Types.VmppArchiveTargetType value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_archive_target_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param value the value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setArchiveTargetConfig(Connection c, Map<String, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_archive_target_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the value of the is_alarm_enabled field
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param value true if alarm is enabled for this policy 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setIsAlarmEnabled(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_is_alarm_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param value the value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setAlarmConfig(Connection c, Map<String, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_alarm_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param key the key to add 
     * @param value the value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void addToBackupSchedule(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.add_to_backup_schedule";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param key the key to add 
     * @param value the value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void addToArchiveTargetConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.add_to_archive_target_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param key the key to add 
     * @param value the value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void addToArchiveSchedule(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.add_to_archive_schedule";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param key the key to add 
     * @param value the value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void addToAlarmConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.add_to_alarm_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param key the key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void removeFromBackupSchedule(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.remove_from_backup_schedule";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param key the key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void removeFromArchiveTargetConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.remove_from_archive_target_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param key the key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void removeFromArchiveSchedule(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.remove_from_archive_schedule";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param key the key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void removeFromAlarmConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.remove_from_alarm_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: Not Applicable
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param value The time at which the last backup was done. When the timezone is missing, UTC is assumed 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setBackupLastRunTime(Connection c, Date value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_backup_last_run_time";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: Not Applicable
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param value The time at which the last archive was created. When the timezone is missing, UTC is assumed 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setArchiveLastRunTime(Connection c, Date value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.set_archive_last_run_time";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Return a list of all the VMPPs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public static Set<VMPP> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<VMPP>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of VMPP references to VMPP records for all VMPPs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<VMPP, VMPP.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VMPP.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<VMPP, VMPP.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}