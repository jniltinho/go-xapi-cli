/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * Asynchronous event registration and handling
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class Event extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    Event(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a Event, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Event)
        {
            Event other = (Event) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a Event
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "id", this.id);
            print.printf("%1$20s: %2$s\n", "timestamp", this.timestamp);
            print.printf("%1$20s: %2$s\n", "clazz", this.clazz);
            print.printf("%1$20s: %2$s\n", "operation", this.operation);
            print.printf("%1$20s: %2$s\n", "ref", this.ref);
            print.printf("%1$20s: %2$s\n", "objUuid", this.objUuid);
            print.printf("%1$20s: %2$s\n", "snapshot", this.snapshot);
            return writer.toString();
        }

        /**
         * Convert a Event.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("id", this.id == null ? 0 : this.id);
            map.put("timestamp", this.timestamp == null ? new Date(0) : this.timestamp);
            map.put("class", this.clazz == null ? "" : this.clazz);
            map.put("operation", this.operation == null ? Types.EventOperation.UNRECOGNIZED : this.operation);
            map.put("ref", this.ref == null ? "" : this.ref);
            map.put("obj_uuid", this.objUuid == null ? "" : this.objUuid);
            return map;
        }

        /**
         * An ID, monotonically increasing, and local to the current session
         */
        @JsonProperty("id")
        public Long id;

        /**
         * The time at which the event occurred
         */
        @JsonProperty("timestamp")
        @Deprecated(since = "XenServer 4.0")
        public Date timestamp;

        /**
         * The name of the class of the object that changed
         */
        @JsonProperty("class")
        public String clazz;

        /**
         * The operation that was performed
         */
        @JsonProperty("operation")
        public Types.EventOperation operation;

        /**
         * A reference to the object that changed
         */
        @JsonProperty("ref")
        public String ref;

        /**
         * The uuid of the object that changed
         */
        @JsonProperty("obj_uuid")
        @Deprecated(since = "XenServer 4.0")
        public String objUuid;

            /**
            * The record of the database object that was added, changed or deleted.
            * The actual type will be VM.Record, VBD.Record, or similar.
            */
            public Object snapshot;
    }

    /**
     * Registers this session with the event system for a set of given classes. This method is only recommended for legacy use in conjunction with event.next.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 6.0
     *
     * @param c The connection the call is made on
     * @param classes the classes for which the session will register with the event system; specifying * as the desired class will register for all classes 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.0")
    public static void register(Connection c, Set<String> classes) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "event.register";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, classes };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Registers this session with the event system for a set of given classes. This method is only recommended for legacy use in conjunction with event.next.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 6.0
     *
     * @param c The connection the call is made on
     * @param classes the classes for which the session will register with the event system; specifying * as the desired class will register for all classes 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.0")
    public static Task registerAsync(Connection c, Set<String> classes) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.event.register";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, classes };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Removes this session's registration with the event system for a set of given classes. This method is only recommended for legacy use in conjunction with event.next.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 6.0
     *
     * @param c The connection the call is made on
     * @param classes the classes for which the session's registration with the event system will be removed 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.0")
    public static void unregister(Connection c, Set<String> classes) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "event.unregister";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, classes };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Removes this session's registration with the event system for a set of given classes. This method is only recommended for legacy use in conjunction with event.next.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 6.0
     *
     * @param c The connection the call is made on
     * @param classes the classes for which the session's registration with the event system will be removed 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.0")
    public static Task unregisterAsync(Connection c, Set<String> classes) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.event.unregister";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, classes };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Blocking call which returns a (possibly empty) batch of events. This method is only recommended for legacy use.It stores events in a buffer of limited size, raising EVENTS_LOST if too many events got generated. New development should use event.from which supersedes this method.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 6.0
     *
     * @param c The connection the call is made on
     * @return A set of events
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SessionNotRegistered This session is not registered to receive events. You must call event.register before event.next. The session handle you are using is echoed.
     * @throws Types.EventsLost Some events have been lost from the queue and cannot be retrieved.
     * @throws Types.EventSubscriptionParseFailure The server failed to parse your event subscription. Valid values include: *, class-name, class-name/object-reference.
     */
    @Deprecated(since = "XenServer 6.0")
    public static Set<Event.Record> next(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SessionNotRegistered,
    Types.EventsLost,
    Types.EventSubscriptionParseFailure {
        String methodCall = "event.next";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<Event.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Blocking call which returns a new token and a (possibly empty) batch of events. The returned token can be used in subsequent calls to this function. It eliminates redundant events (e.g. same field updated multiple times).
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param classes register for events for the indicated classes 
     * @param token A token representing the point from which to generate database events. The empty string represents the beginning. 
     * @param timeout Return after this many seconds if no events match 
     * @return a structure consisting of a token ('token'), a map of valid references per object type ('valid_ref_counts'), and a set of event records ('events').
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.EventFromTokenParseFailure The event.from token could not be parsed. Valid values include: '', and a value returned from a previous event.from call.
     * @throws Types.EventSubscriptionParseFailure The server failed to parse your event subscription. Valid values include: *, class-name, class-name/object-reference.
     */
    public static EventBatch from(Connection c, Set<String> classes, String token, Double timeout) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.EventFromTokenParseFailure,
    Types.EventSubscriptionParseFailure {
        String methodCall = "event.from";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, classes, token, timeout };
        var typeReference = new TypeReference<EventBatch>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return the ID of the next event to be generated by the system
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return the event ID
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Long getCurrentId(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "event.get_current_id";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Injects an artificial event on the given object and returns the corresponding ID in the form of a token, which can be used as a point of reference for database events. For example, to check whether an object has reached the right state before attempting an operation, one can inject an artificial event on the object and wait until the token returned by consecutive event.from calls is lexicographically greater than the one returned by event.inject.
     * Minimum allowed role: read-only
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param clazz class of the object 
     * @param ref A reference to the object that will be changed. 
     * @return the event ID in the form of a token
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static String inject(Connection c, String clazz, String ref) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "event.inject";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, clazz, ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}