/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * UNSUPPORTED. A multi-version driver on a host
 * First published in .
 *
 * @author Cloud Software Group, Inc.
 */
public class HostDriver extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    HostDriver(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a HostDriver, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof HostDriver)
        {
            HostDriver other = (HostDriver) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a HostDriver
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "host", this.host);
            print.printf("%1$20s: %2$s\n", "name", this.name);
            print.printf("%1$20s: %2$s\n", "friendlyName", this.friendlyName);
            print.printf("%1$20s: %2$s\n", "variants", this.variants);
            print.printf("%1$20s: %2$s\n", "activeVariant", this.activeVariant);
            print.printf("%1$20s: %2$s\n", "selectedVariant", this.selectedVariant);
            print.printf("%1$20s: %2$s\n", "type", this.type);
            print.printf("%1$20s: %2$s\n", "description", this.description);
            print.printf("%1$20s: %2$s\n", "info", this.info);
            return writer.toString();
        }

        /**
         * Convert a HostDriver.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("host", this.host == null ? new Host("OpaqueRef:NULL") : this.host);
            map.put("name", this.name == null ? "" : this.name);
            map.put("friendly_name", this.friendlyName == null ? "" : this.friendlyName);
            map.put("variants", this.variants == null ? new LinkedHashSet<DriverVariant>() : this.variants);
            map.put("active_variant", this.activeVariant == null ? new DriverVariant("OpaqueRef:NULL") : this.activeVariant);
            map.put("selected_variant", this.selectedVariant == null ? new DriverVariant("OpaqueRef:NULL") : this.selectedVariant);
            map.put("type", this.type == null ? "" : this.type);
            map.put("description", this.description == null ? "" : this.description);
            map.put("info", this.info == null ? "" : this.info);
            return map;
        }

        /**
         * Unique identifier/object reference
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * Host where this driver is installed
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("host")
        public Host host;

        /**
         * Name identifying the driver uniquely
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("name")
        public String name;

        /**
         * Descriptive name, not used for identification
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("friendly_name")
        public String friendlyName;

        /**
         * Variants of this driver available for selection
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("variants")
        public Set<DriverVariant> variants;

        /**
         * Currently active variant of this driver, if any, or Null.
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("active_variant")
        public DriverVariant activeVariant;

        /**
         * Variant (if any) selected to become active after reboot. Or Null
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("selected_variant")
        public DriverVariant selectedVariant;

        /**
         * Device type this driver supports, like network or storage
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("type")
        public String type;

        /**
         * Description of the driver
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("description")
        public String description;

        /**
         * Information about the driver
         * Experimental. First published in 25.2.0.
         */
        @JsonProperty("info")
        public String info;

    }

    /**
     * Get a record containing the current state of the given Host_driver.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public HostDriver.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<HostDriver.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the Host_driver instance with the specified UUID.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static HostDriver getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<HostDriver>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given Host_driver.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host field of the given Host_driver.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getHost(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_host";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name field of the given Host_driver.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the friendly_name field of the given Host_driver.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getFriendlyName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_friendly_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the variants field of the given Host_driver.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<DriverVariant> getVariants(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_variants";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<DriverVariant>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the active_variant field of the given Host_driver.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public DriverVariant getActiveVariant(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_active_variant";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<DriverVariant>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the selected_variant field of the given Host_driver.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public DriverVariant getSelectedVariant(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_selected_variant";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<DriverVariant>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the type field of the given Host_driver.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the description field of the given Host_driver.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the info field of the given Host_driver.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getInfo(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_info";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * UNSUPPORTED. Select a variant of the driver to become active after reboot or immediately if currently no version is active
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @param variant Driver version to become active (after reboot). 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void select(Connection c, DriverVariant variant) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.select";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, variant };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * UNSUPPORTED. Select a variant of the driver to become active after reboot or immediately if currently no version is active
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @param variant Driver version to become active (after reboot). 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task selectAsync(Connection c, DriverVariant variant) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Host_driver.select";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, variant };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * UNSUPPORTED. Deselect the currently active variant of this driver after reboot. No action will be taken if no variant is currently active.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void deselect(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.deselect";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * UNSUPPORTED. Deselect the currently active variant of this driver after reboot. No action will be taken if no variant is currently active.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task deselectAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Host_driver.deselect";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * UNSUPPORTED. Re-scan a host's drivers and update information about them. This is mostly  for trouble shooting.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @param host Update driver information of this host. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void rescan(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.rescan";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * UNSUPPORTED. Re-scan a host's drivers and update information about them. This is mostly  for trouble shooting.
     * Minimum allowed role: pool-admin
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @param host Update driver information of this host. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task rescanAsync(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Host_driver.rescan";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the Host_drivers known to the system.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<HostDriver> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<HostDriver>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of Host_driver references to Host_driver records for all Host_drivers known to the system.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.2.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<HostDriver, HostDriver.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Host_driver.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<HostDriver, HostDriver.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}