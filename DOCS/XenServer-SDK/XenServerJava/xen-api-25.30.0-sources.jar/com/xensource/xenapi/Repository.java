/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * Repository for updates
 * First published in 1.301.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class Repository extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    Repository(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a Repository, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Repository)
        {
            Repository other = (Repository) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a Repository
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "binaryUrl", this.binaryUrl);
            print.printf("%1$20s: %2$s\n", "sourceUrl", this.sourceUrl);
            print.printf("%1$20s: %2$s\n", "update", this.update);
            print.printf("%1$20s: %2$s\n", "hash", this.hash);
            print.printf("%1$20s: %2$s\n", "upToDate", this.upToDate);
            print.printf("%1$20s: %2$s\n", "gpgkeyPath", this.gpgkeyPath);
            print.printf("%1$20s: %2$s\n", "origin", this.origin);
            print.printf("%1$20s: %2$s\n", "certificate", this.certificate);
            return writer.toString();
        }

        /**
         * Convert a Repository.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("binary_url", this.binaryUrl == null ? "" : this.binaryUrl);
            map.put("source_url", this.sourceUrl == null ? "" : this.sourceUrl);
            map.put("update", this.update == null ? false : this.update);
            map.put("hash", this.hash == null ? "" : this.hash);
            map.put("up_to_date", this.upToDate == null ? false : this.upToDate);
            map.put("gpgkey_path", this.gpgkeyPath == null ? "" : this.gpgkeyPath);
            map.put("origin", this.origin == null ? Types.Origin.UNRECOGNIZED : this.origin);
            map.put("certificate", this.certificate == null ? "" : this.certificate);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * Base URL of binary packages in this repository
         */
        @JsonProperty("binary_url")
        public String binaryUrl;

        /**
         * Base URL of source packages in this repository
         */
        @JsonProperty("source_url")
        public String sourceUrl;

        /**
         * True if updateinfo.xml in this repository needs to be parsed
         */
        @JsonProperty("update")
        public Boolean update;

        /**
         * SHA256 checksum of latest updateinfo.xml.gz in this repository if its 'update' is true
         */
        @JsonProperty("hash")
        public String hash;

        /**
         * True if all hosts in pool is up to date with this repository
         */
        @JsonProperty("up_to_date")
        public Boolean upToDate;

        /**
         * The file name of the GPG public key of this repository
         * Experimental. First published in 22.12.0.
         */
        @JsonProperty("gpgkey_path")
        public String gpgkeyPath;

        /**
         * The origin of this repository. 'remote' if the origin of the repository is a remote one, 'bundle' if the origin of the repository is a local bundle file, 'remote_pool' if the origin of the repository is a remote pool
         * Experimental. First published in 24.23.0.
         */
        @JsonProperty("origin")
        public Types.Origin origin;

        /**
         * The certificate of the host which hosts this repository
         * Experimental. First published in 25.7.0.
         */
        @JsonProperty("certificate")
        public String certificate;

    }

    /**
     * Get a record containing the current state of the given Repository.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Repository.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Repository.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the Repository instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Repository getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<Repository>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the Repository instances with the given label.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Repository> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<Repository>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given Repository.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given Repository.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given Repository.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the binary_url field of the given Repository.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getBinaryUrl(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_binary_url";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the source_url field of the given Repository.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getSourceUrl(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_source_url";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the update field of the given Repository.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getUpdate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_update";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the hash field of the given Repository.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getHash(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_hash";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the up_to_date field of the given Repository.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     * @deprecated since 23.18.0
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "23.18.0")
    public Boolean getUpToDate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_up_to_date";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the gpgkey_path field of the given Repository.
     * Minimum allowed role: read-only
     * Experimental. First published in 22.12.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getGpgkeyPath(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_gpgkey_path";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the origin field of the given Repository.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.23.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.Origin getOrigin(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_origin";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.Origin>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the certificate field of the given Repository.
     * Minimum allowed role: read-only
     * Experimental. First published in 25.7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getCertificate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_certificate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name/label field of the given Repository.
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param label New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, label };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name/description field of the given Repository.
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param description New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameDescription(Connection c, String description) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, description };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the configuration for a new remote repository
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param nameLabel The name of the repository 
     * @param nameDescription The description of the repository 
     * @param binaryUrl Base URL of binary packages in this repository 
     * @param sourceUrl Base URL of source packages in this repository 
     * @param update True if the repository is an update repository. This means that updateinfo.xml will be parsed 
     * @param gpgkeyPath The GPG public key file name 
     * @return The ref of the created repository record.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Repository introduce(Connection c, String nameLabel, String nameDescription, String binaryUrl, String sourceUrl, Boolean update, String gpgkeyPath) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, nameLabel, nameDescription, binaryUrl, sourceUrl, update, gpgkeyPath };
        var typeReference = new TypeReference<Repository>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Add the configuration for a new remote repository
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @param nameLabel The name of the repository 
     * @param nameDescription The description of the repository 
     * @param binaryUrl Base URL of binary packages in this repository 
     * @param sourceUrl Base URL of source packages in this repository 
     * @param update True if the repository is an update repository. This means that updateinfo.xml will be parsed 
     * @param gpgkeyPath The GPG public key file name 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task introduceAsync(Connection c, String nameLabel, String nameDescription, String binaryUrl, String sourceUrl, Boolean update, String gpgkeyPath) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Repository.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, nameLabel, nameDescription, binaryUrl, sourceUrl, update, gpgkeyPath };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Add the configuration for a new bundle repository
     * Minimum allowed role: pool-operator
     * Experimental. First published in 24.23.0.
     *
     * @param c The connection the call is made on
     * @param nameLabel The name of the repository 
     * @param nameDescription The description of the repository 
     * @return The ref of the created repository record.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Repository introduceBundle(Connection c, String nameLabel, String nameDescription) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.introduce_bundle";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, nameLabel, nameDescription };
        var typeReference = new TypeReference<Repository>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Add the configuration for a new bundle repository
     * Minimum allowed role: pool-operator
     * Experimental. First published in 24.23.0.
     *
     * @param c The connection the call is made on
     * @param nameLabel The name of the repository 
     * @param nameDescription The description of the repository 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task introduceBundleAsync(Connection c, String nameLabel, String nameDescription) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Repository.introduce_bundle";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, nameLabel, nameDescription };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Add the configuration for a new remote pool repository
     * Minimum allowed role: pool-operator
     * Experimental. First published in 25.7.0.
     *
     * @param c The connection the call is made on
     * @param nameLabel The name of the repository 
     * @param nameDescription The description of the repository 
     * @param binaryUrl Base URL of binary packages in the local repository of this remote pool in https://&lt;coordinator-ip&gt;/repository/enabled format 
     * @param certificate The host certificate of the coordinator of the remote pool 
     * @return The ref of the created repository record.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Repository introduceRemotePool(Connection c, String nameLabel, String nameDescription, String binaryUrl, String certificate) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.introduce_remote_pool";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, nameLabel, nameDescription, binaryUrl, certificate };
        var typeReference = new TypeReference<Repository>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Add the configuration for a new remote pool repository
     * Minimum allowed role: pool-operator
     * Experimental. First published in 25.7.0.
     *
     * @param c The connection the call is made on
     * @param nameLabel The name of the repository 
     * @param nameDescription The description of the repository 
     * @param binaryUrl Base URL of binary packages in the local repository of this remote pool in https://&lt;coordinator-ip&gt;/repository/enabled format 
     * @param certificate The host certificate of the coordinator of the remote pool 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task introduceRemotePoolAsync(Connection c, String nameLabel, String nameDescription, String binaryUrl, String certificate) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Repository.introduce_remote_pool";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, nameLabel, nameDescription, binaryUrl, certificate };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Remove the repository record from the database
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void forget(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the repository record from the database
     * Minimum allowed role: pool-operator
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task forgetAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Repository.forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the file name of the GPG public key of the repository
     * Minimum allowed role: pool-operator
     * Experimental. First published in 22.12.0.
     *
     * @param c The connection the call is made on
     * @param value The file name of the GPG public key of the repository 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setGpgkeyPath(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.set_gpgkey_path";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the file name of the GPG public key of the repository
     * Minimum allowed role: pool-operator
     * Experimental. First published in 22.12.0.
     *
     * @param c The connection the call is made on
     * @param value The file name of the GPG public key of the repository 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setGpgkeyPathAsync(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.Repository.set_gpgkey_path";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the Repositorys known to the system.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Repository> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<Repository>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of Repository references to Repository records for all Repositorys known to the system.
     * Minimum allowed role: read-only
     * First published in 1.301.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<Repository, Repository.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Repository.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<Repository, Repository.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}