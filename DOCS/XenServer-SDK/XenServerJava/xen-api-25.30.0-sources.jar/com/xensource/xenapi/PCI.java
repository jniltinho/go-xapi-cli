/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A PCI device
 * First published in XenServer 6.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class PCI extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    PCI(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a PCI, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof PCI)
        {
            PCI other = (PCI) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a PCI
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "clazzId", this.clazzId);
            print.printf("%1$20s: %2$s\n", "clazzName", this.clazzName);
            print.printf("%1$20s: %2$s\n", "vendorId", this.vendorId);
            print.printf("%1$20s: %2$s\n", "vendorName", this.vendorName);
            print.printf("%1$20s: %2$s\n", "deviceId", this.deviceId);
            print.printf("%1$20s: %2$s\n", "deviceName", this.deviceName);
            print.printf("%1$20s: %2$s\n", "host", this.host);
            print.printf("%1$20s: %2$s\n", "pciId", this.pciId);
            print.printf("%1$20s: %2$s\n", "dependencies", this.dependencies);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "subsystemVendorId", this.subsystemVendorId);
            print.printf("%1$20s: %2$s\n", "subsystemVendorName", this.subsystemVendorName);
            print.printf("%1$20s: %2$s\n", "subsystemDeviceId", this.subsystemDeviceId);
            print.printf("%1$20s: %2$s\n", "subsystemDeviceName", this.subsystemDeviceName);
            print.printf("%1$20s: %2$s\n", "driverName", this.driverName);
            return writer.toString();
        }

        /**
         * Convert a PCI.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("class_id", this.clazzId == null ? "" : this.clazzId);
            map.put("class_name", this.clazzName == null ? "" : this.clazzName);
            map.put("vendor_id", this.vendorId == null ? "" : this.vendorId);
            map.put("vendor_name", this.vendorName == null ? "" : this.vendorName);
            map.put("device_id", this.deviceId == null ? "" : this.deviceId);
            map.put("device_name", this.deviceName == null ? "" : this.deviceName);
            map.put("host", this.host == null ? new Host("OpaqueRef:NULL") : this.host);
            map.put("pci_id", this.pciId == null ? "" : this.pciId);
            map.put("dependencies", this.dependencies == null ? new LinkedHashSet<PCI>() : this.dependencies);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("subsystem_vendor_id", this.subsystemVendorId == null ? "" : this.subsystemVendorId);
            map.put("subsystem_vendor_name", this.subsystemVendorName == null ? "" : this.subsystemVendorName);
            map.put("subsystem_device_id", this.subsystemDeviceId == null ? "" : this.subsystemDeviceId);
            map.put("subsystem_device_name", this.subsystemDeviceName == null ? "" : this.subsystemDeviceName);
            map.put("driver_name", this.driverName == null ? "" : this.driverName);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * PCI class ID
         */
        @JsonProperty("class_id")
        public String clazzId;

        /**
         * PCI class name
         */
        @JsonProperty("class_name")
        public String clazzName;

        /**
         * Vendor ID
         */
        @JsonProperty("vendor_id")
        public String vendorId;

        /**
         * Vendor name
         */
        @JsonProperty("vendor_name")
        public String vendorName;

        /**
         * Device ID
         */
        @JsonProperty("device_id")
        public String deviceId;

        /**
         * Device name
         */
        @JsonProperty("device_name")
        public String deviceName;

        /**
         * Physical machine that owns the PCI device
         */
        @JsonProperty("host")
        public Host host;

        /**
         * PCI ID of the physical device
         */
        @JsonProperty("pci_id")
        public String pciId;

        /**
         * List of dependent PCI devices
         */
        @JsonProperty("dependencies")
        public Set<PCI> dependencies;

        /**
         * Additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * Subsystem vendor ID
         * First published in XenServer 6.2 SP1 Hotfix 11.
         */
        @JsonProperty("subsystem_vendor_id")
        public String subsystemVendorId;

        /**
         * Subsystem vendor name
         * First published in XenServer 6.2 SP1 Hotfix 11.
         */
        @JsonProperty("subsystem_vendor_name")
        public String subsystemVendorName;

        /**
         * Subsystem device ID
         * First published in XenServer 6.2 SP1 Hotfix 11.
         */
        @JsonProperty("subsystem_device_id")
        public String subsystemDeviceId;

        /**
         * Subsystem device name
         * First published in XenServer 6.2 SP1 Hotfix 11.
         */
        @JsonProperty("subsystem_device_name")
        public String subsystemDeviceName;

        /**
         * Driver name
         * First published in XenServer 7.5.
         */
        @JsonProperty("driver_name")
        public String driverName;

    }

    /**
     * Get a record containing the current state of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PCI.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PCI.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the PCI instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PCI getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<PCI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the class_id field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getClazzId(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_class_id";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the class_name field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getClazzName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_class_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the vendor_id field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getVendorId(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_vendor_id";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the vendor_name field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getVendorName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_vendor_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the device_id field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getDeviceId(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_device_id";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the device_name field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getDeviceName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_device_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getHost(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_host";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the pci_id field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getPciId(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_pci_id";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the dependencies field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PCI> getDependencies(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_dependencies";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PCI>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the subsystem_vendor_id field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Hotfix 11.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getSubsystemVendorId(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_subsystem_vendor_id";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the subsystem_vendor_name field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Hotfix 11.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getSubsystemVendorName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_subsystem_vendor_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the subsystem_device_id field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Hotfix 11.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getSubsystemDeviceId(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_subsystem_device_id";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the subsystem_device_name field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Hotfix 11.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getSubsystemDeviceName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_subsystem_device_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the driver_name field of the given PCI.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getDriverName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_driver_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the other_config field of the given PCI.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given PCI.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given PCI.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Hide a PCI device from the dom0 kernel. (Takes affect after next boot.)
     * Minimum allowed role: pool-operator
     * Experimental. First published in 24.14.0.
     *
     * @param c The connection the call is made on
     * @return The accessibility of this PCI from dom0
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.PciDom0Access disableDom0Access(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.disable_dom0_access";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.PciDom0Access>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Hide a PCI device from the dom0 kernel. (Takes affect after next boot.)
     * Minimum allowed role: pool-operator
     * Experimental. First published in 24.14.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task disableDom0AccessAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PCI.disable_dom0_access";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Unhide a PCI device from the dom0 kernel. (Takes affect after next boot.)
     * Minimum allowed role: pool-operator
     * Experimental. First published in 24.14.0.
     *
     * @param c The connection the call is made on
     * @return The accessibility of this PCI from dom0
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.PciDom0Access enableDom0Access(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.enable_dom0_access";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.PciDom0Access>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Unhide a PCI device from the dom0 kernel. (Takes affect after next boot.)
     * Minimum allowed role: pool-operator
     * Experimental. First published in 24.14.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task enableDom0AccessAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PCI.enable_dom0_access";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a PCI device dom0 access status.
     * Minimum allowed role: pool-operator
     * Experimental. First published in 24.14.0.
     *
     * @param c The connection the call is made on
     * @return The accessibility of this PCI from dom0
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.PciDom0Access getDom0AccessStatus(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_dom0_access_status";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.PciDom0Access>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a PCI device dom0 access status.
     * Minimum allowed role: pool-operator
     * Experimental. First published in 24.14.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getDom0AccessStatusAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PCI.get_dom0_access_status";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the PCIs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<PCI> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<PCI>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of PCI references to PCI records for all PCIs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<PCI, PCI.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PCI.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<PCI, PCI.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}