/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A storage repository
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class SR extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    SR(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a SR, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof SR)
        {
            SR other = (SR) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a SR
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "allowedOperations", this.allowedOperations);
            print.printf("%1$20s: %2$s\n", "currentOperations", this.currentOperations);
            print.printf("%1$20s: %2$s\n", "VDIs", this.VDIs);
            print.printf("%1$20s: %2$s\n", "PBDs", this.PBDs);
            print.printf("%1$20s: %2$s\n", "virtualAllocation", this.virtualAllocation);
            print.printf("%1$20s: %2$s\n", "physicalUtilisation", this.physicalUtilisation);
            print.printf("%1$20s: %2$s\n", "physicalSize", this.physicalSize);
            print.printf("%1$20s: %2$s\n", "type", this.type);
            print.printf("%1$20s: %2$s\n", "contentType", this.contentType);
            print.printf("%1$20s: %2$s\n", "shared", this.shared);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "tags", this.tags);
            print.printf("%1$20s: %2$s\n", "smConfig", this.smConfig);
            print.printf("%1$20s: %2$s\n", "blobs", this.blobs);
            print.printf("%1$20s: %2$s\n", "localCacheEnabled", this.localCacheEnabled);
            print.printf("%1$20s: %2$s\n", "introducedBy", this.introducedBy);
            print.printf("%1$20s: %2$s\n", "clustered", this.clustered);
            print.printf("%1$20s: %2$s\n", "isToolsSr", this.isToolsSr);
            return writer.toString();
        }

        /**
         * Convert a SR.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("allowed_operations", this.allowedOperations == null ? new LinkedHashSet<Types.StorageOperations>() : this.allowedOperations);
            map.put("current_operations", this.currentOperations == null ? new HashMap<String, Types.StorageOperations>() : this.currentOperations);
            map.put("VDIs", this.VDIs == null ? new LinkedHashSet<VDI>() : this.VDIs);
            map.put("PBDs", this.PBDs == null ? new LinkedHashSet<PBD>() : this.PBDs);
            map.put("virtual_allocation", this.virtualAllocation == null ? 0 : this.virtualAllocation);
            map.put("physical_utilisation", this.physicalUtilisation == null ? 0 : this.physicalUtilisation);
            map.put("physical_size", this.physicalSize == null ? 0 : this.physicalSize);
            map.put("type", this.type == null ? "" : this.type);
            map.put("content_type", this.contentType == null ? "" : this.contentType);
            map.put("shared", this.shared == null ? false : this.shared);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("tags", this.tags == null ? new LinkedHashSet<String>() : this.tags);
            map.put("sm_config", this.smConfig == null ? new HashMap<String, String>() : this.smConfig);
            map.put("blobs", this.blobs == null ? new HashMap<String, Blob>() : this.blobs);
            map.put("local_cache_enabled", this.localCacheEnabled == null ? false : this.localCacheEnabled);
            map.put("introduced_by", this.introducedBy == null ? new DRTask("OpaqueRef:NULL") : this.introducedBy);
            map.put("clustered", this.clustered == null ? false : this.clustered);
            map.put("is_tools_sr", this.isToolsSr == null ? false : this.isToolsSr);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * list of the operations allowed in this state. This list is advisory only and the server state may have changed by the time this field is read by a client.
         */
        @JsonProperty("allowed_operations")
        public Set<Types.StorageOperations> allowedOperations;

        /**
         * links each of the running tasks using this object (by reference) to a current_operation enum which describes the nature of the task.
         */
        @JsonProperty("current_operations")
        public Map<String, Types.StorageOperations> currentOperations;

        /**
         * all virtual disks known to this storage repository
         */
        @JsonProperty("VDIs")
        public Set<VDI> VDIs;

        /**
         * describes how particular hosts can see this storage repository
         */
        @JsonProperty("PBDs")
        public Set<PBD> PBDs;

        /**
         * sum of virtual_sizes of all VDIs in this storage repository (in bytes)
         */
        @JsonProperty("virtual_allocation")
        public Long virtualAllocation;

        /**
         * physical space currently utilised on this storage repository (in bytes). Note that for sparse disk formats, physical_utilisation may be less than virtual_allocation
         */
        @JsonProperty("physical_utilisation")
        public Long physicalUtilisation;

        /**
         * total physical size of the repository (in bytes)
         */
        @JsonProperty("physical_size")
        public Long physicalSize;

        /**
         * type of the storage repository
         */
        @JsonProperty("type")
        public String type;

        /**
         * the type of the SR's content, if required (e.g. ISOs)
         */
        @JsonProperty("content_type")
        public String contentType;

        /**
         * true if this SR is (capable of being) shared between multiple hosts
         */
        @JsonProperty("shared")
        public Boolean shared;

        /**
         * additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * user-specified tags for categorization purposes
         * First published in XenServer 5.0.
         */
        @JsonProperty("tags")
        public Set<String> tags;

        /**
         * SM dependent data
         * First published in XenServer 4.1.
         */
        @JsonProperty("sm_config")
        public Map<String, String> smConfig;

        /**
         * Binary blobs associated with this SR
         * First published in XenServer 5.0.
         */
        @JsonProperty("blobs")
        public Map<String, Blob> blobs;

        /**
         * True if this SR is assigned to be the local cache for its host
         * First published in XenServer 5.6 FP1.
         */
        @JsonProperty("local_cache_enabled")
        public Boolean localCacheEnabled;

        /**
         * The disaster recovery task which introduced this SR
         * First published in XenServer 6.0.
         */
        @JsonProperty("introduced_by")
        public DRTask introducedBy;

        /**
         * True if the SR is using aggregated local storage
         * First published in XenServer 7.0.
         */
        @JsonProperty("clustered")
        public Boolean clustered;

        /**
         * True if this is the SR that contains the Tools ISO VDIs
         * First published in XenServer 7.0.
         */
        @JsonProperty("is_tools_sr")
        public Boolean isToolsSr;

    }

    /**
     * Get a record containing the current state of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public SR.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<SR.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the SR instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static SR getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the SR instances with the given label.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<SR> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<SR>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allowed_operations field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.StorageOperations> getAllowedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.StorageOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the current_operations field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Types.StorageOperations> getCurrentOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_current_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Types.StorageOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VDIs field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VDI> getVDIs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_VDIs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VDI>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PBDs field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PBD> getPBDs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_PBDs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PBD>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the virtual_allocation field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getVirtualAllocation(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_virtual_allocation";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the physical_utilisation field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getPhysicalUtilisation(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_physical_utilisation";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the physical_size field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getPhysicalSize(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_physical_size";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the type field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the content_type field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getContentType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_content_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the shared field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getShared(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_shared";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the tags field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getTags(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the sm_config field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getSmConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_sm_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the blobs field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Blob> getBlobs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_blobs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Blob>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the local_cache_enabled field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getLocalCacheEnabled(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_local_cache_enabled";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the introduced_by field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public DRTask getIntroducedBy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_introduced_by";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<DRTask>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the clustered field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getClustered(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_clustered";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_tools_sr field of the given SR.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsToolsSr(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_is_tools_sr";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the other_config field of the given SR.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given SR.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given SR.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the tags field of the given SR.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param tags New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setTags(Connection c, Set<String> tags) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.set_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, tags };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given value to the tags field of the given SR.  If the value is already in that Set, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value New value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addTags(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.add_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given value from the tags field of the given SR.  If the value is not in that Set, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value Value to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeTags(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.remove_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the sm_config field of the given SR.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param smConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSmConfig(Connection c, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.set_sm_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, smConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the sm_config field of the given SR.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToSmConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.add_to_sm_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the sm_config field of the given SR.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromSmConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.remove_from_sm_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Create a new Storage Repository and introduce it into the managed system, creating both SR record and PBD record to attach it to current host (with specified device_config parameters)
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @param physicalSize The physical size of the new storage repository 
     * @param nameLabel The name of the new storage repository 
     * @param nameDescription The description of the new storage repository 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param contentType The type of the new SRs content, if required (e.g. ISOs) 
     * @param shared True if the SR (is capable of) being shared by multiple hosts 
     * @return The reference of the newly created Storage Repository.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrUnknownDriver The SR could not be connected because the driver was not recognised.
     */
    public static SR create(Connection c, Host host, Map<String, String> deviceConfig, Long physicalSize, String nameLabel, String nameDescription, String type, String contentType, Boolean shared) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrUnknownDriver {
        String methodCall = "SR.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig, physicalSize, nameLabel, nameDescription, type, contentType, shared };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new Storage Repository and introduce it into the managed system, creating both SR record and PBD record to attach it to current host (with specified device_config parameters)
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @param physicalSize The physical size of the new storage repository 
     * @param nameLabel The name of the new storage repository 
     * @param nameDescription The description of the new storage repository 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param contentType The type of the new SRs content, if required (e.g. ISOs) 
     * @param shared True if the SR (is capable of) being shared by multiple hosts 
     * @param smConfig Storage backend specific configuration options First published in XenServer 4.1.
     * @return The reference of the newly created Storage Repository.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrUnknownDriver The SR could not be connected because the driver was not recognised.
     */
    public static SR create(Connection c, Host host, Map<String, String> deviceConfig, Long physicalSize, String nameLabel, String nameDescription, String type, String contentType, Boolean shared, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrUnknownDriver {
        String methodCall = "SR.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig, physicalSize, nameLabel, nameDescription, type, contentType, shared, smConfig };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new Storage Repository and introduce it into the managed system, creating both SR record and PBD record to attach it to current host (with specified device_config parameters)
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @param physicalSize The physical size of the new storage repository 
     * @param nameLabel The name of the new storage repository 
     * @param nameDescription The description of the new storage repository 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param contentType The type of the new SRs content, if required (e.g. ISOs) 
     * @param shared True if the SR (is capable of) being shared by multiple hosts 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrUnknownDriver The SR could not be connected because the driver was not recognised.
     */
    public static Task createAsync(Connection c, Host host, Map<String, String> deviceConfig, Long physicalSize, String nameLabel, String nameDescription, String type, String contentType, Boolean shared) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrUnknownDriver {
        String methodCall = "Async.SR.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig, physicalSize, nameLabel, nameDescription, type, contentType, shared };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new Storage Repository and introduce it into the managed system, creating both SR record and PBD record to attach it to current host (with specified device_config parameters)
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @param physicalSize The physical size of the new storage repository 
     * @param nameLabel The name of the new storage repository 
     * @param nameDescription The description of the new storage repository 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param contentType The type of the new SRs content, if required (e.g. ISOs) 
     * @param shared True if the SR (is capable of) being shared by multiple hosts 
     * @param smConfig Storage backend specific configuration options First published in XenServer 4.1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrUnknownDriver The SR could not be connected because the driver was not recognised.
     */
    public static Task createAsync(Connection c, Host host, Map<String, String> deviceConfig, Long physicalSize, String nameLabel, String nameDescription, String type, String contentType, Boolean shared, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrUnknownDriver {
        String methodCall = "Async.SR.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig, physicalSize, nameLabel, nameDescription, type, contentType, shared, smConfig };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Introduce a new Storage Repository into the managed system
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid The uuid assigned to the introduced SR 
     * @param nameLabel The name of the new storage repository 
     * @param nameDescription The description of the new storage repository 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param contentType The type of the new SRs content, if required (e.g. ISOs) 
     * @param shared True if the SR (is capable of) being shared by multiple hosts 
     * @return The reference of the newly introduced Storage Repository.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static SR introduce(Connection c, String uuid, String nameLabel, String nameDescription, String type, String contentType, Boolean shared) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid, nameLabel, nameDescription, type, contentType, shared };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Introduce a new Storage Repository into the managed system
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid The uuid assigned to the introduced SR 
     * @param nameLabel The name of the new storage repository 
     * @param nameDescription The description of the new storage repository 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param contentType The type of the new SRs content, if required (e.g. ISOs) 
     * @param shared True if the SR (is capable of) being shared by multiple hosts 
     * @param smConfig Storage backend specific configuration options First published in XenServer 4.1.
     * @return The reference of the newly introduced Storage Repository.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static SR introduce(Connection c, String uuid, String nameLabel, String nameDescription, String type, String contentType, Boolean shared, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid, nameLabel, nameDescription, type, contentType, shared, smConfig };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Introduce a new Storage Repository into the managed system
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid The uuid assigned to the introduced SR 
     * @param nameLabel The name of the new storage repository 
     * @param nameDescription The description of the new storage repository 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param contentType The type of the new SRs content, if required (e.g. ISOs) 
     * @param shared True if the SR (is capable of) being shared by multiple hosts 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task introduceAsync(Connection c, String uuid, String nameLabel, String nameDescription, String type, String contentType, Boolean shared) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid, nameLabel, nameDescription, type, contentType, shared };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Introduce a new Storage Repository into the managed system
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid The uuid assigned to the introduced SR 
     * @param nameLabel The name of the new storage repository 
     * @param nameDescription The description of the new storage repository 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param contentType The type of the new SRs content, if required (e.g. ISOs) 
     * @param shared True if the SR (is capable of) being shared by multiple hosts 
     * @param smConfig Storage backend specific configuration options First published in XenServer 4.1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task introduceAsync(Connection c, String uuid, String nameLabel, String nameDescription, String type, String contentType, Boolean shared, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.introduce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid, nameLabel, nameDescription, type, contentType, shared, smConfig };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new Storage Repository on disk. This call is deprecated: use SR.create instead.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     * @deprecated since XenServer 4.1
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @param physicalSize The physical size of the new storage repository 
     * @param nameLabel The name of the new storage repository 
     * @param nameDescription The description of the new storage repository 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param contentType The type of the new SRs content, if required (e.g. ISOs) 
     * @return The uuid of the newly created Storage Repository.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 4.1")
    public static String make(Connection c, Host host, Map<String, String> deviceConfig, Long physicalSize, String nameLabel, String nameDescription, String type, String contentType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.make";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig, physicalSize, nameLabel, nameDescription, type, contentType };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new Storage Repository on disk. This call is deprecated: use SR.create instead.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     * @deprecated since XenServer 4.1
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @param physicalSize The physical size of the new storage repository 
     * @param nameLabel The name of the new storage repository 
     * @param nameDescription The description of the new storage repository 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param contentType The type of the new SRs content, if required (e.g. ISOs) 
     * @param smConfig Storage backend specific configuration options First published in XenServer 4.1.
     * @return The uuid of the newly created Storage Repository.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 4.1")
    public static String make(Connection c, Host host, Map<String, String> deviceConfig, Long physicalSize, String nameLabel, String nameDescription, String type, String contentType, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.make";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig, physicalSize, nameLabel, nameDescription, type, contentType, smConfig };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new Storage Repository on disk. This call is deprecated: use SR.create instead.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     * @deprecated since XenServer 4.1
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @param physicalSize The physical size of the new storage repository 
     * @param nameLabel The name of the new storage repository 
     * @param nameDescription The description of the new storage repository 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param contentType The type of the new SRs content, if required (e.g. ISOs) 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 4.1")
    public static Task makeAsync(Connection c, Host host, Map<String, String> deviceConfig, Long physicalSize, String nameLabel, String nameDescription, String type, String contentType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.make";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig, physicalSize, nameLabel, nameDescription, type, contentType };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new Storage Repository on disk. This call is deprecated: use SR.create instead.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     * @deprecated since XenServer 4.1
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @param physicalSize The physical size of the new storage repository 
     * @param nameLabel The name of the new storage repository 
     * @param nameDescription The description of the new storage repository 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param contentType The type of the new SRs content, if required (e.g. ISOs) 
     * @param smConfig Storage backend specific configuration options First published in XenServer 4.1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 4.1")
    public static Task makeAsync(Connection c, Host host, Map<String, String> deviceConfig, Long physicalSize, String nameLabel, String nameDescription, String type, String contentType, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.make";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig, physicalSize, nameLabel, nameDescription, type, contentType, smConfig };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy specified SR, removing SR-record from database and remove SR from disk. (In order to affect this operation the appropriate device_config is read from the specified SR's PBD on current host)
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrHasPbd The SR is still connected to a host via a PBD. It cannot be destroyed or forgotten.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrHasPbd {
        String methodCall = "SR.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy specified SR, removing SR-record from database and remove SR from disk. (In order to affect this operation the appropriate device_config is read from the specified SR's PBD on current host)
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrHasPbd The SR is still connected to a host via a PBD. It cannot be destroyed or forgotten.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrHasPbd {
        String methodCall = "Async.SR.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Removing specified SR-record from database, without attempting to remove SR from disk
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrHasPbd The SR is still connected to a host via a PBD. It cannot be destroyed or forgotten.
     */
    public void forget(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrHasPbd {
        String methodCall = "SR.forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Removing specified SR-record from database, without attempting to remove SR from disk
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.SrHasPbd The SR is still connected to a host via a PBD. It cannot be destroyed or forgotten.
     */
    public Task forgetAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.SrHasPbd {
        String methodCall = "Async.SR.forget";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Refresh the fields on the SR object
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.1.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void update(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.update";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Refresh the fields on the SR object
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task updateAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.update";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a set of all the SR types supported by the system
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return the supported SR types
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<String> getSupportedTypes(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_supported_types";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Refreshes the list of VDIs associated with an SR
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void scan(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.scan";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Refreshes the list of VDIs associated with an SR
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task scanAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.scan";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Perform a backend-specific scan, using the given device_config.  If the device_config is complete, then this will return a list of the SRs present of this type on the device, if any.  If the device_config is partial, then a backend-specific scan will be performed, returning results that will guide the user in improving the device_config.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @return An XML fragment containing the scan results.  These are specific to the scan being performed, and the backend.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static String probe(Connection c, Host host, Map<String, String> deviceConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.probe";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Perform a backend-specific scan, using the given device_config.  If the device_config is complete, then this will return a list of the SRs present of this type on the device, if any.  If the device_config is partial, then a backend-specific scan will be performed, returning results that will guide the user in improving the device_config.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param smConfig Storage backend specific configuration options 
     * @return An XML fragment containing the scan results.  These are specific to the scan being performed, and the backend.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static String probe(Connection c, Host host, Map<String, String> deviceConfig, String type, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.probe";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig, type, smConfig };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Perform a backend-specific scan, using the given device_config.  If the device_config is complete, then this will return a list of the SRs present of this type on the device, if any.  If the device_config is partial, then a backend-specific scan will be performed, returning results that will guide the user in improving the device_config.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task probeAsync(Connection c, Host host, Map<String, String> deviceConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.probe";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Perform a backend-specific scan, using the given device_config.  If the device_config is complete, then this will return a list of the SRs present of this type on the device, if any.  If the device_config is partial, then a backend-specific scan will be performed, returning results that will guide the user in improving the device_config.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param smConfig Storage backend specific configuration options 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task probeAsync(Connection c, Host host, Map<String, String> deviceConfig, String type, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.probe";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig, type, smConfig };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Perform a backend-specific scan, using the given device_config.  If the device_config is complete, then this will return a list of the SRs present of this type on the device, if any.  If the device_config is partial, then a backend-specific scan will be performed, returning results that will guide the user in improving the device_config.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param smConfig Storage backend specific configuration options 
     * @return A set of records containing the scan results.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<ProbeResult.Record> probeExt(Connection c, Host host, Map<String, String> deviceConfig, String type, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.probe_ext";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig, type, smConfig };
        var typeReference = new TypeReference<Set<ProbeResult.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Perform a backend-specific scan, using the given device_config.  If the device_config is complete, then this will return a list of the SRs present of this type on the device, if any.  If the device_config is partial, then a backend-specific scan will be performed, returning results that will guide the user in improving the device_config.
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.6.
     *
     * @param c The connection the call is made on
     * @param host The host to create/make the SR on 
     * @param deviceConfig The device config string that will be passed to backend SR driver 
     * @param type The type of the SR; used to specify the SR backend driver to use 
     * @param smConfig Storage backend specific configuration options 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task probeExtAsync(Connection c, Host host, Map<String, String> deviceConfig, String type, Map<String, String> smConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.probe_ext";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, host, deviceConfig, type, smConfig };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sets the shared flag on the SR
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value True if the SR is shared 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setShared(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.set_shared";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets the shared flag on the SR
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value True if the SR is shared 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setSharedAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.set_shared";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name label of the SR
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value The name label for the SR 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameLabel(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name label of the SR
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value The name label for the SR 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setNameLabelAsync(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name description of the SR
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value The name description for the SR 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameDescription(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name description of the SR
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value The name description for the SR 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setNameDescriptionAsync(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this SR
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @return The reference of the blob, needed for populating its data
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Blob createNewBlob(Connection c, String name, String mimeType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType };
        var typeReference = new TypeReference<Blob>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this SR
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @param _public True if the blob should be publicly available First published in XenServer 6.1.
     * @return The reference of the blob, needed for populating its data
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Blob createNewBlob(Connection c, String name, String mimeType, Boolean _public) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType, _public };
        var typeReference = new TypeReference<Blob>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this SR
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task createNewBlobAsync(Connection c, String name, String mimeType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this SR
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @param _public True if the blob should be publicly available First published in XenServer 6.1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task createNewBlobAsync(Connection c, String name, String mimeType, Boolean _public) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType, _public };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sets the SR's physical_size field
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param value The new value of the SR's physical_size 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setPhysicalSize(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.set_physical_size";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Returns successfully if the given SR can host an HA statefile. Otherwise returns an error to explain why not
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void assertCanHostHaStatefile(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.assert_can_host_ha_statefile";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Returns successfully if the given SR can host an HA statefile. Otherwise returns an error to explain why not
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task assertCanHostHaStatefileAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.assert_can_host_ha_statefile";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns successfully if the given SR supports database replication. Otherwise returns an error to explain why not.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void assertSupportsDatabaseReplication(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.assert_supports_database_replication";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Returns successfully if the given SR supports database replication. Otherwise returns an error to explain why not.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task assertSupportsDatabaseReplicationAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.assert_supports_database_replication";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void enableDatabaseReplication(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.enable_database_replication";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task enableDatabaseReplicationAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.enable_database_replication";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void disableDatabaseReplication(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.disable_database_replication";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task disableDatabaseReplicationAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.SR.disable_database_replication";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return A set of data sources
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<DataSource.Record> getDataSources(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_data_sources";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<DataSource.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Start recording the specified data source
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param dataSource The data source to record 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void recordDataSource(Connection c, String dataSource) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.record_data_source";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dataSource };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Query the latest value of the specified data source
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param dataSource The data source to query 
     * @return The latest value, averaged over the last 5 seconds
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Double queryDataSource(Connection c, String dataSource) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.query_data_source";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dataSource };
        var typeReference = new TypeReference<Double>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Forget the recorded statistics related to the specified data source
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param dataSource The data source whose archives are to be forgotten 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void forgetDataSourceArchives(Connection c, String dataSource) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.forget_data_source_archives";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dataSource };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Return a list of all the SRs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<SR> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<SR>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of SR references to SR records for all SRs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<SR, SR.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "SR.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<SR, SR.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}