/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A virtual machine (or &apos;guest&apos;).
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class VM extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    VM(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a VM, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof VM)
        {
            VM other = (VM) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a VM
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "allowedOperations", this.allowedOperations);
            print.printf("%1$20s: %2$s\n", "currentOperations", this.currentOperations);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "powerState", this.powerState);
            print.printf("%1$20s: %2$s\n", "userVersion", this.userVersion);
            print.printf("%1$20s: %2$s\n", "isATemplate", this.isATemplate);
            print.printf("%1$20s: %2$s\n", "isDefaultTemplate", this.isDefaultTemplate);
            print.printf("%1$20s: %2$s\n", "suspendVDI", this.suspendVDI);
            print.printf("%1$20s: %2$s\n", "residentOn", this.residentOn);
            print.printf("%1$20s: %2$s\n", "scheduledToBeResidentOn", this.scheduledToBeResidentOn);
            print.printf("%1$20s: %2$s\n", "affinity", this.affinity);
            print.printf("%1$20s: %2$s\n", "memoryOverhead", this.memoryOverhead);
            print.printf("%1$20s: %2$s\n", "memoryTarget", this.memoryTarget);
            print.printf("%1$20s: %2$s\n", "memoryStaticMax", this.memoryStaticMax);
            print.printf("%1$20s: %2$s\n", "memoryDynamicMax", this.memoryDynamicMax);
            print.printf("%1$20s: %2$s\n", "memoryDynamicMin", this.memoryDynamicMin);
            print.printf("%1$20s: %2$s\n", "memoryStaticMin", this.memoryStaticMin);
            print.printf("%1$20s: %2$s\n", "VCPUsParams", this.VCPUsParams);
            print.printf("%1$20s: %2$s\n", "VCPUsMax", this.VCPUsMax);
            print.printf("%1$20s: %2$s\n", "VCPUsAtStartup", this.VCPUsAtStartup);
            print.printf("%1$20s: %2$s\n", "actionsAfterSoftreboot", this.actionsAfterSoftreboot);
            print.printf("%1$20s: %2$s\n", "actionsAfterShutdown", this.actionsAfterShutdown);
            print.printf("%1$20s: %2$s\n", "actionsAfterReboot", this.actionsAfterReboot);
            print.printf("%1$20s: %2$s\n", "actionsAfterCrash", this.actionsAfterCrash);
            print.printf("%1$20s: %2$s\n", "consoles", this.consoles);
            print.printf("%1$20s: %2$s\n", "VIFs", this.VIFs);
            print.printf("%1$20s: %2$s\n", "VBDs", this.VBDs);
            print.printf("%1$20s: %2$s\n", "VUSBs", this.VUSBs);
            print.printf("%1$20s: %2$s\n", "crashDumps", this.crashDumps);
            print.printf("%1$20s: %2$s\n", "VTPMs", this.VTPMs);
            print.printf("%1$20s: %2$s\n", "PVBootloader", this.PVBootloader);
            print.printf("%1$20s: %2$s\n", "PVKernel", this.PVKernel);
            print.printf("%1$20s: %2$s\n", "PVRamdisk", this.PVRamdisk);
            print.printf("%1$20s: %2$s\n", "PVArgs", this.PVArgs);
            print.printf("%1$20s: %2$s\n", "PVBootloaderArgs", this.PVBootloaderArgs);
            print.printf("%1$20s: %2$s\n", "PVLegacyArgs", this.PVLegacyArgs);
            print.printf("%1$20s: %2$s\n", "HVMBootPolicy", this.HVMBootPolicy);
            print.printf("%1$20s: %2$s\n", "HVMBootParams", this.HVMBootParams);
            print.printf("%1$20s: %2$s\n", "HVMShadowMultiplier", this.HVMShadowMultiplier);
            print.printf("%1$20s: %2$s\n", "platform", this.platform);
            print.printf("%1$20s: %2$s\n", "PCIBus", this.PCIBus);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "domid", this.domid);
            print.printf("%1$20s: %2$s\n", "domarch", this.domarch);
            print.printf("%1$20s: %2$s\n", "lastBootCPUFlags", this.lastBootCPUFlags);
            print.printf("%1$20s: %2$s\n", "isControlDomain", this.isControlDomain);
            print.printf("%1$20s: %2$s\n", "metrics", this.metrics);
            print.printf("%1$20s: %2$s\n", "guestMetrics", this.guestMetrics);
            print.printf("%1$20s: %2$s\n", "lastBootedRecord", this.lastBootedRecord);
            print.printf("%1$20s: %2$s\n", "recommendations", this.recommendations);
            print.printf("%1$20s: %2$s\n", "xenstoreData", this.xenstoreData);
            print.printf("%1$20s: %2$s\n", "haAlwaysRun", this.haAlwaysRun);
            print.printf("%1$20s: %2$s\n", "haRestartPriority", this.haRestartPriority);
            print.printf("%1$20s: %2$s\n", "isASnapshot", this.isASnapshot);
            print.printf("%1$20s: %2$s\n", "snapshotOf", this.snapshotOf);
            print.printf("%1$20s: %2$s\n", "snapshots", this.snapshots);
            print.printf("%1$20s: %2$s\n", "snapshotTime", this.snapshotTime);
            print.printf("%1$20s: %2$s\n", "transportableSnapshotId", this.transportableSnapshotId);
            print.printf("%1$20s: %2$s\n", "blobs", this.blobs);
            print.printf("%1$20s: %2$s\n", "tags", this.tags);
            print.printf("%1$20s: %2$s\n", "blockedOperations", this.blockedOperations);
            print.printf("%1$20s: %2$s\n", "snapshotInfo", this.snapshotInfo);
            print.printf("%1$20s: %2$s\n", "snapshotMetadata", this.snapshotMetadata);
            print.printf("%1$20s: %2$s\n", "parent", this.parent);
            print.printf("%1$20s: %2$s\n", "children", this.children);
            print.printf("%1$20s: %2$s\n", "biosStrings", this.biosStrings);
            print.printf("%1$20s: %2$s\n", "protectionPolicy", this.protectionPolicy);
            print.printf("%1$20s: %2$s\n", "isSnapshotFromVmpp", this.isSnapshotFromVmpp);
            print.printf("%1$20s: %2$s\n", "snapshotSchedule", this.snapshotSchedule);
            print.printf("%1$20s: %2$s\n", "isVmssSnapshot", this.isVmssSnapshot);
            print.printf("%1$20s: %2$s\n", "appliance", this.appliance);
            print.printf("%1$20s: %2$s\n", "startDelay", this.startDelay);
            print.printf("%1$20s: %2$s\n", "shutdownDelay", this.shutdownDelay);
            print.printf("%1$20s: %2$s\n", "order", this.order);
            print.printf("%1$20s: %2$s\n", "VGPUs", this.VGPUs);
            print.printf("%1$20s: %2$s\n", "attachedPCIs", this.attachedPCIs);
            print.printf("%1$20s: %2$s\n", "suspendSR", this.suspendSR);
            print.printf("%1$20s: %2$s\n", "version", this.version);
            print.printf("%1$20s: %2$s\n", "generationId", this.generationId);
            print.printf("%1$20s: %2$s\n", "hardwarePlatformVersion", this.hardwarePlatformVersion);
            print.printf("%1$20s: %2$s\n", "hasVendorDevice", this.hasVendorDevice);
            print.printf("%1$20s: %2$s\n", "requiresReboot", this.requiresReboot);
            print.printf("%1$20s: %2$s\n", "referenceLabel", this.referenceLabel);
            print.printf("%1$20s: %2$s\n", "domainType", this.domainType);
            print.printf("%1$20s: %2$s\n", "NVRAM", this.NVRAM);
            print.printf("%1$20s: %2$s\n", "pendingGuidances", this.pendingGuidances);
            print.printf("%1$20s: %2$s\n", "pendingGuidancesRecommended", this.pendingGuidancesRecommended);
            print.printf("%1$20s: %2$s\n", "pendingGuidancesFull", this.pendingGuidancesFull);
            print.printf("%1$20s: %2$s\n", "groups", this.groups);
            return writer.toString();
        }

        /**
         * Convert a VM.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("allowed_operations", this.allowedOperations == null ? new LinkedHashSet<Types.VmOperations>() : this.allowedOperations);
            map.put("current_operations", this.currentOperations == null ? new HashMap<String, Types.VmOperations>() : this.currentOperations);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("power_state", this.powerState == null ? Types.VmPowerState.UNRECOGNIZED : this.powerState);
            map.put("user_version", this.userVersion == null ? 0 : this.userVersion);
            map.put("is_a_template", this.isATemplate == null ? false : this.isATemplate);
            map.put("is_default_template", this.isDefaultTemplate == null ? false : this.isDefaultTemplate);
            map.put("suspend_VDI", this.suspendVDI == null ? new VDI("OpaqueRef:NULL") : this.suspendVDI);
            map.put("resident_on", this.residentOn == null ? new Host("OpaqueRef:NULL") : this.residentOn);
            map.put("scheduled_to_be_resident_on", this.scheduledToBeResidentOn == null ? new Host("OpaqueRef:NULL") : this.scheduledToBeResidentOn);
            map.put("affinity", this.affinity == null ? new Host("OpaqueRef:NULL") : this.affinity);
            map.put("memory_overhead", this.memoryOverhead == null ? 0 : this.memoryOverhead);
            map.put("memory_target", this.memoryTarget == null ? 0 : this.memoryTarget);
            map.put("memory_static_max", this.memoryStaticMax == null ? 0 : this.memoryStaticMax);
            map.put("memory_dynamic_max", this.memoryDynamicMax == null ? 0 : this.memoryDynamicMax);
            map.put("memory_dynamic_min", this.memoryDynamicMin == null ? 0 : this.memoryDynamicMin);
            map.put("memory_static_min", this.memoryStaticMin == null ? 0 : this.memoryStaticMin);
            map.put("VCPUs_params", this.VCPUsParams == null ? new HashMap<String, String>() : this.VCPUsParams);
            map.put("VCPUs_max", this.VCPUsMax == null ? 0 : this.VCPUsMax);
            map.put("VCPUs_at_startup", this.VCPUsAtStartup == null ? 0 : this.VCPUsAtStartup);
            map.put("actions_after_softreboot", this.actionsAfterSoftreboot == null ? Types.OnSoftrebootBehavior.UNRECOGNIZED : this.actionsAfterSoftreboot);
            map.put("actions_after_shutdown", this.actionsAfterShutdown == null ? Types.OnNormalExit.UNRECOGNIZED : this.actionsAfterShutdown);
            map.put("actions_after_reboot", this.actionsAfterReboot == null ? Types.OnNormalExit.UNRECOGNIZED : this.actionsAfterReboot);
            map.put("actions_after_crash", this.actionsAfterCrash == null ? Types.OnCrashBehaviour.UNRECOGNIZED : this.actionsAfterCrash);
            map.put("consoles", this.consoles == null ? new LinkedHashSet<Console>() : this.consoles);
            map.put("VIFs", this.VIFs == null ? new LinkedHashSet<VIF>() : this.VIFs);
            map.put("VBDs", this.VBDs == null ? new LinkedHashSet<VBD>() : this.VBDs);
            map.put("VUSBs", this.VUSBs == null ? new LinkedHashSet<VUSB>() : this.VUSBs);
            map.put("crash_dumps", this.crashDumps == null ? new LinkedHashSet<Crashdump>() : this.crashDumps);
            map.put("VTPMs", this.VTPMs == null ? new LinkedHashSet<VTPM>() : this.VTPMs);
            map.put("PV_bootloader", this.PVBootloader == null ? "" : this.PVBootloader);
            map.put("PV_kernel", this.PVKernel == null ? "" : this.PVKernel);
            map.put("PV_ramdisk", this.PVRamdisk == null ? "" : this.PVRamdisk);
            map.put("PV_args", this.PVArgs == null ? "" : this.PVArgs);
            map.put("PV_bootloader_args", this.PVBootloaderArgs == null ? "" : this.PVBootloaderArgs);
            map.put("PV_legacy_args", this.PVLegacyArgs == null ? "" : this.PVLegacyArgs);
            map.put("HVM_boot_policy", this.HVMBootPolicy == null ? "" : this.HVMBootPolicy);
            map.put("HVM_boot_params", this.HVMBootParams == null ? new HashMap<String, String>() : this.HVMBootParams);
            map.put("HVM_shadow_multiplier", this.HVMShadowMultiplier == null ? 0.0 : this.HVMShadowMultiplier);
            map.put("platform", this.platform == null ? new HashMap<String, String>() : this.platform);
            map.put("PCI_bus", this.PCIBus == null ? "" : this.PCIBus);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("domid", this.domid == null ? 0 : this.domid);
            map.put("domarch", this.domarch == null ? "" : this.domarch);
            map.put("last_boot_CPU_flags", this.lastBootCPUFlags == null ? new HashMap<String, String>() : this.lastBootCPUFlags);
            map.put("is_control_domain", this.isControlDomain == null ? false : this.isControlDomain);
            map.put("metrics", this.metrics == null ? new VMMetrics("OpaqueRef:NULL") : this.metrics);
            map.put("guest_metrics", this.guestMetrics == null ? new VMGuestMetrics("OpaqueRef:NULL") : this.guestMetrics);
            map.put("last_booted_record", this.lastBootedRecord == null ? "" : this.lastBootedRecord);
            map.put("recommendations", this.recommendations == null ? "" : this.recommendations);
            map.put("xenstore_data", this.xenstoreData == null ? new HashMap<String, String>() : this.xenstoreData);
            map.put("ha_always_run", this.haAlwaysRun == null ? false : this.haAlwaysRun);
            map.put("ha_restart_priority", this.haRestartPriority == null ? "" : this.haRestartPriority);
            map.put("is_a_snapshot", this.isASnapshot == null ? false : this.isASnapshot);
            map.put("snapshot_of", this.snapshotOf == null ? new VM("OpaqueRef:NULL") : this.snapshotOf);
            map.put("snapshots", this.snapshots == null ? new LinkedHashSet<VM>() : this.snapshots);
            map.put("snapshot_time", this.snapshotTime == null ? new Date(0) : this.snapshotTime);
            map.put("transportable_snapshot_id", this.transportableSnapshotId == null ? "" : this.transportableSnapshotId);
            map.put("blobs", this.blobs == null ? new HashMap<String, Blob>() : this.blobs);
            map.put("tags", this.tags == null ? new LinkedHashSet<String>() : this.tags);
            map.put("blocked_operations", this.blockedOperations == null ? new HashMap<Types.VmOperations, String>() : this.blockedOperations);
            map.put("snapshot_info", this.snapshotInfo == null ? new HashMap<String, String>() : this.snapshotInfo);
            map.put("snapshot_metadata", this.snapshotMetadata == null ? "" : this.snapshotMetadata);
            map.put("parent", this.parent == null ? new VM("OpaqueRef:NULL") : this.parent);
            map.put("children", this.children == null ? new LinkedHashSet<VM>() : this.children);
            map.put("bios_strings", this.biosStrings == null ? new HashMap<String, String>() : this.biosStrings);
            map.put("protection_policy", this.protectionPolicy == null ? new VMPP("OpaqueRef:NULL") : this.protectionPolicy);
            map.put("is_snapshot_from_vmpp", this.isSnapshotFromVmpp == null ? false : this.isSnapshotFromVmpp);
            map.put("snapshot_schedule", this.snapshotSchedule == null ? new VMSS("OpaqueRef:NULL") : this.snapshotSchedule);
            map.put("is_vmss_snapshot", this.isVmssSnapshot == null ? false : this.isVmssSnapshot);
            map.put("appliance", this.appliance == null ? new VMAppliance("OpaqueRef:NULL") : this.appliance);
            map.put("start_delay", this.startDelay == null ? 0 : this.startDelay);
            map.put("shutdown_delay", this.shutdownDelay == null ? 0 : this.shutdownDelay);
            map.put("order", this.order == null ? 0 : this.order);
            map.put("VGPUs", this.VGPUs == null ? new LinkedHashSet<VGPU>() : this.VGPUs);
            map.put("attached_PCIs", this.attachedPCIs == null ? new LinkedHashSet<PCI>() : this.attachedPCIs);
            map.put("suspend_SR", this.suspendSR == null ? new SR("OpaqueRef:NULL") : this.suspendSR);
            map.put("version", this.version == null ? 0 : this.version);
            map.put("generation_id", this.generationId == null ? "" : this.generationId);
            map.put("hardware_platform_version", this.hardwarePlatformVersion == null ? 0 : this.hardwarePlatformVersion);
            map.put("has_vendor_device", this.hasVendorDevice == null ? false : this.hasVendorDevice);
            map.put("requires_reboot", this.requiresReboot == null ? false : this.requiresReboot);
            map.put("reference_label", this.referenceLabel == null ? "" : this.referenceLabel);
            map.put("domain_type", this.domainType == null ? Types.DomainType.UNRECOGNIZED : this.domainType);
            map.put("NVRAM", this.NVRAM == null ? new HashMap<String, String>() : this.NVRAM);
            map.put("pending_guidances", this.pendingGuidances == null ? new LinkedHashSet<Types.UpdateGuidances>() : this.pendingGuidances);
            map.put("pending_guidances_recommended", this.pendingGuidancesRecommended == null ? new LinkedHashSet<Types.UpdateGuidances>() : this.pendingGuidancesRecommended);
            map.put("pending_guidances_full", this.pendingGuidancesFull == null ? new LinkedHashSet<Types.UpdateGuidances>() : this.pendingGuidancesFull);
            map.put("groups", this.groups == null ? new LinkedHashSet<VMGroup>() : this.groups);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * list of the operations allowed in this state. This list is advisory only and the server state may have changed by the time this field is read by a client.
         */
        @JsonProperty("allowed_operations")
        public Set<Types.VmOperations> allowedOperations;

        /**
         * links each of the running tasks using this object (by reference) to a current_operation enum which describes the nature of the task.
         */
        @JsonProperty("current_operations")
        public Map<String, Types.VmOperations> currentOperations;

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * Current power state of the machine
         */
        @JsonProperty("power_state")
        public Types.VmPowerState powerState;

        /**
         * Creators of VMs and templates may store version information here.
         */
        @JsonProperty("user_version")
        public Long userVersion;

        /**
         * true if this is a template. Template VMs can never be started, they are used only for cloning other VMs
         */
        @JsonProperty("is_a_template")
        public Boolean isATemplate;

        /**
         * true if this is a default template. Default template VMs can never be started or migrated, they are used only for cloning other VMs
         * First published in XenServer 7.2.
         */
        @JsonProperty("is_default_template")
        public Boolean isDefaultTemplate;

        /**
         * The VDI that a suspend image is stored on. (Only has meaning if VM is currently suspended)
         */
        @JsonProperty("suspend_VDI")
        public VDI suspendVDI;

        /**
         * the host the VM is currently resident on
         */
        @JsonProperty("resident_on")
        public Host residentOn;

        /**
         * the host on which the VM is due to be started/resumed/migrated. This acts as a memory reservation indicator
         */
        @JsonProperty("scheduled_to_be_resident_on")
        public Host scheduledToBeResidentOn;

        /**
         * A host which the VM has some affinity for (or NULL). This is used as a hint to the start call when it decides where to run the VM. Resource constraints may cause the VM to be started elsewhere.
         */
        @JsonProperty("affinity")
        public Host affinity;

        /**
         * Virtualization memory overhead (bytes).
         */
        @JsonProperty("memory_overhead")
        public Long memoryOverhead;

        /**
         * Dynamically-set memory target (bytes). The value of this field indicates the current target for memory available to this VM.
         */
        @JsonProperty("memory_target")
        @Deprecated(since = "XenServer 4.0")
        public Long memoryTarget;

        /**
         * Statically-set (i.e. absolute) maximum (bytes). The value of this field at VM start time acts as a hard limit of the amount of memory a guest can use. New values only take effect on reboot.
         */
        @JsonProperty("memory_static_max")
        public Long memoryStaticMax;

        /**
         * Dynamic maximum (bytes)
         */
        @JsonProperty("memory_dynamic_max")
        public Long memoryDynamicMax;

        /**
         * Dynamic minimum (bytes)
         */
        @JsonProperty("memory_dynamic_min")
        public Long memoryDynamicMin;

        /**
         * Statically-set (i.e. absolute) mininum (bytes). The value of this field indicates the least amount of memory this VM can boot with without crashing.
         */
        @JsonProperty("memory_static_min")
        public Long memoryStaticMin;

        /**
         * configuration parameters for the selected VCPU policy
         */
        @JsonProperty("VCPUs_params")
        public Map<String, String> VCPUsParams;

        /**
         * Max number of VCPUs
         */
        @JsonProperty("VCPUs_max")
        public Long VCPUsMax;

        /**
         * Boot number of VCPUs
         */
        @JsonProperty("VCPUs_at_startup")
        public Long VCPUsAtStartup;

        /**
         * action to take after soft reboot
         * Experimental. First published in 23.1.0.
         */
        @JsonProperty("actions_after_softreboot")
        public Types.OnSoftrebootBehavior actionsAfterSoftreboot;

        /**
         * action to take after the guest has shutdown itself
         */
        @JsonProperty("actions_after_shutdown")
        public Types.OnNormalExit actionsAfterShutdown;

        /**
         * action to take after the guest has rebooted itself
         */
        @JsonProperty("actions_after_reboot")
        public Types.OnNormalExit actionsAfterReboot;

        /**
         * action to take if the guest crashes
         */
        @JsonProperty("actions_after_crash")
        public Types.OnCrashBehaviour actionsAfterCrash;

        /**
         * virtual console devices
         */
        @JsonProperty("consoles")
        public Set<Console> consoles;

        /**
         * virtual network interfaces
         */
        @JsonProperty("VIFs")
        public Set<VIF> VIFs;

        /**
         * virtual block devices
         */
        @JsonProperty("VBDs")
        public Set<VBD> VBDs;

        /**
         * virtual usb devices
         */
        @JsonProperty("VUSBs")
        public Set<VUSB> VUSBs;

        /**
         * crash dumps associated with this VM
         */
        @JsonProperty("crash_dumps")
        public Set<Crashdump> crashDumps;

        /**
         * virtual TPMs
         */
        @JsonProperty("VTPMs")
        public Set<VTPM> VTPMs;

        /**
         * name of or path to bootloader
         */
        @JsonProperty("PV_bootloader")
        public String PVBootloader;

        /**
         * path to the kernel
         */
        @JsonProperty("PV_kernel")
        public String PVKernel;

        /**
         * path to the initrd
         */
        @JsonProperty("PV_ramdisk")
        public String PVRamdisk;

        /**
         * kernel command-line arguments
         */
        @JsonProperty("PV_args")
        public String PVArgs;

        /**
         * miscellaneous arguments for the bootloader
         */
        @JsonProperty("PV_bootloader_args")
        public String PVBootloaderArgs;

        /**
         * to make Zurich guests boot
         */
        @JsonProperty("PV_legacy_args")
        public String PVLegacyArgs;

        /**
         * HVM boot policy
         */
        @JsonProperty("HVM_boot_policy")
        @Deprecated(since = "XenServer 4.0")
        public String HVMBootPolicy;

        /**
         * HVM boot params
         */
        @JsonProperty("HVM_boot_params")
        public Map<String, String> HVMBootParams;

        /**
         * multiplier applied to the amount of shadow that will be made available to the guest
         * First published in XenServer 4.1.
         */
        @JsonProperty("HVM_shadow_multiplier")
        public Double HVMShadowMultiplier;

        /**
         * platform-specific configuration
         */
        @JsonProperty("platform")
        public Map<String, String> platform;

        /**
         * PCI bus path for pass-through devices
         */
        @JsonProperty("PCI_bus")
        @Deprecated(since = "XenServer 4.0")
        public String PCIBus;

        /**
         * additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * domain ID (if available, -1 otherwise)
         */
        @JsonProperty("domid")
        public Long domid;

        /**
         * Domain architecture (if available, null string otherwise)
         */
        @JsonProperty("domarch")
        public String domarch;

        /**
         * describes the CPU flags on which the VM was last booted
         */
        @JsonProperty("last_boot_CPU_flags")
        public Map<String, String> lastBootCPUFlags;

        /**
         * true if this is a control domain (domain 0 or a driver domain)
         */
        @JsonProperty("is_control_domain")
        public Boolean isControlDomain;

        /**
         * metrics associated with this VM
         */
        @JsonProperty("metrics")
        public VMMetrics metrics;

        /**
         * metrics associated with the running guest
         */
        @JsonProperty("guest_metrics")
        public VMGuestMetrics guestMetrics;

        /**
         * marshalled value containing VM record at time of last boot
         * First published in XenServer 4.1.
         */
        @JsonProperty("last_booted_record")
        public String lastBootedRecord;

        /**
         * An XML specification of recommended values and ranges for properties of this VM
         */
        @JsonProperty("recommendations")
        public String recommendations;

        /**
         * data to be inserted into the xenstore tree (/local/domain/&lt;domid&gt;/vm-data) after the VM is created.
         * First published in XenServer 4.1.
         */
        @JsonProperty("xenstore_data")
        public Map<String, String> xenstoreData;

        /**
         * if true then the system will attempt to keep the VM running as much as possible.
         * First published in XenServer 5.0.
         */
        @JsonProperty("ha_always_run")
        @Deprecated(since = "XenServer 5.0")
        public Boolean haAlwaysRun;

        /**
         * has possible values: "best-effort" meaning "try to restart this VM if possible but don't consider the Pool to be overcommitted if this is not possible"; "restart" meaning "this VM should be restarted"; "" meaning "do not try to restart this VM"
         * First published in XenServer 5.0.
         */
        @JsonProperty("ha_restart_priority")
        public String haRestartPriority;

        /**
         * true if this is a snapshot. Snapshotted VMs can never be started, they are used only for cloning other VMs
         * First published in XenServer 5.0.
         */
        @JsonProperty("is_a_snapshot")
        public Boolean isASnapshot;

        /**
         * Ref pointing to the VM this snapshot is of.
         * First published in XenServer 5.0.
         */
        @JsonProperty("snapshot_of")
        public VM snapshotOf;

        /**
         * List pointing to all the VM snapshots.
         * First published in XenServer 5.0.
         */
        @JsonProperty("snapshots")
        public Set<VM> snapshots;

        /**
         * Date/time when this snapshot was created.
         * First published in XenServer 5.0.
         */
        @JsonProperty("snapshot_time")
        public Date snapshotTime;

        /**
         * Transportable ID of the snapshot VM
         * First published in XenServer 5.0.
         */
        @JsonProperty("transportable_snapshot_id")
        public String transportableSnapshotId;

        /**
         * Binary blobs associated with this VM
         * First published in XenServer 5.0.
         */
        @JsonProperty("blobs")
        public Map<String, Blob> blobs;

        /**
         * user-specified tags for categorization purposes
         * First published in XenServer 5.0.
         */
        @JsonProperty("tags")
        public Set<String> tags;

        /**
         * List of operations which have been explicitly blocked and an error code
         * First published in XenServer 5.0.
         */
        @JsonProperty("blocked_operations")
        public Map<Types.VmOperations, String> blockedOperations;

        /**
         * Human-readable information concerning this snapshot
         * First published in XenServer 5.6.
         */
        @JsonProperty("snapshot_info")
        public Map<String, String> snapshotInfo;

        /**
         * Encoded information about the VM's metadata this is a snapshot of
         * First published in XenServer 5.6.
         */
        @JsonProperty("snapshot_metadata")
        public String snapshotMetadata;

        /**
         * Ref pointing to the parent of this VM
         * First published in XenServer 5.6.
         */
        @JsonProperty("parent")
        public VM parent;

        /**
         * List pointing to all the children of this VM
         * First published in XenServer 5.6.
         */
        @JsonProperty("children")
        public Set<VM> children;

        /**
         * BIOS strings
         * First published in XenServer 5.6.
         */
        @JsonProperty("bios_strings")
        public Map<String, String> biosStrings;

        /**
         * Ref pointing to a protection policy for this VM
         * First published in XenServer 5.6 FP1.
         */
        @JsonProperty("protection_policy")
        @Deprecated(since = "XenServer 5.6 FP1")
        public VMPP protectionPolicy;

        /**
         * true if this snapshot was created by the protection policy
         * First published in XenServer 5.6 FP1.
         */
        @JsonProperty("is_snapshot_from_vmpp")
        public Boolean isSnapshotFromVmpp;

        /**
         * Ref pointing to a snapshot schedule for this VM
         * First published in XenServer 7.2.
         */
        @JsonProperty("snapshot_schedule")
        public VMSS snapshotSchedule;

        /**
         * true if this snapshot was created by the snapshot schedule
         * First published in XenServer 7.2.
         */
        @JsonProperty("is_vmss_snapshot")
        public Boolean isVmssSnapshot;

        /**
         * the appliance to which this VM belongs
         */
        @JsonProperty("appliance")
        public VMAppliance appliance;

        /**
         * The delay to wait before proceeding to the next order in the startup sequence (seconds)
         * First published in XenServer 6.0.
         */
        @JsonProperty("start_delay")
        public Long startDelay;

        /**
         * The delay to wait before proceeding to the next order in the shutdown sequence (seconds)
         * First published in XenServer 6.0.
         */
        @JsonProperty("shutdown_delay")
        public Long shutdownDelay;

        /**
         * The point in the startup or shutdown sequence at which this VM will be started
         * First published in XenServer 6.0.
         */
        @JsonProperty("order")
        public Long order;

        /**
         * Virtual GPUs
         * First published in XenServer 6.0.
         */
        @JsonProperty("VGPUs")
        public Set<VGPU> VGPUs;

        /**
         * Currently passed-through PCI devices
         * First published in XenServer 6.0.
         */
        @JsonProperty("attached_PCIs")
        public Set<PCI> attachedPCIs;

        /**
         * The SR on which a suspend image is stored
         * First published in XenServer 6.0.
         */
        @JsonProperty("suspend_SR")
        public SR suspendSR;

        /**
         * The number of times this VM has been recovered
         * First published in XenServer 6.0.
         */
        @JsonProperty("version")
        public Long version;

        /**
         * Generation ID of the VM
         * First published in XenServer 6.2.
         */
        @JsonProperty("generation_id")
        public String generationId;

        /**
         * The host virtual hardware platform version the VM can run on
         * First published in XenServer 6.5 SP1.
         */
        @JsonProperty("hardware_platform_version")
        public Long hardwarePlatformVersion;

        /**
         * When an HVM guest starts, this controls the presence of the emulated C000 PCI device which triggers Windows Update to fetch or update PV drivers.
         * First published in XenServer 7.0.
         */
        @JsonProperty("has_vendor_device")
        public Boolean hasVendorDevice;

        /**
         * Indicates whether a VM requires a reboot in order to update its configuration, e.g. its memory allocation.
         * First published in XenServer 7.1.
         */
        @JsonProperty("requires_reboot")
        public Boolean requiresReboot;

        /**
         * Textual reference to the template used to create a VM. This can be used by clients in need of an immutable reference to the template since the latter's uuid and name_label may change, for example, after a package installation or upgrade.
         * First published in XenServer 7.1.
         */
        @JsonProperty("reference_label")
        public String referenceLabel;

        /**
         * The type of domain that will be created when the VM is started
         * First published in XenServer 7.5.
         */
        @JsonProperty("domain_type")
        public Types.DomainType domainType;

        /**
         * initial value for guest NVRAM (containing UEFI variables, etc). Cannot be changed while the VM is running
         * First published in Citrix Hypervisor 8.0.
         */
        @JsonProperty("NVRAM")
        public Map<String, String> NVRAM;

        /**
         * The set of pending mandatory guidances after applying updates, which must be applied, as otherwise there may be e.g. VM failures
         * First published in 1.303.0.
         */
        @JsonProperty("pending_guidances")
        public Set<Types.UpdateGuidances> pendingGuidances;

        /**
         * The set of pending recommended guidances after applying updates, which most users should follow to make the updates effective, but if not followed, will not cause a failure
         * Experimental. First published in 24.10.0.
         */
        @JsonProperty("pending_guidances_recommended")
        public Set<Types.UpdateGuidances> pendingGuidancesRecommended;

        /**
         * The set of pending full guidances after applying updates, which a user should follow to make some updates, e.g. specific hardware drivers or CPU features, fully effective, but the 'average user' doesn't need to
         * Experimental. First published in 24.10.0.
         */
        @JsonProperty("pending_guidances_full")
        public Set<Types.UpdateGuidances> pendingGuidancesFull;

        /**
         * VM groups associated with the VM
         * Experimental. First published in 24.19.1.
         */
        @JsonProperty("groups")
        public Set<VMGroup> groups;

    }

    /**
     * Get a record containing the current state of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VM.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VM.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the VM instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VM getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * NOT RECOMMENDED! VM.clone or VM.copy (or VM.import) is a better choice in almost all situations. The standard way to obtain a new VM is to call VM.clone on a template VM, then call VM.provision on the new clone. Caution: if VM.create is used and then the new VM is attached to a virtual disc that has an operating system already installed, then there is no guarantee that the operating system will boot and run. Any software that calls VM.create on a future version of this API may fail or give unexpected results. For example this could happen if an additional parameter were added to VM.create. VM.create is intended only for use in the automatic creation of the system VM templates. It creates a new VM instance, and returns its handle.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return reference to the newly created object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VM create(Connection c, VM.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * NOT RECOMMENDED! VM.clone or VM.copy (or VM.import) is a better choice in almost all situations. The standard way to obtain a new VM is to call VM.clone on a template VM, then call VM.provision on the new clone. Caution: if VM.create is used and then the new VM is attached to a virtual disc that has an operating system already installed, then there is no guarantee that the operating system will boot and run. Any software that calls VM.create on a future version of this API may fail or give unexpected results. For example this could happen if an additional parameter were added to VM.create. VM.create is intended only for use in the automatic creation of the system VM templates. It creates a new VM instance, and returns its handle.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, VM.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy the specified VM.  The VM is completely removed from the system.  This function can only be called when the VM is in the Halted State.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy the specified VM.  The VM is completely removed from the system.  This function can only be called when the VM is in the Halted State.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the VM instances with the given label.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VM> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<VM>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allowed_operations field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.VmOperations> getAllowedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.VmOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the current_operations field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Types.VmOperations> getCurrentOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_current_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Types.VmOperations>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the power_state field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.VmPowerState getPowerState(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_power_state";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.VmPowerState>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the user_version field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getUserVersion(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_user_version";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_a_template field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsATemplate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_is_a_template";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_default_template field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsDefaultTemplate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_is_default_template";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the suspend_VDI field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VDI getSuspendVDI(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_suspend_VDI";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VDI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the resident_on field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getResidentOn(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_resident_on";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the scheduled_to_be_resident_on field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getScheduledToBeResidentOn(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_scheduled_to_be_resident_on";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the affinity field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getAffinity(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_affinity";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the memory/overhead field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getMemoryOverhead(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_memory_overhead";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the memory/target field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 5.6
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 5.6")
    public Long getMemoryTarget(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_memory_target";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the memory/static_max field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getMemoryStaticMax(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_memory_static_max";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the memory/dynamic_max field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getMemoryDynamicMax(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_memory_dynamic_max";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the memory/dynamic_min field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getMemoryDynamicMin(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_memory_dynamic_min";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the memory/static_min field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getMemoryStaticMin(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_memory_static_min";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VCPUs/params field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getVCPUsParams(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_VCPUs_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VCPUs/max field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getVCPUsMax(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_VCPUs_max";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VCPUs/at_startup field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getVCPUsAtStartup(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_VCPUs_at_startup";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the actions/after_softreboot field of the given VM.
     * Minimum allowed role: read-only
     * Experimental. First published in 23.1.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.OnSoftrebootBehavior getActionsAfterSoftreboot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_actions_after_softreboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.OnSoftrebootBehavior>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the actions/after_shutdown field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.OnNormalExit getActionsAfterShutdown(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_actions_after_shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.OnNormalExit>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the actions/after_reboot field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.OnNormalExit getActionsAfterReboot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_actions_after_reboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.OnNormalExit>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the actions/after_crash field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.OnCrashBehaviour getActionsAfterCrash(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_actions_after_crash";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.OnCrashBehaviour>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the consoles field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Console> getConsoles(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_consoles";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Console>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VIFs field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VIF> getVIFs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_VIFs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VIF>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VBDs field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VBD> getVBDs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_VBDs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VBD>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VUSBs field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VUSB> getVUSBs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_VUSBs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VUSB>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the crash_dumps field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Crashdump> getCrashDumps(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_crash_dumps";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Crashdump>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VTPMs field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VTPM> getVTPMs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_VTPMs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VTPM>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PV/bootloader field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getPVBootloader(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_PV_bootloader";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PV/kernel field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getPVKernel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_PV_kernel";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PV/ramdisk field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getPVRamdisk(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_PV_ramdisk";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PV/args field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getPVArgs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_PV_args";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PV/bootloader_args field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getPVBootloaderArgs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_PV_bootloader_args";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PV/legacy_args field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getPVLegacyArgs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_PV_legacy_args";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the HVM/boot_policy field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 7.5
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.5")
    public String getHVMBootPolicy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_HVM_boot_policy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the HVM/boot_params field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getHVMBootParams(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_HVM_boot_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the HVM/shadow_multiplier field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Double getHVMShadowMultiplier(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_HVM_shadow_multiplier";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Double>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the platform field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getPlatform(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_platform";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PCI_bus field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 6.0
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.0")
    public String getPCIBus(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_PCI_bus";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the domid field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getDomid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_domid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the domarch field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getDomarch(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_domarch";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the last_boot_CPU_flags field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getLastBootCPUFlags(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_last_boot_CPU_flags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_control_domain field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsControlDomain(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_is_control_domain";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the metrics field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VMMetrics getMetrics(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_metrics";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VMMetrics>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the guest_metrics field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VMGuestMetrics getGuestMetrics(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_guest_metrics";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VMGuestMetrics>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the last_booted_record field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getLastBootedRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_last_booted_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the recommendations field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getRecommendations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_recommendations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the xenstore_data field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getXenstoreData(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_xenstore_data";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_always_run field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     * @deprecated since XenServer 6.0
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.0")
    public Boolean getHaAlwaysRun(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_ha_always_run";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the ha_restart_priority field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getHaRestartPriority(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_ha_restart_priority";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_a_snapshot field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsASnapshot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_is_a_snapshot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the snapshot_of field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VM getSnapshotOf(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_snapshot_of";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the snapshots field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VM> getSnapshots(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_snapshots";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VM>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the snapshot_time field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getSnapshotTime(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_snapshot_time";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the transportable_snapshot_id field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getTransportableSnapshotId(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_transportable_snapshot_id";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the blobs field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Blob> getBlobs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_blobs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Blob>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the tags field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getTags(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the blocked_operations field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<Types.VmOperations, String> getBlockedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_blocked_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<Types.VmOperations, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the snapshot_info field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getSnapshotInfo(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_snapshot_info";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the snapshot_metadata field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getSnapshotMetadata(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_snapshot_metadata";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the parent field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VM getParent(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_parent";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the children field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VM> getChildren(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_children";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VM>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the bios_strings field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getBiosStrings(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_bios_strings";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the protection_policy field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public VMPP getProtectionPolicy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_protection_policy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VMPP>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_snapshot_from_vmpp field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public Boolean getIsSnapshotFromVmpp(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_is_snapshot_from_vmpp";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the snapshot_schedule field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VMSS getSnapshotSchedule(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_snapshot_schedule";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VMSS>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_vmss_snapshot field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsVmssSnapshot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_is_vmss_snapshot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the appliance field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VMAppliance getAppliance(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_appliance";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VMAppliance>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the start_delay field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getStartDelay(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_start_delay";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the shutdown_delay field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getShutdownDelay(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_shutdown_delay";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the order field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getOrder(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_order";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VGPUs field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VGPU> getVGPUs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_VGPUs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VGPU>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the attached_PCIs field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PCI> getAttachedPCIs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_attached_PCIs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PCI>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the suspend_SR field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public SR getSuspendSR(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_suspend_SR";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<SR>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the version field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getVersion(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_version";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the generation_id field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getGenerationId(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_generation_id";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the hardware_platform_version field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 6.5 SP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getHardwarePlatformVersion(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_hardware_platform_version";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the has_vendor_device field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getHasVendorDevice(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_has_vendor_device";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the requires_reboot field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getRequiresReboot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_requires_reboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the reference_label field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getReferenceLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_reference_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the domain_type field of the given VM.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.DomainType getDomainType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_domain_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.DomainType>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the NVRAM field of the given VM.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getNVRAM(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_NVRAM";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the pending_guidances field of the given VM.
     * Minimum allowed role: read-only
     * First published in 1.303.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.UpdateGuidances> getPendingGuidances(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_pending_guidances";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.UpdateGuidances>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the pending_guidances_recommended field of the given VM.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.10.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.UpdateGuidances> getPendingGuidancesRecommended(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_pending_guidances_recommended";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.UpdateGuidances>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the pending_guidances_full field of the given VM.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.10.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.UpdateGuidances> getPendingGuidancesFull(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_pending_guidances_full";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.UpdateGuidances>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the groups field of the given VM.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VMGroup> getGroups(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_groups";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VMGroup>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name/label field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param label New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, label };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name/description field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param description New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameDescription(Connection c, String description) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, description };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the user_version field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param userVersion New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setUserVersion(Connection c, Long userVersion) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_user_version";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, userVersion };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the is_a_template field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param isATemplate New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setIsATemplate(Connection c, Boolean isATemplate) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_is_a_template";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, isATemplate };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the affinity field of the given VM.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param affinity New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setAffinity(Connection c, Host affinity) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_affinity";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, affinity };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the VCPUs/params field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param params New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setVCPUsParams(Connection c, Map<String, String> params) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_VCPUs_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, params };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the VCPUs/params field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToVCPUsParams(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.add_to_VCPUs_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the VCPUs/params field of the given VM.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromVCPUsParams(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.remove_from_VCPUs_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the actions/after_softreboot field of the given VM.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 23.1.0.
     *
     * @param c The connection the call is made on
     * @param afterSoftreboot New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setActionsAfterSoftreboot(Connection c, Types.OnSoftrebootBehavior afterSoftreboot) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_actions_after_softreboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, afterSoftreboot };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the actions/after_shutdown field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param afterShutdown New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setActionsAfterShutdown(Connection c, Types.OnNormalExit afterShutdown) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_actions_after_shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, afterShutdown };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the actions/after_reboot field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param afterReboot New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setActionsAfterReboot(Connection c, Types.OnNormalExit afterReboot) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_actions_after_reboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, afterReboot };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the PV/bootloader field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param bootloader New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setPVBootloader(Connection c, String bootloader) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_PV_bootloader";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, bootloader };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the PV/kernel field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param kernel New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setPVKernel(Connection c, String kernel) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_PV_kernel";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, kernel };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the PV/ramdisk field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param ramdisk New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setPVRamdisk(Connection c, String ramdisk) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_PV_ramdisk";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, ramdisk };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the PV/args field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param args New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setPVArgs(Connection c, String args) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_PV_args";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, args };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the PV/bootloader_args field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param bootloaderArgs New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setPVBootloaderArgs(Connection c, String bootloaderArgs) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_PV_bootloader_args";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, bootloaderArgs };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the PV/legacy_args field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param legacyArgs New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setPVLegacyArgs(Connection c, String legacyArgs) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_PV_legacy_args";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, legacyArgs };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the HVM/boot_params field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param bootParams New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHVMBootParams(Connection c, Map<String, String> bootParams) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_HVM_boot_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, bootParams };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the HVM/boot_params field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToHVMBootParams(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.add_to_HVM_boot_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the HVM/boot_params field of the given VM.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromHVMBootParams(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.remove_from_HVM_boot_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the platform field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param platform New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setPlatform(Connection c, Map<String, String> platform) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_platform";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, platform };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the platform field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToPlatform(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.add_to_platform";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the platform field of the given VM.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromPlatform(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.remove_from_platform";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the PCI_bus field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     * @deprecated since XenServer 6.0
     *
     * @param c The connection the call is made on
     * @param PCIBus New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.0")
    public void setPCIBus(Connection c, String PCIBus) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_PCI_bus";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, PCIBus };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the other_config field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given VM.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the recommendations field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param recommendations New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setRecommendations(Connection c, String recommendations) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_recommendations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, recommendations };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the xenstore_data field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param xenstoreData New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setXenstoreData(Connection c, Map<String, String> xenstoreData) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_xenstore_data";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, xenstoreData };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the xenstore_data field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToXenstoreData(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.add_to_xenstore_data";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the xenstore_data field of the given VM.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromXenstoreData(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.remove_from_xenstore_data";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the tags field of the given VM.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param tags New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setTags(Connection c, Set<String> tags) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, tags };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given value to the tags field of the given VM.  If the value is already in that Set, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value New value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addTags(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.add_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given value from the tags field of the given VM.  If the value is not in that Set, then do nothing.
     * Minimum allowed role: vm-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value Value to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeTags(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.remove_tags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the suspend_SR field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param suspendSR New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSuspendSR(Connection c, SR suspendSR) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_suspend_SR";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, suspendSR };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the hardware_platform_version field of the given VM.
     * Minimum allowed role: vm-admin
     * First published in XenServer 6.5 SP1.
     *
     * @param c The connection the call is made on
     * @param hardwarePlatformVersion New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHardwarePlatformVersion(Connection c, Long hardwarePlatformVersion) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_hardware_platform_version";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, hardwarePlatformVersion };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Snapshots the specified VM, making a new VM. Snapshot automatically exploits the capabilities of the underlying storage repository in which the VM's disk images are stored (e.g. Copy on Write).
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param newName The name of the snapshotted VM 
     * @return The reference of the newly created VM.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     */
    public VM snapshot(Connection c, String newName) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed {
        String methodCall = "VM.snapshot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, newName };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Snapshots the specified VM, making a new VM. Snapshot automatically exploits the capabilities of the underlying storage repository in which the VM's disk images are stored (e.g. Copy on Write).
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param newName The name of the snapshotted VM 
     * @param ignoreVdis A list of VDIs to ignore for the snapshot First published in 21.4.0.
     * @return The reference of the newly created VM.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     */
    public VM snapshot(Connection c, String newName, Set<VDI> ignoreVdis) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed {
        String methodCall = "VM.snapshot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, newName, ignoreVdis };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Snapshots the specified VM, making a new VM. Snapshot automatically exploits the capabilities of the underlying storage repository in which the VM's disk images are stored (e.g. Copy on Write).
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param newName The name of the snapshotted VM 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     */
    public Task snapshotAsync(Connection c, String newName) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed {
        String methodCall = "Async.VM.snapshot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, newName };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Snapshots the specified VM, making a new VM. Snapshot automatically exploits the capabilities of the underlying storage repository in which the VM's disk images are stored (e.g. Copy on Write).
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param newName The name of the snapshotted VM 
     * @param ignoreVdis A list of VDIs to ignore for the snapshot First published in 21.4.0.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     */
    public Task snapshotAsync(Connection c, String newName, Set<VDI> ignoreVdis) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed {
        String methodCall = "Async.VM.snapshot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, newName, ignoreVdis };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Snapshots the specified VM with quiesce, making a new VM. Snapshot automatically exploits the capabilities of the underlying storage repository in which the VM's disk images are stored (e.g. Copy on Write).
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.0.
     * @deprecated since Citrix Hypervisor 8.1
     *
     * @param c The connection the call is made on
     * @param newName The name of the snapshotted VM 
     * @return The reference of the newly created VM.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmSnapshotWithQuiesceFailed The quiesced-snapshot operation failed for an unexpected reason
     * @throws Types.VmSnapshotWithQuiesceTimeout The VSS plug-in has timed out
     * @throws Types.VmSnapshotWithQuiescePluginDeosNotRespond The VSS plug-in cannot be contacted
     * @throws Types.VmSnapshotWithQuiesceNotSupported The VSS plug-in is not installed on this virtual machine
     */
    @Deprecated(since = "Citrix Hypervisor 8.1")
    public VM snapshotWithQuiesce(Connection c, String newName) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed,
    Types.VmSnapshotWithQuiesceFailed,
    Types.VmSnapshotWithQuiesceTimeout,
    Types.VmSnapshotWithQuiescePluginDeosNotRespond,
    Types.VmSnapshotWithQuiesceNotSupported {
        String methodCall = "VM.snapshot_with_quiesce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, newName };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Snapshots the specified VM with quiesce, making a new VM. Snapshot automatically exploits the capabilities of the underlying storage repository in which the VM's disk images are stored (e.g. Copy on Write).
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.0.
     * @deprecated since Citrix Hypervisor 8.1
     *
     * @param c The connection the call is made on
     * @param newName The name of the snapshotted VM 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmSnapshotWithQuiesceFailed The quiesced-snapshot operation failed for an unexpected reason
     * @throws Types.VmSnapshotWithQuiesceTimeout The VSS plug-in has timed out
     * @throws Types.VmSnapshotWithQuiescePluginDeosNotRespond The VSS plug-in cannot be contacted
     * @throws Types.VmSnapshotWithQuiesceNotSupported The VSS plug-in is not installed on this virtual machine
     */
    @Deprecated(since = "Citrix Hypervisor 8.1")
    public Task snapshotWithQuiesceAsync(Connection c, String newName) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed,
    Types.VmSnapshotWithQuiesceFailed,
    Types.VmSnapshotWithQuiesceTimeout,
    Types.VmSnapshotWithQuiescePluginDeosNotRespond,
    Types.VmSnapshotWithQuiesceNotSupported {
        String methodCall = "Async.VM.snapshot_with_quiesce";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, newName };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Clones the specified VM, making a new VM. Clone automatically exploits the capabilities of the underlying storage repository in which the VM's disk images are stored (e.g. Copy on Write).   This function can only be called when the VM is in the Halted State.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param newName The name of the cloned VM 
     * @return The reference of the newly created VM.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public VM createClone(Connection c, String newName) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed,
    Types.LicenceRestriction {
        String methodCall = "VM.clone";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, newName };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Clones the specified VM, making a new VM. Clone automatically exploits the capabilities of the underlying storage repository in which the VM's disk images are stored (e.g. Copy on Write).   This function can only be called when the VM is in the Halted State.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param newName The name of the cloned VM 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public Task createCloneAsync(Connection c, String newName) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed,
    Types.LicenceRestriction {
        String methodCall = "Async.VM.clone";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, newName };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Copied the specified VM, making a new VM. Unlike clone, copy does not exploits the capabilities of the underlying storage repository in which the VM's disk images are stored. Instead, copy guarantees that the disk images of the newly created VM will be 'full disks' - i.e. not part of a CoW chain.  This function can only be called when the VM is in the Halted State.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param newName The name of the copied VM 
     * @param sr An SR to copy all the VM's disks into (if an invalid reference then it uses the existing SRs) 
     * @return The reference of the newly created VM.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public VM copy(Connection c, String newName, SR sr) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed,
    Types.LicenceRestriction {
        String methodCall = "VM.copy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, newName, sr };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Copied the specified VM, making a new VM. Unlike clone, copy does not exploits the capabilities of the underlying storage repository in which the VM's disk images are stored. Instead, copy guarantees that the disk images of the newly created VM will be 'full disks' - i.e. not part of a CoW chain.  This function can only be called when the VM is in the Halted State.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param newName The name of the copied VM 
     * @param sr An SR to copy all the VM's disks into (if an invalid reference then it uses the existing SRs) 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public Task copyAsync(Connection c, String newName, SR sr) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed,
    Types.LicenceRestriction {
        String methodCall = "Async.VM.copy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, newName, sr };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Reverts the specified VM to a previous state.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.VmRevertFailed An error occured while reverting the specified virtual machine to the specified snapshot
     */
    public void revert(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OperationNotAllowed,
    Types.SrFull,
    Types.VmRevertFailed {
        String methodCall = "VM.revert";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Reverts the specified VM to a previous state.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.VmRevertFailed An error occured while reverting the specified virtual machine to the specified snapshot
     */
    public Task revertAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OperationNotAllowed,
    Types.SrFull,
    Types.VmRevertFailed {
        String methodCall = "Async.VM.revert";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Checkpoints the specified VM, making a new VM. Checkpoint automatically exploits the capabilities of the underlying storage repository in which the VM's disk images are stored (e.g. Copy on Write) and saves the memory image as well.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param newName The name of the checkpointed VM 
     * @return The reference of the newly created VM.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmCheckpointSuspendFailed An error occured while saving the memory image of the specified virtual machine
     * @throws Types.VmCheckpointResumeFailed An error occured while restoring the memory image of the specified virtual machine
     */
    public VM checkpoint(Connection c, String newName) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed,
    Types.VmCheckpointSuspendFailed,
    Types.VmCheckpointResumeFailed {
        String methodCall = "VM.checkpoint";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, newName };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Checkpoints the specified VM, making a new VM. Checkpoint automatically exploits the capabilities of the underlying storage repository in which the VM's disk images are stored (e.g. Copy on Write) and saves the memory image as well.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param newName The name of the checkpointed VM 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmCheckpointSuspendFailed An error occured while saving the memory image of the specified virtual machine
     * @throws Types.VmCheckpointResumeFailed An error occured while restoring the memory image of the specified virtual machine
     */
    public Task checkpointAsync(Connection c, String newName) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed,
    Types.VmCheckpointSuspendFailed,
    Types.VmCheckpointResumeFailed {
        String methodCall = "Async.VM.checkpoint";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, newName };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Inspects the disk configuration contained within the VM's other_config, creates VDIs and VBDs and then executes any applicable post-install script.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public void provision(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed,
    Types.LicenceRestriction {
        String methodCall = "VM.provision";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Inspects the disk configuration contained within the VM's other_config, creates VDIs and VBDs and then executes any applicable post-install script.
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.SrFull The SR is full. Requested new size exceeds the maximum size
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public Task provisionAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.SrFull,
    Types.OperationNotAllowed,
    Types.LicenceRestriction {
        String methodCall = "Async.VM.provision";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Start the specified VM.  This function can only be called with the VM is in the Halted State.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param startPaused Instantiate VM in paused state if set to true. 
     * @param force Attempt to force the VM to start. If this flag is false then the VM may fail pre-boot safety checks (e.g. if the CPU the VM last booted on looks substantially different to the current one) 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.VmHvmRequired HVM is required for this operation
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.BootloaderFailed The bootloader returned an error
     * @throws Types.UnknownBootloader The requested bootloader is unknown
     * @throws Types.NoHostsAvailable There were no servers available to complete the specified operation.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public void start(Connection c, Boolean startPaused, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.VmHvmRequired,
    Types.VmIsTemplate,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.BootloaderFailed,
    Types.UnknownBootloader,
    Types.NoHostsAvailable,
    Types.LicenceRestriction {
        String methodCall = "VM.start";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, startPaused, force };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Start the specified VM.  This function can only be called with the VM is in the Halted State.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param startPaused Instantiate VM in paused state if set to true. 
     * @param force Attempt to force the VM to start. If this flag is false then the VM may fail pre-boot safety checks (e.g. if the CPU the VM last booted on looks substantially different to the current one) 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.VmHvmRequired HVM is required for this operation
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.BootloaderFailed The bootloader returned an error
     * @throws Types.UnknownBootloader The requested bootloader is unknown
     * @throws Types.NoHostsAvailable There were no servers available to complete the specified operation.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public Task startAsync(Connection c, Boolean startPaused, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.VmHvmRequired,
    Types.VmIsTemplate,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.BootloaderFailed,
    Types.UnknownBootloader,
    Types.NoHostsAvailable,
    Types.LicenceRestriction {
        String methodCall = "Async.VM.start";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, startPaused, force };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Start the specified VM on a particular host.  This function can only be called with the VM is in the Halted State.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The Host on which to start the VM 
     * @param startPaused Instantiate VM in paused state if set to true. 
     * @param force Attempt to force the VM to start. If this flag is false then the VM may fail pre-boot safety checks (e.g. if the CPU the VM last booted on looks substantially different to the current one) 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.BootloaderFailed The bootloader returned an error
     * @throws Types.UnknownBootloader The requested bootloader is unknown
     */
    public void startOn(Connection c, Host host, Boolean startPaused, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.VmIsTemplate,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.BootloaderFailed,
    Types.UnknownBootloader {
        String methodCall = "VM.start_on";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host, startPaused, force };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Start the specified VM on a particular host.  This function can only be called with the VM is in the Halted State.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The Host on which to start the VM 
     * @param startPaused Instantiate VM in paused state if set to true. 
     * @param force Attempt to force the VM to start. If this flag is false then the VM may fail pre-boot safety checks (e.g. if the CPU the VM last booted on looks substantially different to the current one) 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.BootloaderFailed The bootloader returned an error
     * @throws Types.UnknownBootloader The requested bootloader is unknown
     */
    public Task startOnAsync(Connection c, Host host, Boolean startPaused, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.VmIsTemplate,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.BootloaderFailed,
    Types.UnknownBootloader {
        String methodCall = "Async.VM.start_on";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host, startPaused, force };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Pause the specified VM. This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public void pause(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "VM.pause";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Pause the specified VM. This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public Task pauseAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "Async.VM.pause";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Resume the specified VM. This can only be called when the specified VM is in the Paused state.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public void unpause(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "VM.unpause";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Resume the specified VM. This can only be called when the specified VM is in the Paused state.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public Task unpauseAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "Async.VM.unpause";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Attempt to cleanly shutdown the specified VM. (Note: this may not be supported---e.g. if a guest agent is not installed). This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public void cleanShutdown(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "VM.clean_shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Attempt to cleanly shutdown the specified VM. (Note: this may not be supported---e.g. if a guest agent is not installed). This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public Task cleanShutdownAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "Async.VM.clean_shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Attempts to first clean shutdown a VM and if it should fail then perform a hard shutdown on it.
     * Minimum allowed role: vm-operator
     * First published in XenServer 6.2.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public void shutdown(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "VM.shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Attempts to first clean shutdown a VM and if it should fail then perform a hard shutdown on it.
     * Minimum allowed role: vm-operator
     * First published in XenServer 6.2.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public Task shutdownAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "Async.VM.shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Attempt to cleanly shutdown the specified VM (Note: this may not be supported---e.g. if a guest agent is not installed). This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public void cleanReboot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "VM.clean_reboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Attempt to cleanly shutdown the specified VM (Note: this may not be supported---e.g. if a guest agent is not installed). This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public Task cleanRebootAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "Async.VM.clean_reboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Stop executing the specified VM without attempting a clean shutdown.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public void hardShutdown(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "VM.hard_shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Stop executing the specified VM without attempting a clean shutdown.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public Task hardShutdownAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "Async.VM.hard_shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Reset the power-state of the VM to halted in the database only. (Used to recover from slave failures in pooling scenarios by resetting the power-states of VMs running on dead slaves to halted.) This is a potentially dangerous operation; use with care.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void powerStateReset(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.power_state_reset";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Reset the power-state of the VM to halted in the database only. (Used to recover from slave failures in pooling scenarios by resetting the power-states of VMs running on dead slaves to halted.) This is a potentially dangerous operation; use with care.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task powerStateResetAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.power_state_reset";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Stop executing the specified VM without attempting a clean shutdown and immediately restart the VM.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public void hardReboot(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "VM.hard_reboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Stop executing the specified VM without attempting a clean shutdown and immediately restart the VM.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public Task hardRebootAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "Async.VM.hard_reboot";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Suspend the specified VM to disk.  This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public void suspend(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "VM.suspend";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Suspend the specified VM to disk.  This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public Task suspendAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "Async.VM.suspend";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Awaken the specified VM and resume it.  This can only be called when the specified VM is in the Suspended state.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param startPaused Resume VM in paused state if set to true. 
     * @param force Attempt to force the VM to resume. If this flag is false then the VM may fail pre-resume safety checks (e.g. if the CPU the VM was running on looks substantially different to the current one) 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public void resume(Connection c, Boolean startPaused, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "VM.resume";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, startPaused, force };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Awaken the specified VM and resume it.  This can only be called when the specified VM is in the Suspended state.
     * Minimum allowed role: vm-operator
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param startPaused Resume VM in paused state if set to true. 
     * @param force Attempt to force the VM to resume. If this flag is false then the VM may fail pre-resume safety checks (e.g. if the CPU the VM was running on looks substantially different to the current one) 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public Task resumeAsync(Connection c, Boolean startPaused, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "Async.VM.resume";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, startPaused, force };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Awaken the specified VM and resume it on a particular Host.  This can only be called when the specified VM is in the Suspended state.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The Host on which to resume the VM 
     * @param startPaused Resume VM in paused state if set to true. 
     * @param force Attempt to force the VM to resume. If this flag is false then the VM may fail pre-resume safety checks (e.g. if the CPU the VM was running on looks substantially different to the current one) 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public void resumeOn(Connection c, Host host, Boolean startPaused, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "VM.resume_on";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host, startPaused, force };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Awaken the specified VM and resume it on a particular Host.  This can only be called when the specified VM is in the Suspended state.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The Host on which to resume the VM 
     * @param startPaused Resume VM in paused state if set to true. 
     * @param force Attempt to force the VM to resume. If this flag is false then the VM may fail pre-resume safety checks (e.g. if the CPU the VM was running on looks substantially different to the current one) 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     */
    public Task resumeOnAsync(Connection c, Host host, Boolean startPaused, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OperationNotAllowed,
    Types.VmIsTemplate {
        String methodCall = "Async.VM.resume_on";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host, startPaused, force };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Migrate a VM to another Host.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The target host 
     * @param options Extra configuration operations: force, live, copy, compress. Each is a boolean option, taking 'true' or 'false' as a value. Option 'compress' controls the use of stream compression during migration. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     */
    public void poolMigrate(Connection c, Host host, Map<String, String> options) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.VmIsTemplate,
    Types.OperationNotAllowed,
    Types.VmBadPowerState {
        String methodCall = "VM.pool_migrate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host, options };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Migrate a VM to another Host.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The target host 
     * @param options Extra configuration operations: force, live, copy, compress. Each is a boolean option, taking 'true' or 'false' as a value. Option 'compress' controls the use of stream compression during migration. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     */
    public Task poolMigrateAsync(Connection c, Host host, Map<String, String> options) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.VmIsTemplate,
    Types.OperationNotAllowed,
    Types.VmBadPowerState {
        String methodCall = "Async.VM.pool_migrate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host, options };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the number of VCPUs for a running VM
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param nvcpu The number of VCPUs 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public void setVCPUsNumberLive(Connection c, Long nvcpu) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OperationNotAllowed,
    Types.LicenceRestriction {
        String methodCall = "VM.set_VCPUs_number_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, nvcpu };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the number of VCPUs for a running VM
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param nvcpu The number of VCPUs 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public Task setVCPUsNumberLiveAsync(Connection c, Long nvcpu) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OperationNotAllowed,
    Types.LicenceRestriction {
        String methodCall = "Async.VM.set_VCPUs_number_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, nvcpu };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Add the given key-value pair to VM.VCPUs_params, and apply that value on the running VM
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key The key 
     * @param value The value 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToVCPUsParamsLive(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.add_to_VCPUs_params_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to VM.VCPUs_params, and apply that value on the running VM
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key The key 
     * @param value The value 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task addToVCPUsParamsLiveAsync(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.add_to_VCPUs_params_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: vm-admin
     * First published in Citrix Hypervisor 8.0.
     *
     * @param c The connection the call is made on
     * @param value The value 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNVRAM(Connection c, Map<String, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_NVRAM";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: vm-admin
     * First published in Citrix Hypervisor 8.0.
     *
     * @param c The connection the call is made on
     * @param key The key 
     * @param value The value 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToNVRAM(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.add_to_NVRAM";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: vm-admin
     * First published in Citrix Hypervisor 8.0.
     *
     * @param c The connection the call is made on
     * @param key The key 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromNVRAM(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.remove_from_NVRAM";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the value of the ha_restart_priority field
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value The value 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHaRestartPriority(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_ha_restart_priority";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the value of the ha_always_run
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     * @deprecated since XenServer 6.0
     *
     * @param c The connection the call is made on
     * @param value The value 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.0")
    public void setHaAlwaysRun(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_ha_always_run";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Computes the virtualization memory overhead of a VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return the virtualization memory overhead of the VM.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long computeMemoryOverhead(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.compute_memory_overhead";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Computes the virtualization memory overhead of a VM.
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task computeMemoryOverheadAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.compute_memory_overhead";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the value of the memory_dynamic_max field
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param value The new value of memory_dynamic_max 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setMemoryDynamicMax(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_memory_dynamic_max";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the value of the memory_dynamic_min field
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param value The new value of memory_dynamic_min 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setMemoryDynamicMin(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_memory_dynamic_min";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the minimum and maximum amounts of physical memory the VM is allowed to use.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param min The new minimum value 
     * @param max The new maximum value 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setMemoryDynamicRange(Connection c, Long min, Long max) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_memory_dynamic_range";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, min, max };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the minimum and maximum amounts of physical memory the VM is allowed to use.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param min The new minimum value 
     * @param max The new maximum value 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setMemoryDynamicRangeAsync(Connection c, Long min, Long max) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_memory_dynamic_range";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, min, max };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the value of the memory_static_max field
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value The new value of memory_static_max 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.HaOperationWouldBreakFailoverPlan This operation cannot be performed because it would invalidate VM failover planning such that the system would be unable to guarantee to restart protected VMs after a Host failure.
     */
    public void setMemoryStaticMax(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.HaOperationWouldBreakFailoverPlan {
        String methodCall = "VM.set_memory_static_max";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the value of the memory_static_min field
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param value The new value of memory_static_min 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setMemoryStaticMin(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_memory_static_min";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the static (ie boot-time) range of virtual memory that the VM is allowed to use.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param min The new minimum value 
     * @param max The new maximum value 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setMemoryStaticRange(Connection c, Long min, Long max) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_memory_static_range";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, min, max };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the static (ie boot-time) range of virtual memory that the VM is allowed to use.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param min The new minimum value 
     * @param max The new maximum value 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setMemoryStaticRangeAsync(Connection c, Long min, Long max) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_memory_static_range";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, min, max };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the memory limits of this VM.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param staticMin The new value of memory_static_min. 
     * @param staticMax The new value of memory_static_max. 
     * @param dynamicMin The new value of memory_dynamic_min. 
     * @param dynamicMax The new value of memory_dynamic_max. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setMemoryLimits(Connection c, Long staticMin, Long staticMax, Long dynamicMin, Long dynamicMax) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_memory_limits";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, staticMin, staticMax, dynamicMin, dynamicMax };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the memory limits of this VM.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param staticMin The new value of memory_static_min. 
     * @param staticMax The new value of memory_static_max. 
     * @param dynamicMin The new value of memory_dynamic_min. 
     * @param dynamicMax The new value of memory_dynamic_max. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setMemoryLimitsAsync(Connection c, Long staticMin, Long staticMax, Long dynamicMin, Long dynamicMax) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_memory_limits";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, staticMin, staticMax, dynamicMin, dynamicMax };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the memory allocation of this VM. Sets all of memory_static_max, memory_dynamic_min, and memory_dynamic_max to the given value, and leaves memory_static_min untouched.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param value The new memory allocation (bytes). 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setMemory(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_memory";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the memory allocation of this VM. Sets all of memory_static_max, memory_dynamic_min, and memory_dynamic_max to the given value, and leaves memory_static_min untouched.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @param value The new memory allocation (bytes). 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setMemoryAsync(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_memory";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the memory target for a running VM
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     * @deprecated since XenServer 5.6
     *
     * @param c The connection the call is made on
     * @param target The target in bytes 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 5.6")
    public void setMemoryTargetLive(Connection c, Long target) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_memory_target_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, target };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the memory target for a running VM
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     * @deprecated since XenServer 5.6
     *
     * @param c The connection the call is made on
     * @param target The target in bytes 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 5.6")
    public Task setMemoryTargetLiveAsync(Connection c, Long target) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_memory_target_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, target };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Wait for a running VM to reach its current memory target
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     * @deprecated since XenServer 5.6
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 5.6")
    public void waitMemoryTargetLive(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.wait_memory_target_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Wait for a running VM to reach its current memory target
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     * @deprecated since XenServer 5.6
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 5.6")
    public Task waitMemoryTargetLiveAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.wait_memory_target_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return true if the VM is currently 'co-operative' i.e. is expected to reach a balloon target and actually has done
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     * @deprecated since XenServer 6.1
     *
     * @param c The connection the call is made on
     * @return true if the VM is currently 'co-operative'; false otherwise
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.1")
    public Boolean getCooperative(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_cooperative";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return true if the VM is currently 'co-operative' i.e. is expected to reach a balloon target and actually has done
     * Minimum allowed role: read-only
     * First published in XenServer 5.6.
     * @deprecated since XenServer 6.1
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.1")
    public Task getCooperativeAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.get_cooperative";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the shadow memory multiplier on a halted VM
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param value The new shadow memory multiplier to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHVMShadowMultiplier(Connection c, Double value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_HVM_shadow_multiplier";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the shadow memory multiplier on a running VM
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param multiplier The new shadow memory multiplier to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setShadowMultiplierLive(Connection c, Double multiplier) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_shadow_multiplier_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, multiplier };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the shadow memory multiplier on a running VM
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param multiplier The new shadow memory multiplier to set 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setShadowMultiplierLiveAsync(Connection c, Double multiplier) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_shadow_multiplier_live";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, multiplier };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the maximum number of VCPUs for a halted VM
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param value The new maximum number of VCPUs 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setVCPUsMax(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_VCPUs_max";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the number of startup VCPUs for a halted VM
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param value The new maximum number of VCPUs 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setVCPUsAtStartup(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_VCPUs_at_startup";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Send the given key as a sysrq to this VM.  The key is specified as a single character (a String of length 1).  This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key The key to send 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     */
    public void sendSysrq(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState {
        String methodCall = "VM.send_sysrq";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Send the given key as a sysrq to this VM.  The key is specified as a single character (a String of length 1).  This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param key The key to send 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     */
    public Task sendSysrqAsync(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState {
        String methodCall = "Async.VM.send_sysrq";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Send the named trigger to this VM.  This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param trigger The trigger to send 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     */
    public void sendTrigger(Connection c, String trigger) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState {
        String methodCall = "VM.send_trigger";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, trigger };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Send the named trigger to this VM.  This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param trigger The trigger to send 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     */
    public Task sendTriggerAsync(Connection c, String trigger) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState {
        String methodCall = "Async.VM.send_trigger";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, trigger };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns the maximum amount of guest memory which will fit, together with overheads, in the supplied amount of physical memory. If 'exact' is true then an exact calculation is performed using the VM's current settings. If 'exact' is false then a more conservative approximation is used
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param total Total amount of physical RAM to fit within 
     * @param approximate If false the limit is calculated with the guest's current exact configuration. Otherwise a more approximate calculation is performed 
     * @return The maximum possible static-max
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long maximiseMemory(Connection c, Long total, Boolean approximate) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.maximise_memory";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, total, approximate };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns the maximum amount of guest memory which will fit, together with overheads, in the supplied amount of physical memory. If 'exact' is true then an exact calculation is performed using the VM's current settings. If 'exact' is false then a more conservative approximation is used
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param total Total amount of physical RAM to fit within 
     * @param approximate If false the limit is calculated with the guest's current exact configuration. Otherwise a more approximate calculation is performed 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task maximiseMemoryAsync(Connection c, Long total, Boolean approximate) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.maximise_memory";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, total, approximate };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Migrate the VM to another host.  This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param dest The result of a Host.migrate_receive call. 
     * @param live Live migration 
     * @param vdiMap Map of source VDI to destination SR 
     * @param vifMap Map of source VIF to destination network 
     * @param options Other parameters 
     * @return The reference of the newly created VM in the destination pool
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public VM migrateSend(Connection c, Map<String, String> dest, Boolean live, Map<VDI, SR> vdiMap, Map<VIF, Network> vifMap, Map<String, String> options) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.LicenceRestriction {
        String methodCall = "VM.migrate_send";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dest, live, vdiMap, vifMap, options };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Migrate the VM to another host.  This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param dest The result of a Host.migrate_receive call. 
     * @param live Live migration 
     * @param vdiMap Map of source VDI to destination SR 
     * @param vifMap Map of source VIF to destination network 
     * @param options Other parameters 
     * @param vgpuMap Map of source vGPU to destination GPU group First published in XenServer 7.3.
     * @return The reference of the newly created VM in the destination pool
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public VM migrateSend(Connection c, Map<String, String> dest, Boolean live, Map<VDI, SR> vdiMap, Map<VIF, Network> vifMap, Map<String, String> options, Map<VGPU, GPUGroup> vgpuMap) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.LicenceRestriction {
        String methodCall = "VM.migrate_send";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dest, live, vdiMap, vifMap, options, vgpuMap };
        var typeReference = new TypeReference<VM>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Migrate the VM to another host.  This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param dest The result of a Host.migrate_receive call. 
     * @param live Live migration 
     * @param vdiMap Map of source VDI to destination SR 
     * @param vifMap Map of source VIF to destination network 
     * @param options Other parameters 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public Task migrateSendAsync(Connection c, Map<String, String> dest, Boolean live, Map<VDI, SR> vdiMap, Map<VIF, Network> vifMap, Map<String, String> options) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.LicenceRestriction {
        String methodCall = "Async.VM.migrate_send";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dest, live, vdiMap, vifMap, options };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Migrate the VM to another host.  This can only be called when the specified VM is in the Running state.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param dest The result of a Host.migrate_receive call. 
     * @param live Live migration 
     * @param vdiMap Map of source VDI to destination SR 
     * @param vifMap Map of source VIF to destination network 
     * @param options Other parameters 
     * @param vgpuMap Map of source vGPU to destination GPU group First published in XenServer 7.3.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public Task migrateSendAsync(Connection c, Map<String, String> dest, Boolean live, Map<VDI, SR> vdiMap, Map<VIF, Network> vifMap, Map<String, String> options, Map<VGPU, GPUGroup> vgpuMap) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.LicenceRestriction {
        String methodCall = "Async.VM.migrate_send";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dest, live, vdiMap, vifMap, options, vgpuMap };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Assert whether a VM can be migrated to the specified destination.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param dest The result of a VM.migrate_receive call. 
     * @param live Live migration 
     * @param vdiMap Map of source VDI to destination SR 
     * @param vifMap Map of source VIF to destination network 
     * @param options Other parameters 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public void assertCanMigrate(Connection c, Map<String, String> dest, Boolean live, Map<VDI, SR> vdiMap, Map<VIF, Network> vifMap, Map<String, String> options) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.LicenceRestriction {
        String methodCall = "VM.assert_can_migrate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dest, live, vdiMap, vifMap, options };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Assert whether a VM can be migrated to the specified destination.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param dest The result of a VM.migrate_receive call. 
     * @param live Live migration 
     * @param vdiMap Map of source VDI to destination SR 
     * @param vifMap Map of source VIF to destination network 
     * @param options Other parameters 
     * @param vgpuMap Map of source vGPU to destination GPU group First published in XenServer 7.3.
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public void assertCanMigrate(Connection c, Map<String, String> dest, Boolean live, Map<VDI, SR> vdiMap, Map<VIF, Network> vifMap, Map<String, String> options, Map<VGPU, GPUGroup> vgpuMap) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.LicenceRestriction {
        String methodCall = "VM.assert_can_migrate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dest, live, vdiMap, vifMap, options, vgpuMap };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Assert whether a VM can be migrated to the specified destination.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param dest The result of a VM.migrate_receive call. 
     * @param live Live migration 
     * @param vdiMap Map of source VDI to destination SR 
     * @param vifMap Map of source VIF to destination network 
     * @param options Other parameters 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public Task assertCanMigrateAsync(Connection c, Map<String, String> dest, Boolean live, Map<VDI, SR> vdiMap, Map<VIF, Network> vifMap, Map<String, String> options) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.LicenceRestriction {
        String methodCall = "Async.VM.assert_can_migrate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dest, live, vdiMap, vifMap, options };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Assert whether a VM can be migrated to the specified destination.
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param dest The result of a VM.migrate_receive call. 
     * @param live Live migration 
     * @param vdiMap Map of source VDI to destination SR 
     * @param vifMap Map of source VIF to destination network 
     * @param options Other parameters 
     * @param vgpuMap Map of source vGPU to destination GPU group First published in XenServer 7.3.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.LicenceRestriction This operation is not allowed because your license lacks a needed feature. Please contact your support representative.
     */
    public Task assertCanMigrateAsync(Connection c, Map<String, String> dest, Boolean live, Map<VDI, SR> vdiMap, Map<VIF, Network> vifMap, Map<String, String> options, Map<VGPU, GPUGroup> vgpuMap) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.LicenceRestriction {
        String methodCall = "Async.VM.assert_can_migrate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dest, live, vdiMap, vifMap, options, vgpuMap };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns a record describing the VM's dynamic state, initialised when the VM boots and updated to reflect runtime configuration changes e.g. CPU hotplug
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 7.3
     *
     * @param c The connection the call is made on
     * @return A record describing the VM
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.3")
    public VM.Record getBootRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_boot_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VM.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return A set of data sources
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<DataSource.Record> getDataSources(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_data_sources";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<DataSource.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Start recording the specified data source
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param dataSource The data source to record 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void recordDataSource(Connection c, String dataSource) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.record_data_source";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dataSource };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Query the latest value of the specified data source
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param dataSource The data source to query 
     * @return The latest value, averaged over the last 5 seconds
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Double queryDataSource(Connection c, String dataSource) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.query_data_source";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dataSource };
        var typeReference = new TypeReference<Double>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Forget the recorded statistics related to the specified data source
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param dataSource The data source whose archives are to be forgotten 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void forgetDataSourceArchives(Connection c, String dataSource) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.forget_data_source_archives";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, dataSource };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Check to see whether this operation is acceptable in the current state of the system, raising an error if the operation is invalid for some reason
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param op proposed operation 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void assertOperationValid(Connection c, Types.VmOperations op) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.assert_operation_valid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, op };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Check to see whether this operation is acceptable in the current state of the system, raising an error if the operation is invalid for some reason
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param op proposed operation 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task assertOperationValidAsync(Connection c, Types.VmOperations op) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.assert_operation_valid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, op };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Recomputes the list of acceptable operations
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void updateAllowedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.update_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Recomputes the list of acceptable operations
     * Minimum allowed role: pool-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task updateAllowedOperationsAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.update_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns a list of the allowed values that a VBD device field can take
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return The allowed values
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getAllowedVBDDevices(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_allowed_VBD_devices";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns a list of the allowed values that a VIF device field can take
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return The allowed values
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getAllowedVIFDevices(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_allowed_VIF_devices";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return the list of hosts on which this VM may run.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return The possible hosts
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Host> getPossibleHosts(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_possible_hosts";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Host>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return the list of hosts on which this VM may run.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getPossibleHostsAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.get_possible_hosts";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns an error if the VM could not boot on this host for some reason
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The host 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.HostNotEnoughFreeMemory Not enough server memory is available to perform this operation.
     * @throws Types.HostNotEnoughPcpus The host does not have enough pCPUs to run the VM. It needs at least as many as the VM has vCPUs.
     * @throws Types.NetworkSriovInsufficientCapacity There is insufficient capacity for VF reservation
     * @throws Types.HostNotLive This operation cannot be completed as the server is not live.
     * @throws Types.HostDisabled The specified server is disabled.
     * @throws Types.HostCannotAttachNetwork Server cannot attach network (in the case of NIC bonding, this may be because attaching the network on this server would require other networks - that are currently active - to be taken down).
     * @throws Types.VmHvmRequired HVM is required for this operation
     * @throws Types.VmRequiresGpu You attempted to run a VM on a host which doesn't have a pGPU available in the GPU group needed by the VM. The VM has a vGPU attached to this GPU group.
     * @throws Types.VmRequiresIommu You attempted to run a VM on a host which doesn't have I/O virtualization (IOMMU/VT-d) enabled, which is needed by the VM.
     * @throws Types.VmRequiresNetwork You attempted to run a VM on a host which doesn't have a PIF on a Network needed by the VM. The VM has at least one VIF attached to the Network.
     * @throws Types.VmRequiresSr You attempted to run a VM on a host which doesn't have access to an SR needed by the VM. The VM has at least one VBD attached to a VDI in the SR.
     * @throws Types.VmRequiresVgpu You attempted to run a VM on a host on which the vGPU required by the VM cannot be allocated on any pGPUs in the GPU_group needed by the VM.
     * @throws Types.VmHostIncompatibleVersion This VM operation cannot be performed on an older-versioned host during an upgrade.
     * @throws Types.VmHostIncompatibleVirtualHardwarePlatformVersion You attempted to run a VM on a host that cannot provide the VM's required Virtual Hardware Platform version.
     * @throws Types.InvalidValue The value given is invalid
     * @throws Types.MemoryConstraintViolation The dynamic memory range does not satisfy the following constraint.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.ValueNotSupported You attempted to set a value that is not supported by this implementation. The fully-qualified field name and the value that you tried to set are returned. Also returned is a developer-only diagnostic reason.
     * @throws Types.VmIncompatibleWithThisHost The VM is incompatible with the CPU features of this host.
     */
    public void assertCanBootHere(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.HostNotEnoughFreeMemory,
    Types.HostNotEnoughPcpus,
    Types.NetworkSriovInsufficientCapacity,
    Types.HostNotLive,
    Types.HostDisabled,
    Types.HostCannotAttachNetwork,
    Types.VmHvmRequired,
    Types.VmRequiresGpu,
    Types.VmRequiresIommu,
    Types.VmRequiresNetwork,
    Types.VmRequiresSr,
    Types.VmRequiresVgpu,
    Types.VmHostIncompatibleVersion,
    Types.VmHostIncompatibleVirtualHardwarePlatformVersion,
    Types.InvalidValue,
    Types.MemoryConstraintViolation,
    Types.OperationNotAllowed,
    Types.ValueNotSupported,
    Types.VmIncompatibleWithThisHost {
        String methodCall = "VM.assert_can_boot_here";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Returns an error if the VM could not boot on this host for some reason
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param host The host 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.HostNotEnoughFreeMemory Not enough server memory is available to perform this operation.
     * @throws Types.HostNotEnoughPcpus The host does not have enough pCPUs to run the VM. It needs at least as many as the VM has vCPUs.
     * @throws Types.NetworkSriovInsufficientCapacity There is insufficient capacity for VF reservation
     * @throws Types.HostNotLive This operation cannot be completed as the server is not live.
     * @throws Types.HostDisabled The specified server is disabled.
     * @throws Types.HostCannotAttachNetwork Server cannot attach network (in the case of NIC bonding, this may be because attaching the network on this server would require other networks - that are currently active - to be taken down).
     * @throws Types.VmHvmRequired HVM is required for this operation
     * @throws Types.VmRequiresGpu You attempted to run a VM on a host which doesn't have a pGPU available in the GPU group needed by the VM. The VM has a vGPU attached to this GPU group.
     * @throws Types.VmRequiresIommu You attempted to run a VM on a host which doesn't have I/O virtualization (IOMMU/VT-d) enabled, which is needed by the VM.
     * @throws Types.VmRequiresNetwork You attempted to run a VM on a host which doesn't have a PIF on a Network needed by the VM. The VM has at least one VIF attached to the Network.
     * @throws Types.VmRequiresSr You attempted to run a VM on a host which doesn't have access to an SR needed by the VM. The VM has at least one VBD attached to a VDI in the SR.
     * @throws Types.VmRequiresVgpu You attempted to run a VM on a host on which the vGPU required by the VM cannot be allocated on any pGPUs in the GPU_group needed by the VM.
     * @throws Types.VmHostIncompatibleVersion This VM operation cannot be performed on an older-versioned host during an upgrade.
     * @throws Types.VmHostIncompatibleVirtualHardwarePlatformVersion You attempted to run a VM on a host that cannot provide the VM's required Virtual Hardware Platform version.
     * @throws Types.InvalidValue The value given is invalid
     * @throws Types.MemoryConstraintViolation The dynamic memory range does not satisfy the following constraint.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.ValueNotSupported You attempted to set a value that is not supported by this implementation. The fully-qualified field name and the value that you tried to set are returned. Also returned is a developer-only diagnostic reason.
     * @throws Types.VmIncompatibleWithThisHost The VM is incompatible with the CPU features of this host.
     */
    public Task assertCanBootHereAsync(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.HostNotEnoughFreeMemory,
    Types.HostNotEnoughPcpus,
    Types.NetworkSriovInsufficientCapacity,
    Types.HostNotLive,
    Types.HostDisabled,
    Types.HostCannotAttachNetwork,
    Types.VmHvmRequired,
    Types.VmRequiresGpu,
    Types.VmRequiresIommu,
    Types.VmRequiresNetwork,
    Types.VmRequiresSr,
    Types.VmRequiresVgpu,
    Types.VmHostIncompatibleVersion,
    Types.VmHostIncompatibleVirtualHardwarePlatformVersion,
    Types.InvalidValue,
    Types.MemoryConstraintViolation,
    Types.OperationNotAllowed,
    Types.ValueNotSupported,
    Types.VmIncompatibleWithThisHost {
        String methodCall = "Async.VM.assert_can_boot_here";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this VM
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @return The reference of the blob, needed for populating its data
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Blob createNewBlob(Connection c, String name, String mimeType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType };
        var typeReference = new TypeReference<Blob>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this VM
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @param _public True if the blob should be publicly available First published in XenServer 6.1.
     * @return The reference of the blob, needed for populating its data
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Blob createNewBlob(Connection c, String name, String mimeType, Boolean _public) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType, _public };
        var typeReference = new TypeReference<Blob>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this VM
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task createNewBlobAsync(Connection c, String name, String mimeType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a placeholder for a named binary blob of data that is associated with this VM
     * Minimum allowed role: vm-power-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param name The name associated with the blob 
     * @param mimeType The mime type for the data. Empty string translates to application/octet-stream 
     * @param _public True if the blob should be publicly available First published in XenServer 6.1.
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task createNewBlobAsync(Connection c, String name, String mimeType, Boolean _public) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.create_new_blob";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, name, mimeType, _public };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns an error if the VM is not considered agile e.g. because it is tied to a resource local to a host
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void assertAgile(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.assert_agile";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Returns an error if the VM is not considered agile e.g. because it is tied to a resource local to a host
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task assertAgileAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.assert_agile";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns mapping of hosts to ratings, indicating the suitability of starting the VM at that location according to wlb. Rating is replaced with an error if the VM cannot boot there.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return The potential hosts and their corresponding recommendations or errors
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<Host, Set<String>> retrieveWlbRecommendations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.retrieve_wlb_recommendations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<Host, Set<String>>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Returns mapping of hosts to ratings, indicating the suitability of starting the VM at that location according to wlb. Rating is replaced with an error if the VM cannot boot there.
     * Minimum allowed role: read-only
     * First published in XenServer 5.5.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task retrieveWlbRecommendationsAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.retrieve_wlb_recommendations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set custom BIOS strings to this VM. VM will be given a default set of BIOS strings, only some of which can be overridden by the supplied values. Allowed keys are: 'bios-vendor', 'bios-version', 'system-manufacturer', 'system-product-name', 'system-version', 'system-serial-number', 'enclosure-asset-tag', 'baseboard-manufacturer', 'baseboard-product-name', 'baseboard-version', 'baseboard-serial-number', 'baseboard-asset-tag', 'baseboard-location-in-chassis', 'enclosure-asset-tag'
     * Minimum allowed role: vm-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @param value The custom BIOS strings as a list of key-value pairs 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBiosStringsAlreadySet The BIOS strings for this VM have already been set and cannot be changed.
     * @throws Types.InvalidValue The value given is invalid
     */
    public void setBiosStrings(Connection c, Map<String, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBiosStringsAlreadySet,
    Types.InvalidValue {
        String methodCall = "VM.set_bios_strings";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set custom BIOS strings to this VM. VM will be given a default set of BIOS strings, only some of which can be overridden by the supplied values. Allowed keys are: 'bios-vendor', 'bios-version', 'system-manufacturer', 'system-product-name', 'system-version', 'system-serial-number', 'enclosure-asset-tag', 'baseboard-manufacturer', 'baseboard-product-name', 'baseboard-version', 'baseboard-serial-number', 'baseboard-asset-tag', 'baseboard-location-in-chassis', 'enclosure-asset-tag'
     * Minimum allowed role: vm-admin
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @param value The custom BIOS strings as a list of key-value pairs 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBiosStringsAlreadySet The BIOS strings for this VM have already been set and cannot be changed.
     * @throws Types.InvalidValue The value given is invalid
     */
    public Task setBiosStringsAsync(Connection c, Map<String, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBiosStringsAlreadySet,
    Types.InvalidValue {
        String methodCall = "Async.VM.set_bios_strings";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Copy the BIOS strings from the given host to this VM
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param host The host to copy the BIOS strings from 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void copyBiosStrings(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.copy_bios_strings";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Copy the BIOS strings from the given host to this VM
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.6.
     *
     * @param c The connection the call is made on
     * @param host The host to copy the BIOS strings from 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task copyBiosStringsAsync(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.copy_bios_strings";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the value of the protection_policy field
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.6 FP1.
     * @deprecated since XenServer 6.2
     *
     * @param c The connection the call is made on
     * @param value The value 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.2")
    public void setProtectionPolicy(Connection c, VMPP value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_protection_policy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the value of the snapshot schedule field
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.2.
     *
     * @param c The connection the call is made on
     * @param value The value 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSnapshotSchedule(Connection c, VMSS value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_snapshot_schedule";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set this VM's start delay in seconds
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param value This VM's start delay in seconds 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setStartDelay(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_start_delay";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set this VM's start delay in seconds
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param value This VM's start delay in seconds 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setStartDelayAsync(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_start_delay";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set this VM's shutdown delay in seconds
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param value This VM's shutdown delay in seconds 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setShutdownDelay(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_shutdown_delay";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set this VM's shutdown delay in seconds
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param value This VM's shutdown delay in seconds 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setShutdownDelayAsync(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_shutdown_delay";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set this VM's boot order
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param value This VM's boot order 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOrder(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_order";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set this VM's boot order
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param value This VM's boot order 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setOrderAsync(Connection c, Long value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_order";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set this VM's suspend VDI, which must be indentical to its current one
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param value The suspend VDI uuid 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setSuspendVDI(Connection c, VDI value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_suspend_VDI";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set this VM's suspend VDI, which must be indentical to its current one
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param value The suspend VDI uuid 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setSuspendVDIAsync(Connection c, VDI value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_suspend_VDI";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Assert whether all SRs required to recover this VM are available.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param sessionTo The session to which the VM is to be recovered. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmIsPartOfAnAppliance This operation is not allowed as the VM is part of an appliance.
     * @throws Types.VmRequiresSr You attempted to run a VM on a host which doesn't have access to an SR needed by the VM. The VM has at least one VBD attached to a VDI in the SR.
     */
    public void assertCanBeRecovered(Connection c, Session sessionTo) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmIsPartOfAnAppliance,
    Types.VmRequiresSr {
        String methodCall = "VM.assert_can_be_recovered";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sessionTo };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Assert whether all SRs required to recover this VM are available.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param sessionTo The session to which the VM is to be recovered. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmIsPartOfAnAppliance This operation is not allowed as the VM is part of an appliance.
     * @throws Types.VmRequiresSr You attempted to run a VM on a host which doesn't have access to an SR needed by the VM. The VM has at least one VBD attached to a VDI in the SR.
     */
    public Task assertCanBeRecoveredAsync(Connection c, Session sessionTo) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmIsPartOfAnAppliance,
    Types.VmRequiresSr {
        String methodCall = "Async.VM.assert_can_be_recovered";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sessionTo };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * List all the SR's that are required for the VM to be recovered
     * Minimum allowed role: read-only
     * First published in XenServer 6.5.
     *
     * @param c The connection the call is made on
     * @param sessionTo The session to which the SRs of the VM have to be recovered. 
     * @return refs for SRs required to recover the VM
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<SR> getSRsRequiredForRecovery(Connection c, Session sessionTo) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_SRs_required_for_recovery";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sessionTo };
        var typeReference = new TypeReference<Set<SR>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * List all the SR's that are required for the VM to be recovered
     * Minimum allowed role: read-only
     * First published in XenServer 6.5.
     *
     * @param c The connection the call is made on
     * @param sessionTo The session to which the SRs of the VM have to be recovered. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getSRsRequiredForRecoveryAsync(Connection c, Session sessionTo) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.get_SRs_required_for_recovery";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sessionTo };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Recover the VM
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param sessionTo The session to which the VM is to be recovered. 
     * @param force Whether the VM should replace newer versions of itself. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void recover(Connection c, Session sessionTo, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.recover";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sessionTo, force };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Recover the VM
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param sessionTo The session to which the VM is to be recovered. 
     * @param force Whether the VM should replace newer versions of itself. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task recoverAsync(Connection c, Session sessionTo, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.recover";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sessionTo, force };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Import using a conversion service.
     * Minimum allowed role: vm-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param type Type of the conversion 
     * @param username Admin username on the host 
     * @param password Password on the host 
     * @param sr The destination SR 
     * @param remoteConfig Remote configuration options 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static void import_Convert(Connection c, String type, String username, String password, SR sr, Map<String, String> remoteConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.import_convert";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, type, username, password, sr, remoteConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Import using a conversion service.
     * Minimum allowed role: vm-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @param type Type of the conversion 
     * @param username Admin username on the host 
     * @param password Password on the host 
     * @param sr The destination SR 
     * @param remoteConfig Remote configuration options 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task import_ConvertAsync(Connection c, String type, String username, String password, SR sr, Map<String, String> remoteConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.import_convert";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, type, username, password, sr, remoteConfig };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Assign this VM to an appliance.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param value The appliance to which this VM should be assigned. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setAppliance(Connection c, VMAppliance value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_appliance";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Assign this VM to an appliance.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param value The appliance to which this VM should be assigned. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setApplianceAsync(Connection c, VMAppliance value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_appliance";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Associate this VM with VM groups.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @param value The VM groups to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     */
    public void setGroups(Connection c, Set<VMGroup> value) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OperationNotAllowed {
        String methodCall = "VM.set_groups";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Associate this VM with VM groups.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 24.19.1.
     *
     * @param c The connection the call is made on
     * @param value The VM groups to set 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     */
    public Task setGroupsAsync(Connection c, Set<VMGroup> value) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OperationNotAllowed {
        String methodCall = "Async.VM.set_groups";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Query the system services advertised by this VM and register them. This can only be applied to a system domain.
     * Minimum allowed role: pool-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @return map of service type to name
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> queryServices(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.query_services";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Query the system services advertised by this VM and register them. This can only be applied to a system domain.
     * Minimum allowed role: pool-admin
     * First published in XenServer 6.1.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task queryServicesAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.query_services";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Call an API plugin on this vm
     * Minimum allowed role: vm-operator
     * First published in XenServer 6.5 SP1.
     *
     * @param c The connection the call is made on
     * @param plugin The name of the plugin 
     * @param fn The name of the function within the plugin 
     * @param args Arguments for the function 
     * @return Result from the plugin
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String callPlugin(Connection c, String plugin, String fn, Map<String, String> args) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.call_plugin";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, plugin, fn, args };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Call an API plugin on this vm
     * Minimum allowed role: vm-operator
     * First published in XenServer 6.5 SP1.
     *
     * @param c The connection the call is made on
     * @param plugin The name of the plugin 
     * @param fn The name of the function within the plugin 
     * @param args Arguments for the function 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task callPluginAsync(Connection c, String plugin, String fn, Map<String, String> args) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.call_plugin";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, plugin, fn, args };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Call an API plugin on the host where this vm resides
     * Minimum allowed role: vm-operator
     * Experimental. First published in 25.22.0.
     *
     * @param c The connection the call is made on
     * @param plugin The name of the plugin 
     * @param fn The name of the function within the plugin 
     * @param args Arguments for the function 
     * @return Result from the plugin
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String callHostPlugin(Connection c, String plugin, String fn, Map<String, String> args) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.call_host_plugin";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, plugin, fn, args };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Call an API plugin on the host where this vm resides
     * Minimum allowed role: vm-operator
     * Experimental. First published in 25.22.0.
     *
     * @param c The connection the call is made on
     * @param plugin The name of the plugin 
     * @param fn The name of the function within the plugin 
     * @param args Arguments for the function 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task callHostPluginAsync(Connection c, String plugin, String fn, Map<String, String> args) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.call_host_plugin";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, plugin, fn, args };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Controls whether, when the VM starts in HVM mode, its virtual hardware will include the emulated PCI device for which drivers may be available through Windows Update. Usually this should never be changed on a VM on which Windows has been installed: changing it on such a VM is likely to lead to a crash on next start.
     * Minimum allowed role: vm-admin
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param value True to provide the vendor PCI device. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setHasVendorDevice(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_has_vendor_device";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Controls whether, when the VM starts in HVM mode, its virtual hardware will include the emulated PCI device for which drivers may be available through Windows Update. Usually this should never be changed on a VM on which Windows has been installed: changing it on such a VM is likely to lead to a crash on next start.
     * Minimum allowed role: vm-admin
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param value True to provide the vendor PCI device. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setHasVendorDeviceAsync(Connection c, Boolean value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_has_vendor_device";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Import an XVA from a URI
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param url The URL of the XVA file 
     * @param sr The destination SR for the disks 
     * @param fullRestore Perform a full restore 
     * @param force Force the import 
     * @return Imported VM reference
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VM> import_(Connection c, String url, SR sr, Boolean fullRestore, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.import";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, url, sr, fullRestore, force };
        var typeReference = new TypeReference<Set<VM>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Import an XVA from a URI
     * Minimum allowed role: pool-operator
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @param url The URL of the XVA file 
     * @param sr The destination SR for the disks 
     * @param fullRestore Perform a full restore 
     * @param force Force the import 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task import_Async(Connection c, String url, SR sr, Boolean fullRestore, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.import";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, url, sr, fullRestore, force };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Sets the actions_after_crash parameter
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value The new value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setActionsAfterCrash(Connection c, Types.OnCrashBehaviour value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_actions_after_crash";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Sets the actions_after_crash parameter
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param value The new value to set 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setActionsAfterCrashAsync(Connection c, Types.OnCrashBehaviour value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_actions_after_crash";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the VM.domain_type field of the given VM, which will take effect when it is next started
     * Minimum allowed role: vm-admin
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @param value The new domain type 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setDomainType(Connection c, Types.DomainType value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_domain_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the VM.HVM_boot_policy field of the given VM, which will take effect when it is next started
     * Minimum allowed role: vm-admin
     * First published in XenServer 4.0.
     * @deprecated since XenServer 7.5
     *
     * @param c The connection the call is made on
     * @param value The new HVM boot policy 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.5")
    public void setHVMBootPolicy(Connection c, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_HVM_boot_policy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Restart device models of the VM
     * Minimum allowed role: vm-power-admin
     * Experimental. First published in 23.30.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     */
    public void restartDeviceModels(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.VmIsTemplate,
    Types.OperationNotAllowed,
    Types.VmBadPowerState {
        String methodCall = "VM.restart_device_models";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Restart device models of the VM
     * Minimum allowed role: vm-power-admin
     * Experimental. First published in 23.30.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     * @throws Types.OtherOperationInProgress Another operation involving the object is currently in progress
     * @throws Types.VmIsTemplate The operation attempted is not valid for a template VM
     * @throws Types.OperationNotAllowed You attempted an operation that was not allowed.
     * @throws Types.VmBadPowerState You attempted an operation on a VM that was not in an appropriate power state at the time; for example, you attempted to start a VM that was already running. The parameters returned are the VM's handle, and the expected and actual VM state at the time of the call.
     */
    public Task restartDeviceModelsAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmBadPowerState,
    Types.OtherOperationInProgress,
    Types.VmIsTemplate,
    Types.OperationNotAllowed,
    Types.VmBadPowerState {
        String methodCall = "Async.VM.restart_device_models";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the UEFI mode of a VM
     * Minimum allowed role: pool-admin
     * Experimental. First published in 24.17.0.
     *
     * @param c The connection the call is made on
     * @param mode The UEFI mode to set 
     * @return Result from the varstore-sb-state call
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String setUefiMode(Connection c, Types.VmUefiMode mode) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_uefi_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, mode };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the UEFI mode of a VM
     * Minimum allowed role: pool-admin
     * Experimental. First published in 24.17.0.
     *
     * @param c The connection the call is made on
     * @param mode The UEFI mode to set 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setUefiModeAsync(Connection c, Types.VmUefiMode mode) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_uefi_mode";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, mode };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return the secureboot readiness of the VM
     * Minimum allowed role: pool-admin
     * Experimental. First published in 24.17.0.
     *
     * @param c The connection the call is made on
     * @return The secureboot readiness of the VM
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.VmSecurebootReadiness getSecurebootReadiness(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_secureboot_readiness";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.VmSecurebootReadiness>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return the secureboot readiness of the VM
     * Minimum allowed role: pool-admin
     * Experimental. First published in 24.17.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getSecurebootReadinessAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.get_secureboot_readiness";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Update list of operations which have been explicitly blocked and an error code
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value Blocked operations 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setBlockedOperations(Connection c, Map<Types.VmOperations, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.set_blocked_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Update list of operations which have been explicitly blocked and an error code
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param value Blocked operations 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setBlockedOperationsAsync(Connection c, Map<Types.VmOperations, String> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.set_blocked_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Update list of operations which have been explicitly blocked and an error code
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param key Blocked operation 
     * @param value Error code 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToBlockedOperations(Connection c, Types.VmOperations key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.add_to_blocked_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Update list of operations which have been explicitly blocked and an error code
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param key Blocked operation 
     * @param value Error code 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task addToBlockedOperationsAsync(Connection c, Types.VmOperations key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.add_to_blocked_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Update list of operations which have been explicitly blocked and an error code
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param key Blocked operation 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromBlockedOperations(Connection c, Types.VmOperations key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.remove_from_blocked_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Update list of operations which have been explicitly blocked and an error code
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param key Blocked operation 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task removeFromBlockedOperationsAsync(Connection c, Types.VmOperations key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.remove_from_blocked_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Pass unattend.xml to Windows sysprep and wait for the VM to shut down as part of a reboot.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 25.24.0.
     *
     * @param c The connection the call is made on
     * @param unattend XML content passed to sysprep 
     * @param timeout timeout in seconds for expected reboot 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void sysprep(Connection c, String unattend, Double timeout) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.sysprep";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, unattend, timeout };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Pass unattend.xml to Windows sysprep and wait for the VM to shut down as part of a reboot.
     * Minimum allowed role: vm-admin
     * Experimental. First published in 25.24.0.
     *
     * @param c The connection the call is made on
     * @param unattend XML content passed to sysprep 
     * @param timeout timeout in seconds for expected reboot 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task sysprepAsync(Connection c, String unattend, Double timeout) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM.sysprep";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, unattend, timeout };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the VMs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VM> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<VM>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of VM references to VM records for all VMs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<VM, VM.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<VM, VM.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}