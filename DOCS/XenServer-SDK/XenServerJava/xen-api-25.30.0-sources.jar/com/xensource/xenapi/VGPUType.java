/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A type of virtual GPU
 * First published in XenServer 6.2 SP1 Tech-Preview.
 *
 * @author Cloud Software Group, Inc.
 */
public class VGPUType extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    VGPUType(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a VGPUType, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof VGPUType)
        {
            VGPUType other = (VGPUType) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a VGPUType
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "vendorName", this.vendorName);
            print.printf("%1$20s: %2$s\n", "modelName", this.modelName);
            print.printf("%1$20s: %2$s\n", "framebufferSize", this.framebufferSize);
            print.printf("%1$20s: %2$s\n", "maxHeads", this.maxHeads);
            print.printf("%1$20s: %2$s\n", "maxResolutionX", this.maxResolutionX);
            print.printf("%1$20s: %2$s\n", "maxResolutionY", this.maxResolutionY);
            print.printf("%1$20s: %2$s\n", "supportedOnPGPUs", this.supportedOnPGPUs);
            print.printf("%1$20s: %2$s\n", "enabledOnPGPUs", this.enabledOnPGPUs);
            print.printf("%1$20s: %2$s\n", "VGPUs", this.VGPUs);
            print.printf("%1$20s: %2$s\n", "supportedOnGPUGroups", this.supportedOnGPUGroups);
            print.printf("%1$20s: %2$s\n", "enabledOnGPUGroups", this.enabledOnGPUGroups);
            print.printf("%1$20s: %2$s\n", "implementation", this.implementation);
            print.printf("%1$20s: %2$s\n", "identifier", this.identifier);
            print.printf("%1$20s: %2$s\n", "experimental", this.experimental);
            print.printf("%1$20s: %2$s\n", "compatibleTypesInVm", this.compatibleTypesInVm);
            return writer.toString();
        }

        /**
         * Convert a VGPUType.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("vendor_name", this.vendorName == null ? "" : this.vendorName);
            map.put("model_name", this.modelName == null ? "" : this.modelName);
            map.put("framebuffer_size", this.framebufferSize == null ? 0 : this.framebufferSize);
            map.put("max_heads", this.maxHeads == null ? 0 : this.maxHeads);
            map.put("max_resolution_x", this.maxResolutionX == null ? 0 : this.maxResolutionX);
            map.put("max_resolution_y", this.maxResolutionY == null ? 0 : this.maxResolutionY);
            map.put("supported_on_PGPUs", this.supportedOnPGPUs == null ? new LinkedHashSet<PGPU>() : this.supportedOnPGPUs);
            map.put("enabled_on_PGPUs", this.enabledOnPGPUs == null ? new LinkedHashSet<PGPU>() : this.enabledOnPGPUs);
            map.put("VGPUs", this.VGPUs == null ? new LinkedHashSet<VGPU>() : this.VGPUs);
            map.put("supported_on_GPU_groups", this.supportedOnGPUGroups == null ? new LinkedHashSet<GPUGroup>() : this.supportedOnGPUGroups);
            map.put("enabled_on_GPU_groups", this.enabledOnGPUGroups == null ? new LinkedHashSet<GPUGroup>() : this.enabledOnGPUGroups);
            map.put("implementation", this.implementation == null ? Types.VgpuTypeImplementation.UNRECOGNIZED : this.implementation);
            map.put("identifier", this.identifier == null ? "" : this.identifier);
            map.put("experimental", this.experimental == null ? false : this.experimental);
            map.put("compatible_types_in_vm", this.compatibleTypesInVm == null ? new LinkedHashSet<VGPUType>() : this.compatibleTypesInVm);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * Name of VGPU vendor
         */
        @JsonProperty("vendor_name")
        public String vendorName;

        /**
         * Model name associated with the VGPU type
         */
        @JsonProperty("model_name")
        public String modelName;

        /**
         * Framebuffer size of the VGPU type, in bytes
         */
        @JsonProperty("framebuffer_size")
        public Long framebufferSize;

        /**
         * Maximum number of displays supported by the VGPU type
         */
        @JsonProperty("max_heads")
        public Long maxHeads;

        /**
         * Maximum resolution (width) supported by the VGPU type
         * First published in XenServer 6.2 SP1.
         */
        @JsonProperty("max_resolution_x")
        public Long maxResolutionX;

        /**
         * Maximum resolution (height) supported by the VGPU type
         * First published in XenServer 6.2 SP1.
         */
        @JsonProperty("max_resolution_y")
        public Long maxResolutionY;

        /**
         * List of PGPUs that support this VGPU type
         */
        @JsonProperty("supported_on_PGPUs")
        public Set<PGPU> supportedOnPGPUs;

        /**
         * List of PGPUs that have this VGPU type enabled
         */
        @JsonProperty("enabled_on_PGPUs")
        public Set<PGPU> enabledOnPGPUs;

        /**
         * List of VGPUs of this type
         */
        @JsonProperty("VGPUs")
        public Set<VGPU> VGPUs;

        /**
         * List of GPU groups in which at least one PGPU supports this VGPU type
         * First published in XenServer 6.2 SP1.
         */
        @JsonProperty("supported_on_GPU_groups")
        public Set<GPUGroup> supportedOnGPUGroups;

        /**
         * List of GPU groups in which at least one have this VGPU type enabled
         * First published in XenServer 6.2 SP1.
         */
        @JsonProperty("enabled_on_GPU_groups")
        public Set<GPUGroup> enabledOnGPUGroups;

        /**
         * The internal implementation of this VGPU type
         * First published in XenServer 7.0.
         */
        @JsonProperty("implementation")
        public Types.VgpuTypeImplementation implementation;

        /**
         * Key used to identify VGPU types and avoid creating duplicates - this field is used internally and not intended for interpretation by API clients
         * First published in XenServer 7.0.
         */
        @JsonProperty("identifier")
        public String identifier;

        /**
         * Indicates whether VGPUs of this type should be considered experimental
         * First published in XenServer 7.0.
         */
        @JsonProperty("experimental")
        public Boolean experimental;

        /**
         * List of VGPU types which are compatible in one VM
         * First published in Citrix Hypervisor 8.1.
         */
        @JsonProperty("compatible_types_in_vm")
        public Set<VGPUType> compatibleTypesInVm;

    }

    /**
     * Get a record containing the current state of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VGPUType.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VGPUType.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the VGPU_type instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VGPUType getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<VGPUType>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the vendor_name field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getVendorName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_vendor_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the model_name field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getModelName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_model_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the framebuffer_size field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getFramebufferSize(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_framebuffer_size";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the max_heads field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getMaxHeads(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_max_heads";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the max_resolution_x field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getMaxResolutionX(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_max_resolution_x";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the max_resolution_y field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getMaxResolutionY(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_max_resolution_y";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the supported_on_PGPUs field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PGPU> getSupportedOnPGPUs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_supported_on_PGPUs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PGPU>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the enabled_on_PGPUs field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PGPU> getEnabledOnPGPUs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_enabled_on_PGPUs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PGPU>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VGPUs field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VGPU> getVGPUs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_VGPUs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VGPU>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the supported_on_GPU_groups field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<GPUGroup> getSupportedOnGPUGroups(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_supported_on_GPU_groups";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<GPUGroup>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the enabled_on_GPU_groups field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<GPUGroup> getEnabledOnGPUGroups(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_enabled_on_GPU_groups";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<GPUGroup>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the implementation field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.VgpuTypeImplementation getImplementation(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_implementation";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.VgpuTypeImplementation>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the identifier field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getIdentifier(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_identifier";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the experimental field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in XenServer 7.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getExperimental(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_experimental";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the compatible_types_in_vm field of the given VGPU_type.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VGPUType> getCompatibleTypesInVm(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_compatible_types_in_vm";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VGPUType>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the VGPU_types known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VGPUType> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<VGPUType>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of VGPU_type references to VGPU_type records for all VGPU_types known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<VGPUType, VGPUType.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VGPU_type.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<VGPUType, VGPUType.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}