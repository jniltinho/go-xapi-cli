/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * VM appliance
 * First published in XenServer 6.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class VMAppliance extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    VMAppliance(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a VMAppliance, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof VMAppliance)
        {
            VMAppliance other = (VMAppliance) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a VMAppliance
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "allowedOperations", this.allowedOperations);
            print.printf("%1$20s: %2$s\n", "currentOperations", this.currentOperations);
            print.printf("%1$20s: %2$s\n", "VMs", this.VMs);
            return writer.toString();
        }

        /**
         * Convert a VMAppliance.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("allowed_operations", this.allowedOperations == null ? new LinkedHashSet<Types.VmApplianceOperation>() : this.allowedOperations);
            map.put("current_operations", this.currentOperations == null ? new HashMap<String, Types.VmApplianceOperation>() : this.currentOperations);
            map.put("VMs", this.VMs == null ? new LinkedHashSet<VM>() : this.VMs);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * list of the operations allowed in this state. This list is advisory only and the server state may have changed by the time this field is read by a client.
         */
        @JsonProperty("allowed_operations")
        public Set<Types.VmApplianceOperation> allowedOperations;

        /**
         * links each of the running tasks using this object (by reference) to a current_operation enum which describes the nature of the task.
         */
        @JsonProperty("current_operations")
        public Map<String, Types.VmApplianceOperation> currentOperations;

        /**
         * all VMs in this appliance
         */
        @JsonProperty("VMs")
        public Set<VM> VMs;

    }

    /**
     * Get a record containing the current state of the given VM_appliance.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VMAppliance.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VMAppliance.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the VM_appliance instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VMAppliance getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<VMAppliance>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VM_appliance instance, and return its handle.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return reference to the newly created object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VMAppliance create(Connection c, VMAppliance.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<VMAppliance>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Create a new VM_appliance instance, and return its handle.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param record All constructor arguments 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, VMAppliance.Record record) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM_appliance.create";
        String sessionReference = c.getSessionReference();
        var record_map = record.toMap();
        Object[] methodParameters = { sessionReference, record_map };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Destroy the specified VM_appliance instance.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Destroy the specified VM_appliance instance.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM_appliance.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the VM_appliance instances with the given label.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VMAppliance> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<VMAppliance>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given VM_appliance.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given VM_appliance.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given VM_appliance.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allowed_operations field of the given VM_appliance.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.VmApplianceOperation> getAllowedOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.get_allowed_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.VmApplianceOperation>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the current_operations field of the given VM_appliance.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, Types.VmApplianceOperation> getCurrentOperations(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.get_current_operations";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, Types.VmApplianceOperation>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VMs field of the given VM_appliance.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VM> getVMs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.get_VMs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VM>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name/label field of the given VM_appliance.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param label New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, label };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name/description field of the given VM_appliance.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param description New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameDescription(Connection c, String description) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, description };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Start all VMs in the appliance
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param paused Instantiate all VMs belonging to this appliance in paused state if set to true. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OperationPartiallyFailed Some VMs belonging to the appliance threw an exception while carrying out the specified operation
     */
    public void start(Connection c, Boolean paused) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OperationPartiallyFailed {
        String methodCall = "VM_appliance.start";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, paused };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Start all VMs in the appliance
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param paused Instantiate all VMs belonging to this appliance in paused state if set to true. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OperationPartiallyFailed Some VMs belonging to the appliance threw an exception while carrying out the specified operation
     */
    public Task startAsync(Connection c, Boolean paused) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OperationPartiallyFailed {
        String methodCall = "Async.VM_appliance.start";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, paused };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Perform a clean shutdown of all the VMs in the appliance
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OperationPartiallyFailed Some VMs belonging to the appliance threw an exception while carrying out the specified operation
     */
    public void cleanShutdown(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OperationPartiallyFailed {
        String methodCall = "VM_appliance.clean_shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Perform a clean shutdown of all the VMs in the appliance
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OperationPartiallyFailed Some VMs belonging to the appliance threw an exception while carrying out the specified operation
     */
    public Task cleanShutdownAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OperationPartiallyFailed {
        String methodCall = "Async.VM_appliance.clean_shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Perform a hard shutdown of all the VMs in the appliance
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OperationPartiallyFailed Some VMs belonging to the appliance threw an exception while carrying out the specified operation
     */
    public void hardShutdown(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OperationPartiallyFailed {
        String methodCall = "VM_appliance.hard_shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Perform a hard shutdown of all the VMs in the appliance
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OperationPartiallyFailed Some VMs belonging to the appliance threw an exception while carrying out the specified operation
     */
    public Task hardShutdownAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OperationPartiallyFailed {
        String methodCall = "Async.VM_appliance.hard_shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * For each VM in the appliance, try to shut it down cleanly. If this fails, perform a hard shutdown of the VM.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OperationPartiallyFailed Some VMs belonging to the appliance threw an exception while carrying out the specified operation
     */
    public void shutdown(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OperationPartiallyFailed {
        String methodCall = "VM_appliance.shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * For each VM in the appliance, try to shut it down cleanly. If this fails, perform a hard shutdown of the VM.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.OperationPartiallyFailed Some VMs belonging to the appliance threw an exception while carrying out the specified operation
     */
    public Task shutdownAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.OperationPartiallyFailed {
        String methodCall = "Async.VM_appliance.shutdown";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Assert whether all SRs required to recover this VM appliance are available.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param sessionTo The session to which the VM appliance is to be recovered. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmRequiresSr You attempted to run a VM on a host which doesn't have access to an SR needed by the VM. The VM has at least one VBD attached to a VDI in the SR.
     */
    public void assertCanBeRecovered(Connection c, Session sessionTo) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmRequiresSr {
        String methodCall = "VM_appliance.assert_can_be_recovered";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sessionTo };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Assert whether all SRs required to recover this VM appliance are available.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param sessionTo The session to which the VM appliance is to be recovered. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmRequiresSr You attempted to run a VM on a host which doesn't have access to an SR needed by the VM. The VM has at least one VBD attached to a VDI in the SR.
     */
    public Task assertCanBeRecoveredAsync(Connection c, Session sessionTo) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmRequiresSr {
        String methodCall = "Async.VM_appliance.assert_can_be_recovered";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sessionTo };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the list of SRs required by the VM appliance to recover.
     * Minimum allowed role: read-only
     * First published in XenServer 6.5.
     *
     * @param c The connection the call is made on
     * @param sessionTo The session to which the list of SRs have to be recovered . 
     * @return refs for SRs required to recover the VM
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<SR> getSRsRequiredForRecovery(Connection c, Session sessionTo) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.get_SRs_required_for_recovery";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sessionTo };
        var typeReference = new TypeReference<Set<SR>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the list of SRs required by the VM appliance to recover.
     * Minimum allowed role: read-only
     * First published in XenServer 6.5.
     *
     * @param c The connection the call is made on
     * @param sessionTo The session to which the list of SRs have to be recovered . 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getSRsRequiredForRecoveryAsync(Connection c, Session sessionTo) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.VM_appliance.get_SRs_required_for_recovery";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sessionTo };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Recover the VM appliance
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param sessionTo The session to which the VM appliance is to be recovered. 
     * @param force Whether the VMs should replace newer versions of themselves. 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmRequiresSr You attempted to run a VM on a host which doesn't have access to an SR needed by the VM. The VM has at least one VBD attached to a VDI in the SR.
     */
    public void recover(Connection c, Session sessionTo, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmRequiresSr {
        String methodCall = "VM_appliance.recover";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sessionTo, force };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Recover the VM appliance
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param sessionTo The session to which the VM appliance is to be recovered. 
     * @param force Whether the VMs should replace newer versions of themselves. 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     * @throws Types.VmRequiresSr You attempted to run a VM on a host which doesn't have access to an SR needed by the VM. The VM has at least one VBD attached to a VDI in the SR.
     */
    public Task recoverAsync(Connection c, Session sessionTo, Boolean force) throws
            BadServerResponse,
            XenAPIException,
            IOException,
    Types.VmRequiresSr {
        String methodCall = "Async.VM_appliance.recover";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, sessionTo, force };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the VM_appliances known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VMAppliance> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<VMAppliance>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of VM_appliance references to VM_appliance records for all VM_appliances known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<VMAppliance, VMAppliance.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_appliance.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<VMAppliance, VMAppliance.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}