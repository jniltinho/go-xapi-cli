/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * An X509 certificate used for TLS connections
 * First published in Citrix Hypervisor 8.2.
 *
 * @author Cloud Software Group, Inc.
 */
public class Certificate extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    Certificate(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a Certificate, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Certificate)
        {
            Certificate other = (Certificate) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a Certificate
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "name", this.name);
            print.printf("%1$20s: %2$s\n", "type", this.type);
            print.printf("%1$20s: %2$s\n", "host", this.host);
            print.printf("%1$20s: %2$s\n", "notBefore", this.notBefore);
            print.printf("%1$20s: %2$s\n", "notAfter", this.notAfter);
            print.printf("%1$20s: %2$s\n", "fingerprint", this.fingerprint);
            print.printf("%1$20s: %2$s\n", "fingerprintSha256", this.fingerprintSha256);
            print.printf("%1$20s: %2$s\n", "fingerprintSha1", this.fingerprintSha1);
            return writer.toString();
        }

        /**
         * Convert a Certificate.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name", this.name == null ? "" : this.name);
            map.put("type", this.type == null ? Types.CertificateType.UNRECOGNIZED : this.type);
            map.put("host", this.host == null ? new Host("OpaqueRef:NULL") : this.host);
            map.put("not_before", this.notBefore == null ? new Date(0) : this.notBefore);
            map.put("not_after", this.notAfter == null ? new Date(0) : this.notAfter);
            map.put("fingerprint", this.fingerprint == null ? "" : this.fingerprint);
            map.put("fingerprint_sha256", this.fingerprintSha256 == null ? "" : this.fingerprintSha256);
            map.put("fingerprint_sha1", this.fingerprintSha1 == null ? "" : this.fingerprintSha1);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * The name of the certificate, only present on certificates of type 'ca'
         * First published in 1.294.0.
         */
        @JsonProperty("name")
        public String name;

        /**
         * The type of the certificate, either 'ca', 'host' or 'host_internal'
         * First published in 1.294.0.
         */
        @JsonProperty("type")
        public Types.CertificateType type;

        /**
         * The host where the certificate is installed
         */
        @JsonProperty("host")
        public Host host;

        /**
         * Date after which the certificate is valid
         */
        @JsonProperty("not_before")
        public Date notBefore;

        /**
         * Date before which the certificate is valid
         */
        @JsonProperty("not_after")
        public Date notAfter;

        /**
         * Use fingerprint_sha256 instead
         */
        @JsonProperty("fingerprint")
        @Deprecated(since = "Citrix Hypervisor 8.2")
        public String fingerprint;

        /**
         * The certificate's SHA256 fingerprint / hash
         * Experimental. First published in 24.20.0.
         */
        @JsonProperty("fingerprint_sha256")
        public String fingerprintSha256;

        /**
         * The certificate's SHA1 fingerprint / hash
         * Experimental. First published in 24.20.0.
         */
        @JsonProperty("fingerprint_sha1")
        public String fingerprintSha1;

    }

    /**
     * Get a record containing the current state of the given Certificate.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Certificate.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Certificate.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the Certificate instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Certificate getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<Certificate>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given Certificate.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name field of the given Certificate.
     * Minimum allowed role: read-only
     * First published in 1.294.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getName(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_name";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the type field of the given Certificate.
     * Minimum allowed role: read-only
     * First published in 1.294.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.CertificateType getType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.CertificateType>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host field of the given Certificate.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getHost(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_host";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the not_before field of the given Certificate.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getNotBefore(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_not_before";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the not_after field of the given Certificate.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getNotAfter(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_not_after";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the fingerprint field of the given Certificate.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.2.
     * @deprecated since 24.19.0
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "24.19.0")
    public String getFingerprint(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_fingerprint";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the fingerprint_sha256 field of the given Certificate.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.20.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getFingerprintSha256(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_fingerprint_sha256";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the fingerprint_sha1 field of the given Certificate.
     * Minimum allowed role: read-only
     * Experimental. First published in 24.20.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getFingerprintSha1(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_fingerprint_sha1";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the Certificates known to the system.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<Certificate> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<Certificate>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of Certificate references to Certificate records for all Certificates known to the system.
     * Minimum allowed role: read-only
     * First published in Citrix Hypervisor 8.2.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<Certificate, Certificate.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Certificate.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<Certificate, Certificate.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}