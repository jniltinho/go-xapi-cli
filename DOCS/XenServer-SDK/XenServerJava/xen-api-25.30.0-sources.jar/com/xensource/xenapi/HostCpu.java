/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A physical CPU
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class HostCpu extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    HostCpu(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a HostCpu, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof HostCpu)
        {
            HostCpu other = (HostCpu) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a HostCpu
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "host", this.host);
            print.printf("%1$20s: %2$s\n", "number", this.number);
            print.printf("%1$20s: %2$s\n", "vendor", this.vendor);
            print.printf("%1$20s: %2$s\n", "speed", this.speed);
            print.printf("%1$20s: %2$s\n", "modelname", this.modelname);
            print.printf("%1$20s: %2$s\n", "family", this.family);
            print.printf("%1$20s: %2$s\n", "model", this.model);
            print.printf("%1$20s: %2$s\n", "stepping", this.stepping);
            print.printf("%1$20s: %2$s\n", "flags", this.flags);
            print.printf("%1$20s: %2$s\n", "features", this.features);
            print.printf("%1$20s: %2$s\n", "utilisation", this.utilisation);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            return writer.toString();
        }

        /**
         * Convert a HostCpu.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("host", this.host == null ? new Host("OpaqueRef:NULL") : this.host);
            map.put("number", this.number == null ? 0 : this.number);
            map.put("vendor", this.vendor == null ? "" : this.vendor);
            map.put("speed", this.speed == null ? 0 : this.speed);
            map.put("modelname", this.modelname == null ? "" : this.modelname);
            map.put("family", this.family == null ? 0 : this.family);
            map.put("model", this.model == null ? 0 : this.model);
            map.put("stepping", this.stepping == null ? "" : this.stepping);
            map.put("flags", this.flags == null ? "" : this.flags);
            map.put("features", this.features == null ? "" : this.features);
            map.put("utilisation", this.utilisation == null ? 0.0 : this.utilisation);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * the host the CPU is in
         */
        @JsonProperty("host")
        public Host host;

        /**
         * the number of the physical CPU within the host
         */
        @JsonProperty("number")
        public Long number;

        /**
         * the vendor of the physical CPU
         */
        @JsonProperty("vendor")
        public String vendor;

        /**
         * the speed of the physical CPU
         */
        @JsonProperty("speed")
        public Long speed;

        /**
         * the model name of the physical CPU
         */
        @JsonProperty("modelname")
        public String modelname;

        /**
         * the family (number) of the physical CPU
         */
        @JsonProperty("family")
        public Long family;

        /**
         * the model number of the physical CPU
         */
        @JsonProperty("model")
        public Long model;

        /**
         * the stepping of the physical CPU
         */
        @JsonProperty("stepping")
        public String stepping;

        /**
         * the flags of the physical CPU (a decoded version of the features field)
         */
        @JsonProperty("flags")
        public String flags;

        /**
         * the physical CPU feature bitmap
         */
        @JsonProperty("features")
        public String features;

        /**
         * the current CPU utilisation
         */
        @JsonProperty("utilisation")
        public Double utilisation;

        /**
         * additional configuration
         * First published in XenServer 5.0.
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

    }

    /**
     * Get a record containing the current state of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 5.6
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 5.6")
    public HostCpu.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<HostCpu.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the host_cpu instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 5.6
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 5.6")
    public static HostCpu getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<HostCpu>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getHost(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_host";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the number field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getNumber(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_number";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the vendor field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getVendor(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_vendor";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the speed field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getSpeed(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_speed";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the modelname field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getModelname(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_modelname";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the family field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getFamily(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_family";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the model field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getModel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_model";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the stepping field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getStepping(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_stepping";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the flags field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getFlags(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_flags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the features field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getFeatures(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_features";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the utilisation field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Double getUtilisation(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_utilisation";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Double>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given host_cpu.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the other_config field of the given host_cpu.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given host_cpu.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given host_cpu.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Return a list of all the host_cpus known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 5.6
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 5.6")
    public static Set<HostCpu> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<HostCpu>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of host_cpu references to host_cpu records for all host_cpus known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<HostCpu, HostCpu.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "host_cpu.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<HostCpu, HostCpu.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}