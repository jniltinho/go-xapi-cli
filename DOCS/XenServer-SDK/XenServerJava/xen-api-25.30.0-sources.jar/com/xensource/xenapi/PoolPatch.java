/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * Pool-wide patches
 * First published in XenServer 4.1.
 *
 * @author Cloud Software Group, Inc.
 */
public class PoolPatch extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    PoolPatch(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a PoolPatch, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof PoolPatch)
        {
            PoolPatch other = (PoolPatch) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a PoolPatch
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "version", this.version);
            print.printf("%1$20s: %2$s\n", "size", this.size);
            print.printf("%1$20s: %2$s\n", "poolApplied", this.poolApplied);
            print.printf("%1$20s: %2$s\n", "hostPatches", this.hostPatches);
            print.printf("%1$20s: %2$s\n", "afterApplyGuidance", this.afterApplyGuidance);
            print.printf("%1$20s: %2$s\n", "poolUpdate", this.poolUpdate);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            return writer.toString();
        }

        /**
         * Convert a PoolPatch.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("version", this.version == null ? "" : this.version);
            map.put("size", this.size == null ? 0 : this.size);
            map.put("pool_applied", this.poolApplied == null ? false : this.poolApplied);
            map.put("host_patches", this.hostPatches == null ? new LinkedHashSet<HostPatch>() : this.hostPatches);
            map.put("after_apply_guidance", this.afterApplyGuidance == null ? new LinkedHashSet<Types.AfterApplyGuidance>() : this.afterApplyGuidance);
            map.put("pool_update", this.poolUpdate == null ? new PoolUpdate("OpaqueRef:NULL") : this.poolUpdate);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * Patch version number
         */
        @JsonProperty("version")
        public String version;

        /**
         * Size of the patch
         */
        @JsonProperty("size")
        public Long size;

        /**
         * This patch should be applied across the entire pool
         */
        @JsonProperty("pool_applied")
        public Boolean poolApplied;

        /**
         * This hosts this patch is applied to.
         */
        @JsonProperty("host_patches")
        public Set<HostPatch> hostPatches;

        /**
         * What the client should do after this patch has been applied.
         */
        @JsonProperty("after_apply_guidance")
        public Set<Types.AfterApplyGuidance> afterApplyGuidance;

        /**
         * A reference to the associated pool_update object
         * First published in XenServer 7.1.
         */
        @JsonProperty("pool_update")
        public PoolUpdate poolUpdate;

        /**
         * additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

    }

    /**
     * Get a record containing the current state of the given pool_patch.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public PoolPatch.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PoolPatch.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the pool_patch instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public static PoolPatch getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<PoolPatch>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the pool_patch instances with the given label.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public static Set<PoolPatch> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<PoolPatch>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given pool_patch.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given pool_patch.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given pool_patch.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the version field of the given pool_patch.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getVersion(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_version";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the size field of the given pool_patch.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getSize(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_size";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the pool_applied field of the given pool_patch.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getPoolApplied(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_pool_applied";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host_patches field of the given pool_patch.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<HostPatch> getHostPatches(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_host_patches";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<HostPatch>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the after_apply_guidance field of the given pool_patch.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<Types.AfterApplyGuidance> getAfterApplyGuidance(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_after_apply_guidance";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<Types.AfterApplyGuidance>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the pool_update field of the given pool_patch.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PoolUpdate getPoolUpdate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_pool_update";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PoolUpdate>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given pool_patch.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the other_config field of the given pool_patch.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given pool_patch.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given pool_patch.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Apply the selected patch to a host and return its output
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @param host The host to apply the patch too 
     * @return the output of the patch application process
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public String apply(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.apply";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Apply the selected patch to a host and return its output
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @param host The host to apply the patch too 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public Task applyAsync(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool_patch.apply";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Apply the selected patch to all hosts in the pool and return a map of host_ref -&gt; patch output
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public void poolApply(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.pool_apply";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Apply the selected patch to all hosts in the pool and return a map of host_ref -&gt; patch output
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public Task poolApplyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool_patch.pool_apply";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Execute the precheck stage of the selected patch on a host and return its output
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @param host The host to run the prechecks on 
     * @return the output of the patch prechecks
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public String precheck(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.precheck";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Execute the precheck stage of the selected patch on a host and return its output
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @param host The host to run the prechecks on 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public Task precheckAsync(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool_patch.precheck";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Removes the patch's files from the server
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public void clean(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.clean";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Removes the patch's files from the server
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public Task cleanAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool_patch.clean";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Removes the patch's files from all hosts in the pool, but does not remove the database entries
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public void poolClean(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.pool_clean";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Removes the patch's files from all hosts in the pool, but does not remove the database entries
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public Task poolCleanAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool_patch.pool_clean";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Removes the patch's files from all hosts in the pool, and removes the database entries.  Only works on unapplied patches.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Removes the patch's files from all hosts in the pool, and removes the database entries.  Only works on unapplied patches.
     * Minimum allowed role: pool-operator
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool_patch.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Removes the patch's files from the specified host
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @param host The host on which to clean the patch 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public void cleanOnHost(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.clean_on_host";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Removes the patch's files from the specified host
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @param host The host on which to clean the patch 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public Task cleanOnHostAsync(Connection c, Host host) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.pool_patch.clean_on_host";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, host };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the pool_patchs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     * @deprecated since XenServer 7.1
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 7.1")
    public static Set<PoolPatch> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<PoolPatch>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of pool_patch references to pool_patch records for all pool_patchs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.1.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<PoolPatch, PoolPatch.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "pool_patch.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<PoolPatch, PoolPatch.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}