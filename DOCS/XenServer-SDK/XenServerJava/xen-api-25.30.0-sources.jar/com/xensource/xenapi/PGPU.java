/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A physical GPU (pGPU)
 * First published in XenServer 6.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class PGPU extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    PGPU(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a PGPU, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof PGPU)
        {
            PGPU other = (PGPU) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a PGPU
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "PCI", this.PCI);
            print.printf("%1$20s: %2$s\n", "GPUGroup", this.GPUGroup);
            print.printf("%1$20s: %2$s\n", "host", this.host);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "supportedVGPUTypes", this.supportedVGPUTypes);
            print.printf("%1$20s: %2$s\n", "enabledVGPUTypes", this.enabledVGPUTypes);
            print.printf("%1$20s: %2$s\n", "residentVGPUs", this.residentVGPUs);
            print.printf("%1$20s: %2$s\n", "supportedVGPUMaxCapacities", this.supportedVGPUMaxCapacities);
            print.printf("%1$20s: %2$s\n", "dom0Access", this.dom0Access);
            print.printf("%1$20s: %2$s\n", "isSystemDisplayDevice", this.isSystemDisplayDevice);
            print.printf("%1$20s: %2$s\n", "compatibilityMetadata", this.compatibilityMetadata);
            return writer.toString();
        }

        /**
         * Convert a PGPU.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("PCI", this.PCI == null ? new PCI("OpaqueRef:NULL") : this.PCI);
            map.put("GPU_group", this.GPUGroup == null ? new GPUGroup("OpaqueRef:NULL") : this.GPUGroup);
            map.put("host", this.host == null ? new Host("OpaqueRef:NULL") : this.host);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("supported_VGPU_types", this.supportedVGPUTypes == null ? new LinkedHashSet<VGPUType>() : this.supportedVGPUTypes);
            map.put("enabled_VGPU_types", this.enabledVGPUTypes == null ? new LinkedHashSet<VGPUType>() : this.enabledVGPUTypes);
            map.put("resident_VGPUs", this.residentVGPUs == null ? new LinkedHashSet<VGPU>() : this.residentVGPUs);
            map.put("supported_VGPU_max_capacities", this.supportedVGPUMaxCapacities == null ? new HashMap<VGPUType, Long>() : this.supportedVGPUMaxCapacities);
            map.put("dom0_access", this.dom0Access == null ? Types.PciDom0Access.UNRECOGNIZED : this.dom0Access);
            map.put("is_system_display_device", this.isSystemDisplayDevice == null ? false : this.isSystemDisplayDevice);
            map.put("compatibility_metadata", this.compatibilityMetadata == null ? new HashMap<String, String>() : this.compatibilityMetadata);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * Link to underlying PCI device
         */
        @JsonProperty("PCI")
        public PCI PCI;

        /**
         * GPU group the pGPU is contained in
         */
        @JsonProperty("GPU_group")
        public GPUGroup GPUGroup;

        /**
         * Host that owns the GPU
         */
        @JsonProperty("host")
        public Host host;

        /**
         * Additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * List of VGPU types supported by the underlying hardware
         * First published in XenServer 6.2 SP1 Tech-Preview.
         */
        @JsonProperty("supported_VGPU_types")
        public Set<VGPUType> supportedVGPUTypes;

        /**
         * List of VGPU types which have been enabled for this PGPU
         * First published in XenServer 6.2 SP1 Tech-Preview.
         */
        @JsonProperty("enabled_VGPU_types")
        public Set<VGPUType> enabledVGPUTypes;

        /**
         * List of VGPUs running on this PGPU
         * First published in XenServer 6.2 SP1 Tech-Preview.
         */
        @JsonProperty("resident_VGPUs")
        public Set<VGPU> residentVGPUs;

        /**
         * A map relating each VGPU type supported on this GPU to the maximum number of VGPUs of that type which can run simultaneously on this GPU
         * First published in XenServer 6.2 SP1.
         */
        @JsonProperty("supported_VGPU_max_capacities")
        public Map<VGPUType, Long> supportedVGPUMaxCapacities;

        /**
         * The accessibility of this device from dom0
         * First published in XenServer 6.5 SP1.
         */
        @JsonProperty("dom0_access")
        @Deprecated(since = "XenServer 6.5 SP1")
        public Types.PciDom0Access dom0Access;

        /**
         * Is this device the system display device
         * First published in XenServer 6.5 SP1.
         */
        @JsonProperty("is_system_display_device")
        public Boolean isSystemDisplayDevice;

        /**
         * PGPU metadata to determine whether a VGPU can migrate between two PGPUs
         * First published in XenServer 7.3.
         */
        @JsonProperty("compatibility_metadata")
        public Map<String, String> compatibilityMetadata;

    }

    /**
     * Get a record containing the current state of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PGPU.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PGPU.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the PGPU instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static PGPU getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<PGPU>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PCI field of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public PCI getPCI(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_PCI";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<PCI>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the GPU_group field of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public GPUGroup getGPUGroup(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_GPU_group";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<GPUGroup>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the host field of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Host getHost(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_host";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Host>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the supported_VGPU_types field of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VGPUType> getSupportedVGPUTypes(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_supported_VGPU_types";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VGPUType>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the enabled_VGPU_types field of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VGPUType> getEnabledVGPUTypes(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_enabled_VGPU_types";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VGPUType>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the resident_VGPUs field of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VGPU> getResidentVGPUs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_resident_VGPUs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VGPU>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the supported_VGPU_max_capacities field of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<VGPUType, Long> getSupportedVGPUMaxCapacities(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_supported_VGPU_max_capacities";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<VGPUType, Long>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the dom0_access field of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.5 SP1.
     * @deprecated since 24.14.0
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "24.14.0")
    public Types.PciDom0Access getDom0Access(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_dom0_access";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.PciDom0Access>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the is_system_display_device field of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 6.5 SP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getIsSystemDisplayDevice(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_is_system_display_device";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the compatibility_metadata field of the given PGPU.
     * Minimum allowed role: read-only
     * First published in XenServer 7.3.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getCompatibilityMetadata(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_compatibility_metadata";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the other_config field of the given PGPU.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given PGPU.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given PGPU.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param value The VGPU type to enable 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addEnabledVGPUTypes(Connection c, VGPUType value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.add_enabled_VGPU_types";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param value The VGPU type to enable 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task addEnabledVGPUTypesAsync(Connection c, VGPUType value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PGPU.add_enabled_VGPU_types";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param value The VGPU type to disable 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeEnabledVGPUTypes(Connection c, VGPUType value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.remove_enabled_VGPU_types";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param value The VGPU type to disable 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task removeEnabledVGPUTypesAsync(Connection c, VGPUType value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PGPU.remove_enabled_VGPU_types";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param value The VGPU types to enable 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setEnabledVGPUTypes(Connection c, Set<VGPUType> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.set_enabled_VGPU_types";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param value The VGPU types to enable 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setEnabledVGPUTypesAsync(Connection c, Set<VGPUType> value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PGPU.set_enabled_VGPU_types";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param value The group to which the PGPU will be moved 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setGPUGroup(Connection c, GPUGroup value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.set_GPU_group";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param value The group to which the PGPU will be moved 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task setGPUGroupAsync(Connection c, GPUGroup value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PGPU.set_GPU_group";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, value };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param vgpuType The VGPU type for which we want to find the number of VGPUs which can still be started on this PGPU 
     * @return The number of VGPUs of the specified type which can still be started on this PGPU
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getRemainingCapacity(Connection c, VGPUType vgpuType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_remaining_capacity";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, vgpuType };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param vgpuType The VGPU type for which we want to find the number of VGPUs which can still be started on this PGPU 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getRemainingCapacityAsync(Connection c, VGPUType vgpuType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PGPU.get_remaining_capacity";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, vgpuType };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1.
     * @deprecated since 24.14.0
     *
     * @param c The connection the call is made on
     * @return The accessibility of this PGPU from dom0
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "24.14.0")
    public Types.PciDom0Access enableDom0Access(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.enable_dom0_access";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.PciDom0Access>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1.
     * @deprecated since 24.14.0
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "24.14.0")
    public Task enableDom0AccessAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PGPU.enable_dom0_access";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1.
     * @deprecated since 24.14.0
     *
     * @param c The connection the call is made on
     * @return The accessibility of this PGPU from dom0
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "24.14.0")
    public Types.PciDom0Access disableDom0Access(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.disable_dom0_access";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.PciDom0Access>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.5 SP1.
     * @deprecated since 24.14.0
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "24.14.0")
    public Task disableDom0AccessAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.PGPU.disable_dom0_access";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the PGPUs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<PGPU> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<PGPU>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of PGPU references to PGPU records for all PGPUs known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<PGPU, PGPU.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "PGPU.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<PGPU, PGPU.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}