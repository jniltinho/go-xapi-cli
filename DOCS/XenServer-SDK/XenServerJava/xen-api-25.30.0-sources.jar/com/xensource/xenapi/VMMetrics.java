/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * The metrics associated with a VM
 * First published in XenServer 4.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class VMMetrics extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    VMMetrics(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a VMMetrics, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof VMMetrics)
        {
            VMMetrics other = (VMMetrics) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a VMMetrics
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "memoryActual", this.memoryActual);
            print.printf("%1$20s: %2$s\n", "VCPUsNumber", this.VCPUsNumber);
            print.printf("%1$20s: %2$s\n", "VCPUsUtilisation", this.VCPUsUtilisation);
            print.printf("%1$20s: %2$s\n", "VCPUsCPU", this.VCPUsCPU);
            print.printf("%1$20s: %2$s\n", "VCPUsParams", this.VCPUsParams);
            print.printf("%1$20s: %2$s\n", "VCPUsFlags", this.VCPUsFlags);
            print.printf("%1$20s: %2$s\n", "state", this.state);
            print.printf("%1$20s: %2$s\n", "startTime", this.startTime);
            print.printf("%1$20s: %2$s\n", "installTime", this.installTime);
            print.printf("%1$20s: %2$s\n", "lastUpdated", this.lastUpdated);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "hvm", this.hvm);
            print.printf("%1$20s: %2$s\n", "nestedVirt", this.nestedVirt);
            print.printf("%1$20s: %2$s\n", "nomigrate", this.nomigrate);
            print.printf("%1$20s: %2$s\n", "currentDomainType", this.currentDomainType);
            return writer.toString();
        }

        /**
         * Convert a VMMetrics.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("memory_actual", this.memoryActual == null ? 0 : this.memoryActual);
            map.put("VCPUs_number", this.VCPUsNumber == null ? 0 : this.VCPUsNumber);
            map.put("VCPUs_utilisation", this.VCPUsUtilisation == null ? new HashMap<Long, Double>() : this.VCPUsUtilisation);
            map.put("VCPUs_CPU", this.VCPUsCPU == null ? new HashMap<Long, Long>() : this.VCPUsCPU);
            map.put("VCPUs_params", this.VCPUsParams == null ? new HashMap<String, String>() : this.VCPUsParams);
            map.put("VCPUs_flags", this.VCPUsFlags == null ? new HashMap<Long, Set<String>>() : this.VCPUsFlags);
            map.put("state", this.state == null ? new LinkedHashSet<String>() : this.state);
            map.put("start_time", this.startTime == null ? new Date(0) : this.startTime);
            map.put("install_time", this.installTime == null ? new Date(0) : this.installTime);
            map.put("last_updated", this.lastUpdated == null ? new Date(0) : this.lastUpdated);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("hvm", this.hvm == null ? false : this.hvm);
            map.put("nested_virt", this.nestedVirt == null ? false : this.nestedVirt);
            map.put("nomigrate", this.nomigrate == null ? false : this.nomigrate);
            map.put("current_domain_type", this.currentDomainType == null ? Types.DomainType.UNRECOGNIZED : this.currentDomainType);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * Guest's actual memory (bytes)
         */
        @JsonProperty("memory_actual")
        public Long memoryActual;

        /**
         * Current number of VCPUs
         */
        @JsonProperty("VCPUs_number")
        public Long VCPUsNumber;

        /**
         * Utilisation for all of guest's current VCPUs
         */
        @JsonProperty("VCPUs_utilisation")
        public Map<Long, Double> VCPUsUtilisation;

        /**
         * VCPU to PCPU map
         */
        @JsonProperty("VCPUs_CPU")
        public Map<Long, Long> VCPUsCPU;

        /**
         * The live equivalent to VM.VCPUs_params
         */
        @JsonProperty("VCPUs_params")
        public Map<String, String> VCPUsParams;

        /**
         * CPU flags (blocked,online,running)
         */
        @JsonProperty("VCPUs_flags")
        public Map<Long, Set<String>> VCPUsFlags;

        /**
         * The state of the guest, eg blocked, dying etc
         */
        @JsonProperty("state")
        public Set<String> state;

        /**
         * Time at which this VM was last booted
         */
        @JsonProperty("start_time")
        public Date startTime;

        /**
         * Time at which the VM was installed
         */
        @JsonProperty("install_time")
        public Date installTime;

        /**
         * Time at which this information was last updated
         */
        @JsonProperty("last_updated")
        public Date lastUpdated;

        /**
         * additional configuration
         * First published in XenServer 5.0.
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * hardware virtual machine
         * First published in XenServer 7.1.
         */
        @JsonProperty("hvm")
        public Boolean hvm;

        /**
         * VM supports nested virtualisation
         * First published in XenServer 7.1.
         */
        @JsonProperty("nested_virt")
        public Boolean nestedVirt;

        /**
         * VM is immobile and can't migrate between hosts
         * First published in XenServer 7.1.
         */
        @JsonProperty("nomigrate")
        public Boolean nomigrate;

        /**
         * The current domain type of the VM (for running,suspended, or paused VMs). The last-known domain type for halted VMs.
         * First published in XenServer 7.5.
         */
        @JsonProperty("current_domain_type")
        public Types.DomainType currentDomainType;

    }

    /**
     * Get a record containing the current state of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public VMMetrics.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<VMMetrics.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the VM_metrics instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static VMMetrics getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<VMMetrics>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the memory/actual field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getMemoryActual(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_memory_actual";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VCPUs/number field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getVCPUsNumber(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_VCPUs_number";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VCPUs/utilisation field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     * @deprecated since XenServer 6.1
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    @Deprecated(since = "XenServer 6.1")
    public Map<Long, Double> getVCPUsUtilisation(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_VCPUs_utilisation";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<Long, Double>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VCPUs/CPU field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<Long, Long> getVCPUsCPU(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_VCPUs_CPU";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<Long, Long>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VCPUs/params field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getVCPUsParams(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_VCPUs_params";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VCPUs/flags field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<Long, Set<String>> getVCPUsFlags(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_VCPUs_flags";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<Long, Set<String>>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the state field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getState(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_state";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the start_time field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getStartTime(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_start_time";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the install_time field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getInstallTime(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_install_time";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the last_updated field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Date getLastUpdated(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_last_updated";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Date>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the hvm field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getHvm(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_hvm";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the nested_virt field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getNestedVirt(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_nested_virt";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the nomigrate field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 7.1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Boolean getNomigrate(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_nomigrate";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Boolean>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the current_domain_type field of the given VM_metrics.
     * Minimum allowed role: read-only
     * First published in XenServer 7.5.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.DomainType getCurrentDomainType(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_current_domain_type";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.DomainType>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the other_config field of the given VM_metrics.
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given VM_metrics.
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given VM_metrics.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: vm-admin
     * First published in XenServer 5.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Return a list of all the VM_metrics instances known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<VMMetrics> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<VMMetrics>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of VM_metrics references to VM_metrics records for all VM_metrics instances known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 4.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<VMMetrics, VMMetrics.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "VM_metrics.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<VMMetrics, VMMetrics.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}