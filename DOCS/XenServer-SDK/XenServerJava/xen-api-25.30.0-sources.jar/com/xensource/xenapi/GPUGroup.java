/*
 * Copyright (c) Cloud Software Group, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2) Redistributions in binary form must reproduce the above
 *      copyright notice, this list of conditions and the following
 *      disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package com.xensource.xenapi;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.xensource.xenapi.Types.BadServerResponse;
import com.xensource.xenapi.Types.XenAPIException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;
import java.io.IOException;

/**
 * A group of compatible GPUs across the resource pool
 * First published in XenServer 6.0.
 *
 * @author Cloud Software Group, Inc.
 */
public class GPUGroup extends XenAPIObject {

    /**
     * The XenAPI reference (OpaqueRef) to this object.
     */
    protected final String ref;

    /**
     * For internal use only.
     */
    GPUGroup(String ref) {
        this.ref = ref;
    }

    /**
     * @return The XenAPI reference (OpaqueRef) to this object.
     */
    @JsonValue
    public String toWireString() {
        return this.ref;
    }

    /**
     * If obj is a GPUGroup, compares XenAPI references for equality.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof GPUGroup)
        {
            GPUGroup other = (GPUGroup) obj;
            return other.ref.equals(this.ref);
        } else
        {
            return false;
        }
    }

    @Override
    public int hashCode()
    {
        return ref.hashCode();
    }

    /**
     * Represents all the fields in a GPUGroup
     */
    public static class Record implements Types.Record {
        public String toString() {
            StringWriter writer = new StringWriter();
            PrintWriter print = new PrintWriter(writer);
            print.printf("%1$20s: %2$s\n", "uuid", this.uuid);
            print.printf("%1$20s: %2$s\n", "nameLabel", this.nameLabel);
            print.printf("%1$20s: %2$s\n", "nameDescription", this.nameDescription);
            print.printf("%1$20s: %2$s\n", "PGPUs", this.PGPUs);
            print.printf("%1$20s: %2$s\n", "VGPUs", this.VGPUs);
            print.printf("%1$20s: %2$s\n", "GPUTypes", this.GPUTypes);
            print.printf("%1$20s: %2$s\n", "otherConfig", this.otherConfig);
            print.printf("%1$20s: %2$s\n", "allocationAlgorithm", this.allocationAlgorithm);
            print.printf("%1$20s: %2$s\n", "supportedVGPUTypes", this.supportedVGPUTypes);
            print.printf("%1$20s: %2$s\n", "enabledVGPUTypes", this.enabledVGPUTypes);
            return writer.toString();
        }

        /**
         * Convert a GPUGroup.Record to a Map
         */
        public Map<String,Object> toMap() {
            var map = new HashMap<String,Object>();
            map.put("uuid", this.uuid == null ? "" : this.uuid);
            map.put("name_label", this.nameLabel == null ? "" : this.nameLabel);
            map.put("name_description", this.nameDescription == null ? "" : this.nameDescription);
            map.put("PGPUs", this.PGPUs == null ? new LinkedHashSet<PGPU>() : this.PGPUs);
            map.put("VGPUs", this.VGPUs == null ? new LinkedHashSet<VGPU>() : this.VGPUs);
            map.put("GPU_types", this.GPUTypes == null ? new LinkedHashSet<String>() : this.GPUTypes);
            map.put("other_config", this.otherConfig == null ? new HashMap<String, String>() : this.otherConfig);
            map.put("allocation_algorithm", this.allocationAlgorithm == null ? Types.AllocationAlgorithm.UNRECOGNIZED : this.allocationAlgorithm);
            map.put("supported_VGPU_types", this.supportedVGPUTypes == null ? new LinkedHashSet<VGPUType>() : this.supportedVGPUTypes);
            map.put("enabled_VGPU_types", this.enabledVGPUTypes == null ? new LinkedHashSet<VGPUType>() : this.enabledVGPUTypes);
            return map;
        }

        /**
         * Unique identifier/object reference
         */
        @JsonProperty("uuid")
        public String uuid;

        /**
         * a human-readable name
         */
        @JsonProperty("name_label")
        public String nameLabel;

        /**
         * a notes field containing human-readable description
         */
        @JsonProperty("name_description")
        public String nameDescription;

        /**
         * List of pGPUs in the group
         */
        @JsonProperty("PGPUs")
        public Set<PGPU> PGPUs;

        /**
         * List of vGPUs using the group
         */
        @JsonProperty("VGPUs")
        public Set<VGPU> VGPUs;

        /**
         * List of GPU types (vendor+device ID) that can be in this group
         */
        @JsonProperty("GPU_types")
        public Set<String> GPUTypes;

        /**
         * Additional configuration
         */
        @JsonProperty("other_config")
        public Map<String, String> otherConfig;

        /**
         * Current allocation of vGPUs to pGPUs for this group
         * First published in XenServer 6.2 SP1 Tech-Preview.
         */
        @JsonProperty("allocation_algorithm")
        public Types.AllocationAlgorithm allocationAlgorithm;

        /**
         * vGPU types supported on at least one of the pGPUs in this group
         * First published in XenServer 6.2 SP1.
         */
        @JsonProperty("supported_VGPU_types")
        public Set<VGPUType> supportedVGPUTypes;

        /**
         * vGPU types supported on at least one of the pGPUs in this group
         * First published in XenServer 6.2 SP1.
         */
        @JsonProperty("enabled_VGPU_types")
        public Set<VGPUType> enabledVGPUTypes;

    }

    /**
     * Get a record containing the current state of the given GPU_group.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return all fields from the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public GPUGroup.Record getRecord(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_record";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<GPUGroup.Record>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get a reference to the GPU_group instance with the specified UUID.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param uuid UUID of object to return 
     * @return reference to the object
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static GPUGroup getByUuid(Connection c, String uuid) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_by_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, uuid };
        var typeReference = new TypeReference<GPUGroup>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get all the GPU_group instances with the given label.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param label label of object to return 
     * @return references to objects with matching names
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<GPUGroup> getByNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_by_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, label };
        var typeReference = new TypeReference<Set<GPUGroup>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the uuid field of the given GPU_group.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getUuid(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_uuid";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/label field of the given GPU_group.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameLabel(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the name/description field of the given GPU_group.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public String getNameDescription(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<String>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the PGPUs field of the given GPU_group.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<PGPU> getPGPUs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_PGPUs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<PGPU>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the VGPUs field of the given GPU_group.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VGPU> getVGPUs(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_VGPUs";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VGPU>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the GPU_types field of the given GPU_group.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<String> getGPUTypes(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_GPU_types";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the other_config field of the given GPU_group.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Map<String, String> getOtherConfig(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Map<String, String>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the allocation_algorithm field of the given GPU_group.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Types.AllocationAlgorithm getAllocationAlgorithm(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_allocation_algorithm";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Types.AllocationAlgorithm>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the supported_VGPU_types field of the given GPU_group.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VGPUType> getSupportedVGPUTypes(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_supported_VGPU_types";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VGPUType>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Get the enabled_VGPU_types field of the given GPU_group.
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1.
     *
     * @param c The connection the call is made on
     * @return value of the field
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Set<VGPUType> getEnabledVGPUTypes(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_enabled_VGPU_types";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Set<VGPUType>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Set the name/label field of the given GPU_group.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param label New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameLabel(Connection c, String label) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.set_name_label";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, label };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the name/description field of the given GPU_group.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param description New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setNameDescription(Connection c, String description) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.set_name_description";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, description };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the other_config field of the given GPU_group.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param otherConfig New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setOtherConfig(Connection c, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.set_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, otherConfig };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Add the given key-value pair to the other_config field of the given GPU_group.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param key Key to add 
     * @param value Value to add 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void addToOtherConfig(Connection c, String key, String value) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.add_to_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key, value };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Remove the given key and its corresponding value from the other_config field of the given GPU_group.  If the key is not in that Map, then do nothing.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param key Key to remove 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void removeFromOtherConfig(Connection c, String key) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.remove_from_other_config";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, key };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * Set the allocation_algorithm field of the given GPU_group.
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param allocationAlgorithm New value to set 
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void setAllocationAlgorithm(Connection c, Types.AllocationAlgorithm allocationAlgorithm) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.set_allocation_algorithm";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, allocationAlgorithm };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param nameLabel No description 
     * @param nameDescription No description 
     * @param otherConfig No description 
     * @return The reference of the created GPU_group
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static GPUGroup create(Connection c, String nameLabel, String nameDescription, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, nameLabel, nameDescription, otherConfig };
        var typeReference = new TypeReference<GPUGroup>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @param nameLabel No description 
     * @param nameDescription No description 
     * @param otherConfig No description 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Task createAsync(Connection c, String nameLabel, String nameDescription, Map<String, String> otherConfig) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.GPU_group.create";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, nameLabel, nameDescription, otherConfig };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public void destroy(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        c.dispatch(methodCall, methodParameters);
    }

    /**
     * 
     * Minimum allowed role: pool-operator
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task destroyAsync(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.GPU_group.destroy";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param vgpuType The VGPU_type for which the remaining capacity will be calculated 
     * @return The number of VGPUs of the given type which can still be started on the PGPUs in the group
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Long getRemainingCapacity(Connection c, VGPUType vgpuType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_remaining_capacity";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, vgpuType };
        var typeReference = new TypeReference<Long>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * 
     * Minimum allowed role: read-only
     * First published in XenServer 6.2 SP1 Tech-Preview.
     *
     * @param c The connection the call is made on
     * @param vgpuType The VGPU_type for which the remaining capacity will be calculated 
     * @return Task
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public Task getRemainingCapacityAsync(Connection c, VGPUType vgpuType) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "Async.GPU_group.get_remaining_capacity";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference, this.ref, vgpuType };
        var typeReference = new TypeReference<Task>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a list of all the GPU_groups known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return references to all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Set<GPUGroup> getAll(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_all";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Set<GPUGroup>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

    /**
     * Return a map of GPU_group references to GPU_group records for all GPU_groups known to the system.
     * Minimum allowed role: read-only
     * First published in XenServer 6.0.
     *
     * @param c The connection the call is made on
     * @return records of all objects
     * @throws BadServerResponse Thrown if the response from the server contains an invalid status.
     * @throws XenAPIException if the call failed.
     * @throws IOException if an error occurs during a send or receive. This includes cases where a payload is invalid JSON.
     */
    public static Map<GPUGroup, GPUGroup.Record> getAllRecords(Connection c) throws
            BadServerResponse,
            XenAPIException,
            IOException {
        String methodCall = "GPU_group.get_all_records";
        String sessionReference = c.getSessionReference();
        Object[] methodParameters = { sessionReference };
        var typeReference = new TypeReference<Map<GPUGroup, GPUGroup.Record>>(){};
        return c.dispatch(methodCall, methodParameters, typeReference);
    }

}